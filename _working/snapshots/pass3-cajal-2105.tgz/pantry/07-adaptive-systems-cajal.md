# CAJAL Figure Intelligence Report — Chapter 7: Adaptive Systems: From Pacing to Personalization
*Generated 2026-06-07 · /scan silent*

## Detection summary

The chapter runs on five figure-worthy structures, all confirmed present in the revised text:

1. **The pacing-vs-personalization distinction** (System A / System B opening; the three probe questions; "they route flow; they do not interpret") — the chapter's central undepicted comparison. VG, Critical.
2. **The BKT posterior walk** — a fully worked four-step Bayesian update (0.20 → ≈0.55 → ≈0.84 → ≈0.51 → ≈0.82 against a 0.95 threshold) with the over-practice mechanism explicit. MC + PQ. The author's own placeholder at the worked-update section calls for a table; the figure below supplies the spatial form the table cannot — distance-to-threshold as visible quantity.
3. **The IRT reduction** — two learners with entirely different gaps collapsing to one identical θ reading; the thermometer-not-diagnosis claim. VG.
4. **The two LLM architectures** — LLM-as-generator-on-classical-model (endorsed) vs. LLM-as-learner-model (blocked by 2025 evidence). VG with a hard ⊣.
5. **The measurement-distance effect-size ladder** (d ≈ 0.66–0.76 controlled → +0.20 year-two → +0.04 WWC weighted → year-one null). PQ — but heavily verify-flagged: only Kulik & Fletcher's ≈0.66 is clean-verified; VanLehn's 0.76 carries [verify exact figure], the WWC +0.04 is [verify — partially confirmed], year-two ≈+0.20 traces to the RAND study via the same flag. **Rendered as ordinal schematic; exact values live in the caption with their flags intact.**

**Numbers that must NOT be charted:** the 30–50% time-reduction / 15–25% outcome-improvement figures (Cao et al.) — explicitly contested in the text ("could not be independently confirmed... [contested — see pantry flag]"). Caption-flag territory only; no figure may visualize them. The Knewton $180M / $17M contrast was considered as a PQ bar pair and declined: both figures are reported press numbers serving a narrative, not a measurement; the prose carries it better than a two-bar chart would.

The never-adapts list is structural but is a policy table, not a spatial structure — the author's existing table placeholders cover it. No figure assigned.

## Density recommendation

Main expository body ≈ 3,200 words across six sections. **Five figures**, one per load-bearing section, none in the exercise apparatus. This is the upper-middle of the appropriate range; the chapter is mechanism-dense (two formal models plus an architecture decision) and each figure carries a distinct cognitive job. Do not add a sixth — the never-adapts and warrant-check content is checklist-shaped and belongs in typeset tables.

## Figures

---

### Figure 1 — Two machines, one word (Critical; VG)

**Concept:** Pacing individualization vs. genuine personalization of support — System A changes *when/in what order*; System B changes *what kind of support* based on what the error means. The chapter's titular distinction, currently carried entirely in prose.

**Type:** Two-panel comparison schematic.

**BLOCK 1 — Illustrae paste:**
A two-panel comparison schematic rendered as a flat, unannotated vector illustration. Left panel: a single horizontal track of six identical small squares in muted blue, representing a fixed content sequence. Two filled circles in green sit on the track at different distances along it, each trailed by a short motion arrow of different length — the same path traveled at two speeds. Every square is identical; nothing on the track varies except position. Right panel: the same six-square blue track, but at the third square the path forks at a small pink diamond node. One branch continues straight to the next blue square; the other branch turns downward through a single orange hexagon — a different shape and color from everything else in the figure — before rejoining the track. The hexagon is the only non-square content element in either panel. A thin vertical divider separates the panels. Flat white background, 1pt uniform strokes, geometric precision, generous negative space, no text anywhere, no decorative elements. Clean instructional-diagram aesthetic, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm print width, 300 DPI, vector (SVG master). Two-panel landscape, divider at horizontal center.
- **[C]** 7 components: (1) left fixed track of six identical squares; (2–3) two learner markers with unequal motion arrows [inference: speed difference rendered as arrow length — labeled INFERENCE, the chapter states "radically different speeds" without depicting them]; (4) right track, identical squares; (5) fork node (diamond) at square three [inference: fork position is arbitrary; any mid-track position is faithful]; (6) divergent support element (hexagon, distinct shape class); (7) rejoin path.
- **[O]** Left-to-right reading flow in both panels; → arrows only, single-headed, orthogonal routing; the right panel's branch departs at −90°, passes through the hexagon, rejoins at +90°. No ⊣ in this figure. Panel divider 0.5pt, 50% gray.
- **[P]** Track/content squares anchor #56B4E9; learner markers and motion arrows active #009E73; fork node composite #CC79A7 (it reads the error — a composite judgment); divergent support hexagon secondary #E69F00. Strokes 1pt #000000 at 80% where outlining is needed. No red-green pairing anywhere.
- **[E]** Serious exclusions: no dashboard imagery, no θ or P(mastery) notation (Figures 2–3 own the models), no speed-gauge or speedometer metaphor (clutters the minimal track logic), no third panel for "marketing language" — the figure's force is that two panels look almost identical until you find the hexagon.

**BLOCK 3 — NEGATIVE:**
Figure-specific: clocks, speedometers, gauges, student avatars or faces, screen/UI chrome, more than one divergent-shape element in the right panel, branching in the left panel, curved organic paths. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Seven elements, two-panel parallel structure exploits comparison schema; the single anomalous element (hexagon) is the entire payload. Germane load only.

---

### Figure 2 — The posterior walk to 0.95 (High; MC + PQ)

**Concept:** The BKT update sequence — correct, correct, incorrect, correct — moving P(mastery) 0.20 → ≈0.55 → ≈0.84 → ≈0.51 → ≈0.82, ending below the 0.95 threshold; the over-practice zone made visible as the gap between 0.82 and the gate. Verification status: these are the chapter's own worked-example values, internally computed from stipulated parameters (P(L₀)=0.20, P(T)=0.15, P(G)=0.25, P(S)=0.10) — chart-safe as a worked illustration; caption must state "worked-example values from stipulated parameters, not empirical data."

**Type:** Zero-anchored step trace (probability 0–1) over four evidence events.

**BLOCK 1 — Illustrae paste:**
A minimal step-trace chart rendered as a flat, unannotated vector illustration. A vertical baseline at left and a horizontal baseline at bottom meet at a true zero origin; the vertical extent represents the full zero-to-one probability range. Near the top, a single horizontal line in burnt orange spans the full width — a threshold gate, visually firm, 1pt. A trace of five filled green circles connected by straight 1pt green segments steps across the chart left to right: starting low at one-fifth height, rising to just past half, rising again to just above four-fifths, dropping sharply to just past half, then rising back to just above four-fifths — a zig-zag that climbs, falls hard once, and recovers, but never touches the orange line. The visible gap between the final circle and the orange threshold line is the focal negative space. Four small open blue squares sit along the bottom baseline marking the evidence events, the third subtly distinguished by a thin orange outline. Flat white background, no gridlines, no text, no axis ticks beyond the two baselines, geometric precision, generous margins.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Portrait-leaning square; vertical span maps 0→1 exactly, zero-anchored at the visible origin.
- **[C]** 8 components (at cap): (1) zero-anchored vertical baseline; (2) horizontal event baseline; (3) threshold line at 0.95 height; (4) five-point trace as one polyline component; (5–8) four event markers on the baseline, third marker outlined as the incorrect answer [inference: marker distinction for the wrong answer is an editorial choice; the data distinguishes it, the chapter narrates it].
- **[O]** Left-to-right temporal flow; the trace is the only diagonal element. The threshold line functions as a ⊣ — render it solid and full-bleed across the plot area so the trace visibly fails to cross it. Trace vertices at normalized heights 0.20, 0.55, 0.84, 0.51, 0.82.
- **[P]** Trace and vertices active #009E73; threshold line blocking #D55E00; baselines anchor #0072B2 at 1pt; event markers anchor #56B4E9, incorrect-event outline #D55E00. No red-green adjacency.
- **[E]** Serious exclusions: no formula, no Bayes notation, no per-step intermediate values (the two-stage evidence-then-bump arithmetic would double the point count to nine and bury the shape — the chapter's prose carries the intermediates), no second learner trace (the "P(T) estimated too low" counterfactual is a caption sentence, not a second line).

**BLOCK 3 — NEGATIVE:**
Figure-specific: gridlines, axis tick labels, numeric annotations, smoothed or curved interpolation between points, area fill under the trace, a second trace, checkmark/X icons on event markers, progress-bar imagery. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. One polyline, one gate, four event marks. The hard drop at event three and the unclosed gap to the threshold are pre-attentive; the caption supplies all numbers.

---

### Figure 3 — Two interiors, one reading (High; VG)

**Concept:** IRT as thermometer, not diagnosis — θ is a single position on one difficulty-ordered dimension; two learners with entirely different gaps in understanding produce identical readings. The figure depicts the reduction itself: rich, different internal structures collapsing onto the same scale point.

**Type:** Convergence schematic onto a single vertical scale.

**BLOCK 1 — Illustrae paste:**
A convergence schematic rendered as a flat, unannotated vector illustration. At center, a single vertical line in deep blue — a one-dimensional scale, plain, with no tick marks except one short horizontal notch at its midpoint. Flanking the scale, left and right, two large rounded-square containers of equal size, each holding a different internal composition of small flat shapes: the left container holds a cluster of filled and hollow circles with two conspicuously missing positions in its grid; the right container holds a differently arranged grid with different gaps — same shape vocabulary, clearly non-identical internal patterns. From each container, one straight 1pt arrow in green runs horizontally inward and terminates at exactly the same single pink dot sitting on the scale's midpoint notch. The two arrows meet the scale at one shared point — two distinct interiors mapping to one identical reading. Flat white background, generous spacing, geometric precision, no text, no decoration, Okabe-Ito palette, uniform 1pt strokes.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape, mirror-symmetric about the central scale.
- **[C]** 6 components: (1) vertical θ scale with midpoint notch; (2) left learner container with patterned interior; (3) right learner container with differently patterned interior [inference: the specific gap patterns are invented exemplars of "entirely different gaps" — labeled INFERENCE]; (4–5) two convergence arrows; (6) shared scale-point dot.
- **[O]** Outside-in convergence; → arrows only, both terminating at the identical point — the collision of arrowheads at one dot is the figure's argument. Containers vertically centered; interiors must read as orderly grids with absences, not noise.
- **[P]** Scale anchor #0072B2; containers anchor #56B4E9 outlines; interior shapes 60% gray fills with gaps as voids; convergence arrows active #009E73; shared reading dot composite #CC79A7 (the single number summarizing a composite). 
- **[E]** Serious exclusions: no thermometer pictograph (the metaphor is verbal; a literal thermometer adds an object to decode and invites clip-art drift), no logistic S-curve in this figure (considered and cut — the curve is the model's machinery, the reduction is the design payload; one figure cannot carry both without exceeding the cap), no faces or learner avatars.

**BLOCK 3 — NEGATIVE:**
Figure-specific: thermometer imagery, S-curves, equation fragments, theta or any Greek letterform, more than one dot on the scale, dual-headed arrows between containers, randomized scatter inside containers. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Six elements, bilateral symmetry, single convergence point. The viewer's comparison work (spot the differing interiors) is exactly the chapter's intended inference.

---

### Figure 4 — Generator, not oracle (High; VG)

**Concept:** The two LLM architectures — (A) classical learner model holds state, LLM renders content (endorsed; "the auditable model stays in charge of what the learner needs"); (B) LLM occupies the learner-model seat (blocked: unstable estimates, wrong-direction updates, no persistent representation). The decision rule: vary what the learner sees ≠ decide what the learner knows.

**Type:** Two-panel architecture comparison with one blocked channel.

**BLOCK 1 — Illustrae paste:**
A two-panel system-architecture comparison rendered as a flat, unannotated vector illustration, stacked vertically. Top panel: a left-to-right pipeline of three flat blocks — a solid blue square (the classical state-holder), connected by a 1pt green arrow to a pink rounded rectangle (the generator), connected by a second green arrow to a small neutral circle at right (the recipient). Beneath the blue square, a short looping arrow returns into it from the recipient's direction, in blue — evidence flowing back to the state-holder. Bottom panel: the same three-position pipeline, but the left blue square is absent and the pink rounded rectangle sits alone in the state-holder's position; the arrow leaving it toward the recipient is interrupted mid-path by a bold burnt-orange perpendicular bar — a blocked channel, rendered as a clean T-stop, not an X. A faint dashed outline marks the empty square position where the state-holder should be. Flat white background, orthogonal routing, uniform 1pt strokes, no text, generous negative space, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Two stacked panels, identical geometry, differences strictly local.
- **[C]** 8 components (at cap): top panel — (1) classical-model square; (2) LLM generator block; (3) learner node; (4) evidence return loop [inference: the return loop is implied by "IRT or BKT maintains learner state"; update flow is not drawn in the text — labeled INFERENCE]. Bottom panel — (5) LLM block in state position; (6) learner node; (7) ⊣ block bar on the outbound authority channel; (8) dashed empty state-holder outline.
- **[O]** Left-to-right flow both panels; → single-headed; the ⊣ bar is the only perpendicular element and the only #D55E00 element in the figure — maximal pop-out. The dashed empty square aligns exactly under the top panel's blue square to force the structural comparison.
- **[P]** Classical state-holder anchor #0072B2 (solid) / its absence dashed #56B4E9; LLM blocks composite #CC79A7; forward arrows active #009E73; evidence loop anchor #56B4E9; block bar blocking #D55E00. 
- **[E]** Serious exclusions: no neural-network or brain iconography for the LLM (invites texture and metaphor drift), no chat-bubble imagery, no hybrid neural-symbolic third panel (the chapter mentions it in one sentence; a third panel would dilute the binary decision rule), no hallucination imagery.

**BLOCK 3 — NEGATIVE:**
Figure-specific: brains, neurons, chips, sparkles, chat bubbles, robot icons, X-marks or prohibition circles in place of the clean T-stop, a third panel, crossing wires between panels. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Identical panel geometry means the reader processes only the deltas: missing blue square, ⊣ bar. Two deltas, one rule.

---

### Figure 5 — Distance from the classroom (Medium; PQ — verify-constrained, rendered ordinal)

**Concept:** The efficacy–effectiveness gradient: effect estimates shrink as measurement approaches real deployment (controlled-study d ≈ 0.66–0.76 → year-two at-scale ≈ +0.20 → WWC weighted ≈ +0.04 → year-one null). PQ heuristic applies, but verification status forces a design decision: of the four magnitudes, only ≈0.66 (Kulik & Fletcher 2016) is clean-verified; 0.76, +0.20, and +0.04 all carry [verify] flags in the chapter. **Hard rule applied: unverified figures are not charted to scale. The figure renders ordinal positions only; the caption carries every number with its flag.**

**Type:** Ordinal descent schematic on a zero-anchored implicit scale.

**BLOCK 1 — Illustrae paste:**
A minimal ordinal schematic rendered as a flat, unannotated vector illustration. A single horizontal baseline in deep blue runs the full width — a zero line, visibly the floor of the figure. Above it, four filled circles are placed left to right at descending heights: the first highest, the second markedly lower, the third only slightly above the baseline, the fourth resting on the baseline itself. The circles are not connected by a line — they are discrete measurements, not a trend — but each sits atop its own thin 1pt vertical stem dropping to the baseline, like four unlabeled lollipop markers of decreasing height. Beneath the baseline, a single long horizontal arrow in orange runs left to right, indicating increasing distance along the sequence. The leftmost circle is filled solid blue; the remaining three are blue outlines with white fill — a visual distinction between one anchored value and three provisional ones. Flat white background, no gridlines, no text, no axis ticks, generous spacing, geometric precision, Okabe-Ito palette, 1pt strokes throughout.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Wide landscape; baseline is the true zero anchor.
- **[C]** 6 components: (1) zero baseline; (2–5) four lollipop markers at ordinal heights — descending order only, spacing deliberately non-proportional [inference: heights signal rank, not magnitude — this is the figure's verification-honest design and must be stated in the caption]; (6) deployment-distance arrow below the baseline.
- **[O]** Left-to-right = controlled study → year-two scale → WWC weighted → year-one null; → arrow single-headed. Solid fill on marker 1 only (verified value); open fills on markers 2–4 (verify-flagged values). Marker 4 sits ON the baseline (null).
- **[P]** Baseline and markers anchor #0072B2 (marker 1 solid fill, markers 2–4 open); stems anchor #56B4E9; distance arrow secondary #E69F00. No blocking color — nothing is forbidden here, only provisional.
- **[E]** Serious exclusions: NO numeric scale, no proportional heights (would assert magnitudes the verification pass cannot support), no error bars (would imply precision data the chapter does not contain), no vendor-claim marker for the 30–50%/15–25% contested figures — they do not appear in this figure under any rendering. Caption must carry: each value, its source, and its [verify] flag verbatim from the chapter.

**BLOCK 3 — NEGATIVE:**
Figure-specific: connected trend line, numeric labels, proportional bar heights, error bars, confidence whiskers, a fifth marker, axis tick marks, grid. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Four discrete marks, one direction arrow, one fill distinction. The solid/open fill encoding does double duty as epistemic honesty and visual hierarchy.

---

## Video candidate pass

Criteria sweep:
- **BKT posterior walk (Figure 2 substrate):** transition-mechanism ✓ (belief revision per evidence event); 3+ causal stages ✓ (prior → evidence likelihood ratio → posterior → learning bump → threshold test, repeated four times); cyclical ✓ (the update loop repeats per response); below-observation ✓ (the mastery probability is invisible to the learner and only summarized for the teacher — the entire dynamic happens beneath the progress bar). Four for four.
- **Two LLM architectures (Figure 4):** comparison, not process — static contrast, weak temporal spine. Fails 3+ stages as animation.
- **Measurement-distance ladder:** ordinal arrangement, no mechanism. Fails.
- **Pacing-vs-personalization:** strong comparison but its temporal version (two learners moving) animates speed, which the static figure already conveys. Marginal.

**RECOMMENDED (one): The BKT posterior walk.** A 45–60 second piece: a single probability column fills and drains as four answers arrive; each event splits visibly into evidence-shift then learning-bump; the third event's hard drop lands as the emotional beat; the trace ends hovering at 0.82 under the unmoved 0.95 gate, and the final held frame is the gap — the over-practice zone where a learner drills at 0.94 while the dashboard reports progress. The mechanism is invisible in every real product; animation is the only medium that can show posterior updating happening *to* someone.
