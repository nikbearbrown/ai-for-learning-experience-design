# CAJAL Figure Intelligence Report — Chapter 12: Agentic AI: Bounded Authority and Reversible Paths
*Generated 2026-06-07 · /scan silent*

## Detection summary

Scan of the revised chapter (≈6,820 words) finds a chapter explicitly designed ahead of the evidence (its own Evidence Box says so), whose figure-bearing structure is: one organizing instrument (the L0–L3 authority ladder, governed by stakes × reversibility, with L3 presumptively forbidden for learner-differentiated actions), one diagnostic stack (the missing design layer between model and policy — author DIAGRAM placeholder at the opening), one pattern set (five non-negotiables, honestly labeled inference-from-policy), one designed path (escalation as architecture, with the three-undo trigger and the pre-change holding state), and one verified survey pair (HBR 86% investment vs. 6% deep trust).

- **MC hits:** the escalation path (trigger conditions → leaves agent's hands → human receives with context and deadline → pre-change state persists while waiting → decision or policy revision: five steps, undepicted). Maya's four silent actions → discovery is a sequence, but it is the chapter's narrative engine and is better served by the ladder figure plus prose; depicting Maya risks human-figure and dramatization violations — declined as a figure, flagged for video.
- **VG hits:** the authority ladder (author DIAGRAM placeholder at line ~42 — honored as Figure 1, with two corrections: the placeholder's "green zone / red" band is remapped to Okabe-Ito bluish-green/vermillion, and its microphone/bell/checkmark icon set is simplified to glyphs that survive the no-text rule); the four-layer stack (author placeholder at line ~12 — honored as Figure 2, with its "highlighted in red" instruction likewise remapped); the five non-negotiables (undepicted — Figure 3). The five-capability boundary table placeholder (line ~106) should remain a typeset table — it is row-and-column prose, not vector geometry; CAJAL declines it as a figure.
- **PQ hits:** 86%/6% (HBR Analytic Services 2025) — Evidence Box status: **verified as published survey; not education-specific** → chartable with caption flag. The ~9% production / ~12% governance-readiness figures carry explicit [verify — not pinned] → **never charted**, caption-mention at most. The "MIT Sloan (2026)" definition is [verify] — prose problem, not figure scope. Bastani −17% belongs to earlier chapters; cited here only as scaling intuition — not recharted.
- **No-fabrication note:** the Evidence Box's final row ("GAP: no causal studies exist") is itself a candidate visual idea but contains no depictable structure beyond an empty cell — carried as a caption obligation on Figure 3 instead.

## Density recommendation

**Five figures.** The chapter's load divides cleanly: diagnosis (stack), instrument (ladder), obligations (pattern ring), context (86/6 chart), and operation (escalation loop). The boundary-table and Evidence Box placeholders remain typeset tables. Six would require figuring either Maya (declined — register and human-figure constraints) or the policy floor (statutes resist honest diagramming; the Annex III scoping is prose). Cognitive Load Check passed at five: one idea per figure; the only chart is two bars.

## Figures

### Figure 1 — The Authority Ladder: Autonomy, Visibility, and the Ceiling (Critical; VG)

**Concept:** the four authority levels positioned on a field of agent autonomy (increasing rightward) versus human visibility at the moment of action (increasing upward): L0 suggest (top-left), L1 act-with-approval, L2 act-and-notify, L3 act-silently (bottom-right). A stakes × reversibility ceiling bars high-stakes action types from descending past L1; the L3 corner is blocked outright for learner-differentiated actions. Ladder level is assigned per action type, never per system.

**Type:** positioned-levels field diagram with ceiling band and blocked zone.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A square field bounded by a plain 1pt frame, with no tick marks, no axis arrows inside, no gridlines — a conceptual space, not a chart. Four rounded-square nodes descend diagonally from upper-left to lower-right in a stepped arrangement, like rungs walked down and to the right. The first node, upper-left, in bluish green, contains a small speech-bubble outline glyph; the second, one step down-right, in bluish green, contains an open-gate glyph — two posts with a raised bar; the third, another step, in bluish green, contains a small concentric-arcs signal glyph; the fourth position, lower-right corner, is not a node at all but a dashed hollow square overlaid by a bold vermillion inhibition bar — a place on the field that exists and is refused. A horizontal band in solid orange crosses the field between the second and third positions on the right-hand half only, reading as a ceiling: action types above a stakes threshold cannot pass below this line into autonomous territory. Flat matte vector, 1pt strokes, three hues, generous spacing, no text anywhere.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 7 components: bounding field, four level positions (L0 speech-bubble = a voice no hands; L1 gate = approval; L2 signal = act-and-notify; L3 dashed + ⊣ = forbidden-by-default), ceiling band, inhibition bar. Layout labels: field margins "agent autonomy →" / "human visibility ↑" set outside the frame at typesetting; levels "L0 Suggest / L1 Act with approval / L2 Act and notify / L3 Act silently"; band "stakes × reversibility set the ceiling (Rule 2)"; blocked corner "presumptively forbidden for learner-differentiated actions (Rule 3)." Caption carries provenance honestly, per the chapter: the book's adaptation of Sheridan–Verplanck (1978) and Parasuraman–Sheridan–Wickens (2000) — a design tool with lineage, **not a measured taxonomy of educational outcomes**.
- **[O]** stepped diagonal descent upper-left → lower-right; partial-width ceiling band (it constrains high-stakes action types, not the whole field); ⊣ on the L3 position only.
- **[P]** permitted levels active #009E73 on anchor #56B4E9 field strokes; ceiling band secondary #E69F00; L3 block blocking #D55E00 (Okabe-Ito green/vermillion replaces the placeholder's green/red — colorblind-safe). 1pt, no text.
- **[E]** exclusions: no per-capability examples in the vector (the DataWise table stays typeset); no microphone or bell pictograms from the placeholder (icon vocabulary simplified); the legitimate infrastructural-L3 carve-out (cache warming) is caption-only — drawing a "safe L3" subzone would invite misreading; no Maya iconography.
- **Cognitive Load Check:** four positions, one band, one block — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no literal ladder illustration, no microphones, bells, or checkmark icons, no robot imagery, no axis arrows or tick marks inside the field, no traffic-light metaphor, no gradient zone shading, no padlock on L3. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 2 — The Missing Layer (High; VG — honors author placeholder)

**Concept:** the chapter's diagnosis of Maya's semester: a four-position stack — model layer (sound inference), policy layer (compliant), the design layer (absent: what may the agent do, what does it owe the learner, how is it reversed), learner experience at the bottom. The failure sits in the void between policy and experience; decisions fall through it, unspecified, straight onto the learner.

**Type:** layered-stack diagram with a void.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Four full-width horizontal strata stacked with even spacing, like a clean architectural section. Top stratum: a solid rectangle in deep blue. Second stratum: a solid rectangle in lighter blue. Third position: where a stratum should be, there is instead a dashed hollow rectangle of the same dimensions, its outline in bold vermillion, its interior empty white — a missing course of masonry in an otherwise sound wall. Bottom stratum: a solid rectangle in orange, the layer where someone lives with the result. A single 1pt arrow descends from the second stratum, passes uninterrupted through the empty interior of the dashed void — meeting nothing, deflected by nothing — and lands on the bottom stratum: decisions falling through the absent layer directly onto experience. The arrow must visibly cross the void without contact. Wide margins, flat matte fills, 1pt strokes, strict horizontal alignment, no text, no icons, no ornament. The figure's single event is an absence with consequences.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 5 components: model stratum, policy stratum, void (dashed), experience stratum, fall-through arrow. Layout labels: "Model layer — assume the inferences were sound"; "Policy layer — assume FERPA was honored"; void "Design layer — MISSING: what may it do · what does it owe the learner · how is it reversed"; "Learner experience"; arrow annotation "this chapter." Placeholder's "highlighted in red" remapped to vermillion #D55E00 per palette rules.
- **[O]** vertical stack, top-down; single → through the void; no other connectors.
- **[P]** model anchor #0072B2; policy anchor #56B4E9; void blocking #D55E00 dashed on white; experience secondary #E69F00. 1pt, no text.
- **[E]** exclusions: no Maya depiction, no timeline of the four actions (week 3/5/8/11 stays prose), no platform UI imagery; the layers are institutional abstractions, not screens.
- **Cognitive Load Check:** four strata, one arrow — passes; this is the chapter's simplest figure and should stay that way.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no brick or masonry texture, no crumbling-wall drama, no lightning-bolt failure glyphs, no person at the bottom layer, no cake/sandwich layer clichés, no more than one arrow. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 3 — Five Non-Negotiables Around the Acting Agent (High; VG)

**Concept:** the pattern set as containment architecture: an autonomous action at center, enclosed by the five obligations — learner notification, bounded authority (allowlist), override with both hands (staff and learner), audit log, reversibility. Caption carries the chapter's headline epistemic label: inference from policy frameworks and human-factors lineage, not experimentally validated canon; justified by risk asymmetry.

**Type:** containment ring schematic.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A central solid circle in orange — the autonomous action, energetic, capable — enclosed by a pentagonal arrangement of five rounded-rectangle stations connected to one another by plain 1pt lines forming a closed perimeter ring around the center: the obligations are a containment structure, joined, not five floating tips. Each station carries one minimal glyph: a small concentric-arcs signal (notification at the moment of action); a closed fence of three vertical posts with one gap and a gate bar (bounded authority — the allowlist); two distinct small open-hand outlines side by side, one larger one smaller (override, both hands — staff and learner); a ledger rectangle with four aligned tally bars (audit log, reconstructable); a counterclockwise single-headed return arrow bent into an open arc (reversibility). The central circle touches none of the stations — bounded, not strangled; a thin clear margin separates action from perimeter. All stations in blue family on a white ground, flat matte vector, 1pt, no text, even pentagon geometry, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 7 components: central action, five obligation stations, perimeter ring. Layout labels: the five pattern names; center "autonomous action." Caption carries, near-verbatim, the chapter's epistemic status line: **"inferences from policy frameworks and human-factors lineage, not experimentally validated design canon — no RCT shows audit logs improve learning; the justification is risk asymmetry"** — this caption is non-optional; the figure may not be allowed to look like settled science.
- **[O]** radial containment; perimeter lines plain (structure, not flow); the only arrow is the reversibility glyph's return arc inside its own station.
- **[P]** central action secondary #E69F00; stations anchor #56B4E9 with #0072B2 glyph strokes; perimeter #0072B2. No vermillion — nothing here is blocked; the obligations are architecture, not prohibition. 1pt, no text.
- **[E]** exclusions: escalation and the experiential-correctness test (the chapter's "two patterns that complete the layer") are excluded — escalation gets Figure 5; the test is prose; cramming seven patterns into the ring breaks both the count and the chapter's own structure. No cage or prison imagery — the ring must read as engineered containment, not punishment.
- **Cognitive Load Check:** center + 5 + ring, one glyph each — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no cages, chains, or padlocks, no shield icons, no stop signs, no robot at center, no checkmarks on stations, no sixth or seventh station, no radiating spokes touching the center. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 4 — Invest at 86, Trust at 6 (Medium-High; PQ)

**Concept:** the measured contradiction the chapter opens its institutional-context section with: 86% of surveyed organizations plan to increase agentic-AI investment while only 6% say they deeply trust it (HBR Analytic Services 2025 — Evidence Box status: verified as published survey; not education-specific). The gap between the bars is the absent design layer.

**Type:** zero-anchored horizontal bar chart, two bars.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Two horizontal bars of equal height, stacked with a clear gap, growing rightward from a single shared crisp vertical baseline — the zero anchor, a 1pt rule running the full height of the composition. Behind each bar, a faint hairline frame marks the full 100-extent of the common scale. The upper bar runs to 86 percent of the scale, solid deep blue: intention, investment, momentum. The lower bar runs to just 6 percent of the same scale, solid orange: a stub, almost nothing, trust. The visual event is the violent disproportion between two bars sharing one baseline — the upper bar nearly fourteen times the lower. Between the two bars, no decoration, no bracket, no annotation mark; the white gap itself does the work. No gridlines, no tick marks, no numerals, no axis furniture beyond the baseline and the two hairline frames. Flat matte fills, 1pt outlines, wide left margin reserved for typeset labels. Sober and spare; the chart must not editorialize beyond the lengths themselves.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector; consider half-column placement given only two bars.
- **[C]** 5 components: zero baseline, two data bars, two 100% hairline frames. Layout labels: "plan to increase agentic-AI investment — 86%" / "deeply trust agentic AI — 6%"; source line "HBR Analytic Services 2025." Caption flags, mandatory: practitioner attitude/intent survey, **not education-specific**; and the chapter's reading — "the gap is not hypocrisy; it is the absence of the design layer this chapter teaches."
- **[O]** shared left zero anchor; investment above, trust below.
- **[P]** investment bar anchor #0072B2; trust bar secondary #E69F00; baseline and frames neutral #56B4E9 hairline. 1pt, no text in vector.
- **[E]** exclusions — strict: the ~9% production-deployment and ~12% governance-readiness figures are [verify — attributions not pinned; directional only] per the Evidence Box and **must not appear as bars**; if mentioned at all, caption-only with the verify flag. No third bar, ever, on this chart.
- **Cognitive Load Check:** two bars, one disproportion — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no truncated baseline, no log scale, no pie/donut, no third bar, no money or padlock icons, no numerals in vector, no bracket or gap-callout glyph between bars. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 5 — Escalation Is a Designed Path (Medium; MC)

**Concept:** escalation as architecture, not exception handler: the agent's bounded action domain → trigger conditions (stakes threshold, confidence floor, protected-population flag, repeated learner overrides — three undos of one action type) → the action leaves the agent's hands → a staffed human station receives it with context and a deadline → meanwhile the pre-change state persists as the safe default. The failure case: an escalation landing in an unmonitored queue is L3 with extra steps.

**Type:** left-to-right designed-path flow with holding state.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A left-to-right flow in five stations. First: a rounded square in green containing a small gear-free circular motion glyph — the agent operating inside its bounds. Second: a slim vertical gate of four stacked small diamond shapes — four distinct trigger conditions on one threshold; the path's arrow passes through this gate and visibly changes character after it, from green to blue. Third: an open-hand outline releasing the path — the action leaving the agent's hands, drawn as the arrow exiting a dashed green boundary box that encloses stations one and two only. Fourth: a solid blue rounded square with a small clock-circle outline beside it — the staffed human station with a stated deadline. Beneath the span between gate and human station, a horizontal holding bar in pale blue with a small anchor-like pause glyph (two short vertical bars): the pre-change state persisting while the decision waits, connected upward by thin plain lines to that span. Far right, separated by white space: the counter-example — a dashed hollow square with the arrow entering and a vermillion inhibition bar at its far side — the unmonitored queue where the path dies. Flat vector, 1pt, no text.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 8 components (cap): agent-domain box, trigger gate (counts as one station; four diamonds labeled at layout: stakes / confidence / protected flag / 3 undos), boundary exit, human station with deadline glyph, holding-state bar, connector arrows, counter-example queue with ⊣. Layout labels per station; holding bar "pre-change state persists — the safe default"; counter-example "an unmonitored queue is L3 with extra steps" (chapter near-verbatim). The three-undo trigger is the chapter's explicit spec — no inference flag.
- **[O]** left-to-right →; color shift at the gate marks the handover; ⊣ only on the counter-example; holding state below the main path, connected by plain lines (state, not flow).
- **[P]** agent domain active #009E73 with dashed #009E73 boundary; post-gate path and human station anchor #0072B2/#56B4E9; holding bar pale #56B4E9; dead queue blocking #D55E00. Green and vermillion at opposite ends, never adjacent. 1pt, no text.
- **[E]** exclusions: no specific DataWise capability rows (typeset table); no org-chart of who receives escalations; the experiential-correctness test is not in this figure; no timer-countdown drama on the deadline glyph.
- **Cognitive Load Check:** five stations + holding state + one counter-example — at the ceiling but passes; if proofing feels crowded, the counter-example moves to caption.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no alarm bells or sirens, no exclamation-triangle hazard icons, no human figures at the staffed station (the station is a place, not a person), no gears, no hourglass clichés, no branching spaghetti — one main path, one counter-example. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

## Video candidate pass

Candidates considered: (a) Maya's semester, twice — the same four platform actions replayed under L3 silence (week 3, 5, 8, 11, discovery in week 15) and then under the bounded design (L2 notification with undo for the review items, L1 approval for the quiz window, L0 for the at-risk flag), ending on the experiential-correctness test; (b) the ladder walk — one capability (insert review items) walked through L0/L1/L2/L3 framings to teach per-action assignment; (c) the approval-queue collapse — blanket L1 degrading into rubber-stamp L2, teaching oversight theater.

**Recommended: (a) Maya's semester, twice (90–120s).** It is the chapter's strongest asset — the same pedagogically correct decisions producing failure or legitimacy depending solely on the design layer — and the doubled replay is inherently temporal: animation shows what no static figure can, the *experience* of silence versus notification. Production constraints, firm: no depicted student — Maya is rendered as a course-path line and interface moments only (abstract path, notification chips, an undo affordance), keeping the human-figure rule and the sober register; every on-screen decision is one from the chapter's own scenario; the closing beat is the line "the agent was right" giving way to "is the beginning of the evaluation, not the end." Candidates (b) and (c) are course-site supplements, not print-companion material.
