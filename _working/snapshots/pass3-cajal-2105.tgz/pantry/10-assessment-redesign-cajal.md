# CAJAL Figure Intelligence Report — Chapter 10: Assessment Redesign: Making Reasoning Visible
*Generated 2026-06-07 · /scan silent*

## Detection summary

Scan of the revised chapter (≈5,260 words) finds a chapter built around one mechanism (Kane's four-inference chain, with GenAI severing extrapolation), one comparison the prose makes but never draws (discursive vs. structural change), one decision framework (the three questions, with Question 3 logically prior), one allocation architecture (the two-lane model applied program-level to DataWise 101), and one cluster of verified quantities (94% of AI submissions undetected at Reading; 61.3% of non-native TOEFL essays falsely flagged by Liang et al.).

- **MC hits (3+ steps):** Kane's chain — four sequential inferences, break at link 3, downstream consequence at link 4 (six steps as the chapter teaches it, including the AI attack and the zero-cheating consequence). The three-question protocol — Q3 → Q1/Q2 → per-objective window mix. Both undepicted.
- **VG hits (undepicted structure/comparison):** discursive vs. structural change (Corbin–Dawson–Liu) is the chapter's sorting distinction and exists only in prose. The two-lane program-level allocation has an author placeholder (line ~117 INFOGRAPHIC comment) — honored and tightened below. The three-question framework has a TABLE placeholder (line ~65) — the table should stay a table; the *logical priority* of Q3 is the figure.
- **PQ hits (verified numbers → zero-anchored chart):** 94% (Scarfe et al. 2024, carried as the paper's verified headline) and 61.3% (Liang et al. 2023, carried as the decisive finding, no [verify] flag). Chartable together as the two directions of detection failure. Turnitin's ~15% miss rate is carried as a vendor claim — excluded from the chart, caption-flag only. The 2%-FP/10,000-submissions/200-accusations arithmetic is illustrative, not measured — do not chart; it lives in prose and Exercise 3. Per-module Reading grade margins carry an explicit [verify] — never chart.
- **Existing placeholders:** two author comments (three-question TABLE; two-lane INFOGRAPHIC). Figure 2 below absorbs the infographic placeholder. The table placeholder is editorial, not Illustrae scope.

## Density recommendation

**Five figures.** The chapter has five distinct conceptual movements (inference machine → detection failure → discursive/structural → three questions → two-lane resolution), each carrying one figure cleanly. Six would force a figure onto the pattern-set section, which is honestly labeled as consensus-without-RCTs and is better served by prose. Spacing: roughly one figure per 1,000 words; no two figures within the same section. Cognitive Load Check passed at five: each figure carries exactly one idea, and the only quantitative figure (Fig. 4) carries two bars.

## Figures

### Figure 1 — The Validity Chain and Where GenAI Cuts It (Critical; MC)

**Concept:** Kane's four-inference argument as a literal chain — scoring → generalization → extrapolation → decision — with generative AI severing the extrapolation link, leaving the decision link attached to nothing. The chapter's organizing move ("GenAI breaks the inference, not the rule") in one image.

**Type:** horizontal process chain with break mark.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A clean horizontal chain of four solid rounded rectangles connected left to right by three short single-headed arrows, reading as a sequence of inferential links. The first two rectangles and their connecting arrows are rendered in strong blue, intact and confident. The third connecting segment — between the second and third rectangle — is interrupted by a bold vermillion inhibition bar (a perpendicular blunt-ended stroke, the ⊣ glyph form) cutting cleanly through the arrow shaft, with a small angular wedge shape in vermillion pressing down onto the cut point from above, representing an external force severing the link. The third and fourth rectangles, downstream of the cut, are rendered as hollow outlines in pale blue with dashed connecting arrow, visually drained of support — present but no longer load-bearing. Generous white space around the chain. Flat vector, 1pt uniform strokes, no fills other than the solid upstream rectangles, no text anywhere, no decoration. The single visual event is the cut: everything to its left holds, everything to its right hangs.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm single-column width, 300DPI, flat vector.
- **[C]** 6 components: four inference nodes (scoring, generalization, extrapolation, decision — labels applied at layout, not in vector), one AI wedge (inference attack point — labeled in layout as "GenAI"), one inhibition bar at the extrapolation link. The hollow rendering of nodes 3–4 is an inference the chapter states explicitly ("extrapolation is dead"; decision unwarranted) — label as chapter claim, not Kane's own diagram.
- **[O]** strict left-to-right chain; → for intact inference links 1–2; ⊣ at link 3; dashed → for the orphaned link 4. Wedge enters from above at the ⊣.
- **[P]** intact chain nodes and arrows anchor blue #0072B2; downstream hollow nodes pale tint of #56B4E9; severing wedge and inhibition bar blocking #D55E00. Two hues only. 1pt strokes, no text.
- **[E]** exclusions: no per-module grade data (explicitly [verify] in text); no depiction of the Reading study itself; no cheating/student iconography — the figure must depict the validity failure at zero percent cheating, so no human figures, no "cheater" symbol, no detector imagery. Do not depict all four links breaking — the chapter is precise that scoring and generalization hold.
- **Cognitive Load Check:** one event, two colors, six elements — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no chain-link clipart or literal metal chains, no padlocks, no robot icons, no scales-of-justice, no checkmark/X marks on nodes, no more than one break point, no breakage debris or crack textures. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 2 — Program-Level Allocation: Load-Bearing Walls and Drywall (High; VG)

**Concept:** the two-lane model as program architecture — a sequence of assessments across a program, a minority of which (Lane 1, secure) carry the verification load for the program-level claim, freeing the majority (Lane 2, open) to embrace AI. Mapped to the DataWise 101 resolution: portfolio (Lane 2) + oral (Lane 1) + critique section (Lane 2), with the oral carrying the extrapolation inference. Absorbs the author's INFOGRAPHIC placeholder.

**Type:** structural schematic (architecture/allocation diagram).

**BLOCK 1 — Illustrae paste (unannotated vector):**
A horizontal baseline band representing a program timeline, on which six small rectangles sit in a row like wall segments in an architectural plan. Two of the six are solid filled columns in deep blue, taller than the rest, reading as load-bearing piers; the remaining four are hollow outlined rectangles in orange, lighter and open, reading as non-structural partition walls. From each of the two solid piers, a single upward arrow in blue rises to a wide horizontal beam spanning the full top of the composition — the beam rests visibly and only on those two arrows, depicting a program-level claim supported entirely by the secure verification points. The four hollow rectangles have no arrows; they sit under the beam without touching it. One of the two piers is subtly emphasized with a thicker outline, marking the oral assessment that carries the severed inference from the previous figure. Flat vector, 1pt strokes, even spacing, no text, no ornament; the structural logic — few members carry the load — must read instantly.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 8 components: six assessment segments (two Lane-1 piers, four Lane-2 partitions), one spanning claim-beam, one emphasis stroke on the oral pier. Layout labels assign: beam = "program-level capability claim"; piers = Lane 1 secure (oral, supervised windows); partitions = Lane 2 open (portfolio, critique task, etc.). The DataWise mapping is the chapter's worked case — label as case application, not as the Sydney framework's own artwork; the framework itself is cited as institutional practice, not causal evidence, and the caption must say so.
- **[O]** horizontal row on baseline; ↑ arrows only from piers to beam; no arrows from partitions — the absence is the message.
- **[P]** Lane-1 piers and support arrows anchor #0072B2; Lane-2 partitions secondary #E69F00 outlines; beam anchor #56B4E9. 1pt, no text.
- **[E]** exclusions: do not render Lane 1 as "good" and Lane 2 as "bad" (no checkmarks, no warning marks) — the chapter explicitly rejects that reading; do not depict the two-lane critiques (exam anxiety, accommodation burden) in this figure — they are prose-borne caveats; no percentages or grade weights (15/15/5 stay in text).
- **Cognitive Load Check:** one structural metaphor, three hues, eight elements — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no literal house or building illustration, no bricks or masonry texture, no roof, no swim-lane racetrack imagery, no road/highway lanes, no padlocks on Lane 1, no equal arrows from all six segments (the unequal support is the figure). Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 3 — Three Questions, One Order (High; MC)

**Concept:** the chapter's three-question protocol with its logical priority made visible: Question 3 (visibility — what must the assessment make visible?) sits upstream and *determines* the answers to Question 1 (production) and Question 2 (completion), with completion fanning into the three designed flavors (AI-free window / disclosed-use / AI-required). The prose states Q3 is "logically prior"; the figure is that priority.

**Type:** top-down decision flow.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A single large rounded rectangle at the top center in solid deep blue — the governing question — with two single-headed arrows descending symmetrically to two medium rounded rectangles side by side in mid-blue, the dependent questions. From the right-hand dependent rectangle, three short arrows fan downward to three small pill shapes arranged in a row: the first pill solid green, the second pill green outline with a thin orange inner band, the third pill solid orange — three distinct permission flavors on one visual spectrum from closed to open. The left-hand dependent rectangle has no children; it terminates cleanly. The hierarchy reads strictly top-down: one question above, two below, three options at the foot of only one branch. All connectors are plain single-headed arrows of uniform weight. Flat vector, 1pt strokes, generous vertical spacing between the three tiers, no text, no icons inside shapes, no decoration. The asymmetry — one branch fans out, one does not — is deliberate and must be preserved.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 6 components: Q3 visibility node (top), Q1 production node and Q2 completion node (middle), three completion-flavor pills (AI-free / disclosed-use / AI-required). Layout labels carry the question texts. The top-down ordering is the chapter's explicit claim ("logically prior") — no inference flag needed.
- **[O]** three-tier vertical hierarchy; → (rendered downward) from Q3 to Q1 and Q2; fan of three → from Q2 to flavor pills.
- **[P]** Q3 anchor #0072B2; Q1/Q2 anchor #56B4E9; AI-free pill active #009E73; disclosed-use pill #009E73 outline with secondary #E69F00 accent; AI-required pill secondary #E69F00. Note: green here pairs with blue and orange only — no red/vermillion in this figure, so no red-green adjacency. 1pt, no text.
- **[E]** exclusions: do not depict the confused-policy counterexample; do not add a fourth tier for Kane repairs (that synthesis belongs to the editorial TABLE placeholder already in the manuscript, which should remain a typeset table, not a vector); the per-objective (not per-course) unit of decision is caption text, not geometry.
- **Cognitive Load Check:** three tiers, six elements, one asymmetry — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no question-mark glyphs, no numbered circles, no traffic-light vertical stack (the pills are a permission spectrum, not a stoplight), no equal fan from both middle nodes, no swimlanes. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 4 — Detection Fails in Both Directions (Medium-High; PQ)

**Concept:** the two verified failure rates the chapter carries, charted as the two directions of detector error: 94% of AI-written exam submissions undetected (Scarfe et al. 2024, *PLOS ONE*); 61.3% of human-written non-native TOEFL essays falsely flagged as AI (Liang et al. 2023, *Patterns*). Misses and false accusations, side by side.

**Type:** zero-anchored horizontal bar chart, two bars.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Two horizontal bars of equal height, stacked with a clear gap, both growing rightward from a single shared vertical baseline at the left edge — the zero anchor, drawn as a crisp 1pt vertical rule. The upper bar extends nearly the full available width (94 percent of the scale), rendered in solid vermillion: machine text sailing past human markers. The lower bar extends to just past three-fifths of the same scale (61.3 percent), rendered in solid orange: human text condemned as machine. A faint full-width reference outline at 100 percent sits behind each bar as a hairline rectangle, so each bar visibly falls short of, or approaches, a complete whole. Nothing else: no gridlines, no tick marks, no axis decorations, no third bar. The two bars must share the identical baseline and identical scale so the eye compares lengths honestly. Flat vector, matte fills, 1pt outlines, no text, no numerals — all figures, sources, and the denominator caveat enter via the typeset caption.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 5 components: zero baseline, two data bars, two 100%-reference hairline frames. Layout caption carries: values (94%, 61.3%), full citations, and the mandatory caveat that the bars come from **two different studies with different populations and denominators** (real exam submissions vs. TOEFL essays across seven detectors) — comparison of direction, not of magnitude.
- **[O]** horizontal bars, shared left zero anchor, top-to-bottom order: miss rate, then false-positive rate.
- **[P]** 94% bar blocking #D55E00 (the failure that defeats the assessment); 61.3% bar secondary #E69F00 (the failure that harms students); baseline and reference frames neutral anchor #56B4E9 hairline. 1pt, no text in vector.
- **[E]** exclusions — the serious ones: Turnitin's ~15% acknowledged miss rate is carried in the chapter as a **vendor claim** and is excluded from the chart (caption-flag: "vendor-published figures omitted as unverified"). The 2%-FP → ~200 accusations arithmetic is an illustrative hypothetical, not a measurement — excluded. Per-module Reading grade margins are [verify] — excluded. "Roughly one in five flagged by all seven detectors" is verified prose but adding a third bar mixes denominators further — excluded, caption-mention only.
- **Cognitive Load Check:** two bars, one comparison — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no truncated axis, no third bar, no pie or donut form, no percentage glyphs baked into the vector, no detector-logo iconography, no magnifying glasses or robot icons, no gridlines. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 5 — Discursive Wrapper, Structural Repair (Medium; VG)

**Concept:** the Corbin–Dawson–Liu distinction as a two-panel comparison: a discursive change wraps the unchanged task in a rule layer whose enforcement is unverifiable (dashed, permeable); a structural change alters the task mechanics themselves so validity no longer depends on compliance.

**Type:** two-panel side-by-side comparison schematic.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Two square panels side by side with a thin neutral divider of white space. Left panel: a solid orange rounded square at center — the task, unchanged — enclosed by a dashed orange circle that does not touch it: a rule wrapper, visibly permeable, with one small arrow passing cleanly through the dashed boundary from outside to the task, demonstrating that the wrapper stops nothing. Right panel: the same-size rounded square, but in solid green and visibly re-formed — its right edge cut into a distinctive notched profile, an interlocking keyed shape — with a small matching key-shaped piece in deep blue seated into the notch, depicting a task whose own mechanics have been rebuilt so that only genuine engagement fits. No wrapper circle on the right; the integrity lives in the geometry of the task itself. Both panels balanced, equal visual weight, flat vector, 1pt strokes, no text, no icons beyond the described shapes. The contrast must read in one glance: a rule drawn around an unchanged thing versus a thing rebuilt.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 6 components: left task square, dashed rule wrapper, penetrating arrow; right re-formed task square, keyed insert, panel divider (whitespace). Layout labels: "discursive — rules around the task" / "structural — the task itself." The penetrating arrow is an inference from the chapter's claim that unsupervised discursive rules are unverifiable — label as the chapter's argument.
- **[O]** side-by-side panels; single → penetrating the left wrapper; no arrows in right panel.
- **[P]** discursive panel secondary #E69F00 (task) with dashed #E69F00 wrapper; structural task active #009E73 with anchor #0072B2 key insert. Green and orange never overlap or touch across the divider; no vermillion needed. 1pt, no text.
- **[E]** exclusions: no specific policy text examples (traffic lights, declarations — prose); do not render the left panel as malicious (no skull, no cheating imagery) — discursive policy is inadequate, not evil; do not depict Turnitin or detection here.
- **Cognitive Load Check:** two panels, one contrast — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no padlocks, no shields, no fences or wall imagery, no literal paper-document icons, no checkmark/X verdict marks, no puzzle-piece clichés beyond the single keyed notch. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

## Video candidate pass

Candidates considered: (a) animated Kane chain — build the four links one at a time, run the zero-cheating thought experiment, then sever extrapolation and watch the decision link hang; (b) the DataWise red-team walkthrough — three dead ends (obscurity, detection, pure Lane 1) collapsing in sequence before the portfolio-plus-oral resolution; (c) base-rate arithmetic animation (10,000 dots, 200 turn vermillion).

**Recommended: (a) the Kane chain animation (60–90s).** It is the chapter's single organizing mechanism, it is genuinely sequential (animation adds comprehension that the static Figure 1 cannot), and every beat is verified material. Script spine: chain assembles link by link → the magic-wand zero-cheating world is granted → the chain still fails → the wedge lands on extrapolation → integrity question vs. validity question, side by side as the close. Candidate (b) is strong for the course site but depends on case material; (c) risks dramatizing false accusations and is better as prose.
