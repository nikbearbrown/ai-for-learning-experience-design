# CAJAL Figure Intelligence Report — Chapter 14: Evaluating AI-Mediated Learning

*Generated 2026-06-07 · /scan silent*

## Detection summary

This is the book's measurement chapter and its richest figure terrain. (1) **The four-endpoint architecture** — assisted / unassisted (PRIMARY) / transfer / retention — is the chapter's spine and carries an authored `<!-- TABLE -->` placeholder; the table handles the claims-grammar, but the *temporal-spatial structure* (when and where each endpoint is measured relative to the AI's presence) is undepicted and is the Critical figure. (2) **The Bastani endpoint dissociation** — +48%/−17% vs. +127%/no deficit vs. control — is the one verified quantitative structure in the book (PNAS, marked **Verified — the spine** in the Ch15 Evidence Box): PQ fires, zero-anchored diverging chart, the only data chart these three chapters license. The opening deck's +40%/92%/nine-points are synthetic case numbers — never chart. The 2026 preprint (N=1,222, not yet peer-reviewed) and LearnLM +5.5pp (exploratory, [verify]) — never chart; caption-mention only. (3) **The scissors pattern** has an authored `<!-- CHART -->` placeholder including a "−22pp" annotation — that number is illustrative, not measured; render as a pattern schematic, caption-flagged illustrative, no fabricated values presented as data. (4) **Reliance-trajectory metrics** — declining curve = scaffold, flat/rising = crutch signature, visible in telemetry before any assessment — the book's coinage (flag in caption), an undepicted prediction structure. (5) **The counterfactual ladder** (randomized → staggered/waitlist → pre/post-with-named-threats, descending strength) is a 3-step comparative structure, Supplementary. (6) The **two-register discipline** and the Kirkpatrick critique are argued well in prose; a figure would add furniture, not clarity — no figure.

## Density recommendation

**5 figures** (1 Critical, 3 Important, 1 Supplementary). The chapter is dense with protocol prose and two placeholders already reserved space for the table and the scissors; five figures at one per major section is the correct ceiling. Order: Fig 1 (four endpoints) at the endpoint section, Fig 2 (Bastani PQ) immediately after the "re-read the study as an evaluation design" paragraph, Fig 3 (reliance trajectories) at the withdrawal-protocol section, Fig 4 (scissors) at the subgroup section replacing the placeholder's intent, Fig 5 (counterfactual ladder) at the counterfactual paragraph — cut first.

## Figures

### Figure 1 — The four-endpoint architecture: where each measurement lives (Critical; VG + MC)

**Concept:** Four endpoints measure four different constructs. Assisted performance is taken *inside* the AI's presence; unassisted at withdrawal (primary); transfer on novel material; retention at delay. "Assisted performance and learning are not two readings of one dial." The table placeholder carries the claims; this figure carries the geometry — what is measured with the AI present vs. gone, now vs. later.

**Type:** Measurement-architecture schematic — a 2×2 spatial field (AI present/absent × immediate/delayed-or-novel) with the primary endpoint anchored.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A flat unannotated vector schematic, transparent background, no text. A large rounded-rectangle field occupies the left half, tinted pale orange with a small orange hexagon docked inside its upper edge — the environment with the AI present. Inside it, one orange measurement glyph: a small diamond on a thin pedestal line, like a survey marker. To the right of the field, open white space — the AI withdrawn — holding three more measurement-marker glyphs of identical anatomy but distinct colors and positions: a large deep-blue marker drawn at twice the stroke weight of the others standing just past the field's boundary (unassisted, the primary endpoint, nearest the withdrawal line); a teal-green marker placed higher and farther right, sitting on a small five-sided novel-shape pedestal unlike the others (transfer, novel terrain); and a sky-blue marker far right at the end of a long thin dotted horizontal track (retention, the same measurement after a long delay). A vertical 1pt dashed line marks the field's right boundary — the withdrawal threshold. One thin baseline runs under everything, left to right: time. Flat Okabe-Ito color, large whitespace, exact alignment, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm minimum, ideally 120mm landscape, 300 DPI, vector, transparent.
- **[C]** 8 components: AI-presence field; AI hexagon badge; withdrawal threshold (dashed); assisted marker; unassisted PRIMARY marker (weight-emphasized); transfer marker on novel pedestal; retention marker on delay track; time baseline. No inferences — this is the chapter's explicit architecture.
- **[O]** Left-to-right time; presence field left, absence right; the primary endpoint is the first thing across the threshold — proximity encodes "the Withdrawal Test promoted to protocol." → on the time baseline only.
- **[P]** AI presence/assisted #E69F00 (secondary — legitimate but non-primary); unassisted PRIMARY #0072B2 (anchor-dark, heaviest stroke); transfer #009E73 (active — the strongest learning signal); retention #56B4E9 (anchor-light) on dotted delay track; threshold neutral gray. 1pt base weight, 2pt for primary only, no text.
- **[E]** Serious exclusions: no effect-size numbers (the table and prose carry Bastani; Figure 2 charts it); no Kirkpatrick levels (prose dismantles them — depicting grants them rank); no satisfaction glyph (its absence from the architecture *is* the argument; caption may note the omission is deliberate).

**BLOCK 3 — NEGATIVE:** dashboard or gauge imagery, ruler/measuring-tape clipart, robot icons, brain icons, text labels, words, gibberish letters, numerals, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components at cap, but four are one repeated marker anatomy varied by position/color — effective load ~5 chunks; the single emphasized marker gives an unambiguous entry point. PASS.

---

### Figure 2 — The dissociation: same model, two columns (Important; PQ — verified data)

**Concept:** Bastani et al. (2025), the book's spine, verified: GPT Base +48% assisted / −17% unassisted; GPT Tutor +127% assisted / no deficit; control baseline. The chapter re-frames it as an evaluation design — an assisted-only version would have reported GPT Base as a triumph. The chart must make the missing-column logic visceral: the assisted bars alone cannot distinguish the conditions' fates; the unassisted column can.

**Type:** Zero-anchored paired diverging bar chart, two bars per condition (assisted, unassisted), baseline at zero. Unannotated vector; condition labels, percentages, and source citation applied at layout.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A minimal zero-anchored bar chart as flat unannotated vector, transparent background, no text, no numerals, no axis ticks. A single horizontal 1pt baseline runs across the composition: zero. Two condition groups stand left and right, each a pair of vertical bars. Left group: a tall orange bar rising above the baseline paired immediately with a vermillion bar dropping below the baseline — large assisted gain, real unassisted deficit. Right group: a much taller teal-green bar rising above the baseline (roughly two and a half times the left group's rise) paired with a flat stub at baseline level rendered as a sky-blue tick of near-zero height — huge assisted gain, no unassisted deficit. Bar heights proportional to +48, −17, +127, ~0. The two below-baseline positions are the composition's focus: one filled vermillion descent, one quiet near-empty stub. A faint 15% neutral-gray vertical band shades the entire unassisted pair-column region behind both groups — the column the pilot deck does not have. Flat color, equal bar widths, generous spacing, nothing else.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 7 components: zero baseline; assisted bar (Base); unassisted bar (Base); assisted bar (Tutor); unassisted stub (Tutor); missing-column shading band; (control is the baseline itself — caption states it, no bars fabricated for it). All four values verified against Bastani et al. (2025), *PNAS* — Evidence Box status **Verified**. No other study's numbers enter this chart: LearnLM +5.5pp is exploratory/[verify], the N=1,222 preprint is unreviewed — caption-mention only if at all.
- **[O]** Zero-anchored, diverging vertical; conditions grouped; assisted left within pair, unassisted right; deficit reads downward. No arrows.
- **[P]** assisted gains #E69F00 (secondary — the seductive number); unassisted deficit #D55E00 (blocking — the harm); Tutor assisted #009E73 (active — the scaffold passing); Tutor unassisted stub #56B4E9; shading neutral gray 15%. 1pt outlines, no text.
- **[E]** Serious exclusions: no error bars or intervals (not reported in-text — fabricating them violates no-fabrication); no satisfaction or engagement series; no control-condition bars (baseline by definition; drawing zero-height bars adds noise); no composite "success index" (the chapter kills it).

**BLOCK 3 — NEGATIVE:** axis numerals, percentage signs, gridlines, legend boxes, data labels, trend lines, 3D bars, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components, one encoding (height vs. zero), one comparison axis. The reader's eye lands on the vermillion descent in two saccades. PASS.

---

### Figure 3 — Reliance trajectories: the scaffold curve and the crutch signature (Important; VG — book's coinage, flag)

**Concept:** "A scaffold predicts a declining reliance curve along the Chapter 6 fading schedule; a flat or rising curve is the crutch signature, visible in telemetry before any assessment is scored." Reliance-trajectory metrics are **this book's coinage** (components individually grounded — help-seeking analytics, gaming-the-system detection, paste-and-accept rates); the unified construct and the predictive claim are the book's. Caption must carry both the attribution and the Exercise 9 honesty: the trajectory→outcome correlation is itself an unmeasured hypothesis.

**Type:** Conceptual trajectory schematic — three stylized curves against a faded reference envelope; explicitly NOT a data chart (no data exist).

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A spare conceptual line schematic, flat unannotated vector, transparent background, no text, no numerals, no axis ticks. A thin 1pt neutral horizontal baseline and a thin vertical edge imply a plotting field without gridlines. A wide faded sky-blue band sweeps from upper left to lower right, broad and soft-edged at 25% opacity — the published fading schedule's expected envelope. Three 1.5pt curves cross the field left to right. The first, teal green, descends steadily inside the envelope and exits at the lower right — declining reliance, the scaffold prediction. The second, orange, runs flat across the middle, leaving the envelope as the envelope descends away beneath it — reliance that never fades. The third, vermillion, bends upward toward the upper right — deepening dependency, the crutch signature. At the far right edge, a short vertical dashed neutral line marks the withdrawal window the curves are racing toward. The three curves never touch; spacing stays generous; the geometry is smooth, schematic, and obviously stylized rather than plotted. Flat color only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 6 components: implied axes (one pair); fading-schedule envelope; declining curve; flat curve; rising curve; withdrawal-window marker. Inference labeled twice in caption: (a) construct name is the book's coinage; (b) curves are theoretical predictions, not telemetry — no study yet ties trajectory to withdrawal outcome.
- **[O]** Left-to-right time; envelope descends; divergence of curves from envelope is the read; dashed vertical = upcoming measurement occasion.
- **[P]** envelope #56B4E9 at 25%; scaffold curve #009E73 (active); flat curve #E69F00 (secondary warning); crutch curve #D55E00 (blocking); marker neutral gray. 1.5pt curves, 1pt furniture, no text.
- **[E]** Serious exclusions: no fabricated data points or jitter (stylized smoothness is the honesty marker — points would impersonate telemetry); no Wang et al. paste-rates as plotted values; no second panel correlating trajectory with outcome (unmeasured — the chapter says so).

**BLOCK 3 — NEGATIVE:** data-point markers, confidence ribbons, gridlines, axis numerals, legend boxes, smartphone or chat iconography, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 6 components, three curves with one shared reference — the canonical three-fates pattern, instantly parsed. PASS.

---

### Figure 4 — The scissors pattern: harm invisible at the mean (Important; VG — illustrative schematic, not data)

**Concept:** A population-average null can conceal a subgroup scissors: assisted gains roughly even across prior-achievement quartiles while unassisted deficits concentrate in the lowest quartile (Klarin et al. predict where; theory pre-specifies the slice). The chapter's own placeholder proposes this chart with a "−22pp" annotation — that value is **illustrative**; the figure must read as a pattern schematic and the caption must flag that no plotted value is measured data. PQ explicitly declines to render this as a data chart.

**Type:** Conceptual two-line schematic across four ordinal positions, zero-anchored baseline; stylized, unannotated.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A minimal conceptual schematic in flat unannotated vector, transparent background, no text or numerals. A horizontal 1pt neutral baseline represents zero. Four evenly spaced position ticks along it stand for ordered subgroups, low to high. Two smooth 1.5pt lines cross the field like opening scissor blades. The upper blade, orange, runs slightly above the baseline and nearly level across all four positions — assisted gains, flat and pleasant everywhere. The lower blade, vermillion, starts deep below the baseline at the first position and rises position by position to touch the baseline at the fourth — the unassisted deficit, severe at the left, gone at the right. The two blades visibly converge rightward, scissor-like, their crossing implied beyond the field. At the midpoint hangs a single neutral-gray hollow circle pinned exactly on the baseline — the population mean, reading as nothing. The deepest vermillion point at the first position carries a small solid vermillion dot, the only point emphasis in the figure. Flat color, generous whitespace, deliberately smooth and schematic geometry.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 6 components: zero baseline; 4 subgroup ticks (one set); assisted blade; deficit blade; population-mean hollow circle; deepest-deficit dot. Inference labeled: **all magnitudes illustrative** — the pattern is theory-predicted (Klarin et al. 2024 locate the vulnerability; Bastani provides the dissociation mechanism), but no study reports this quartile breakdown; caption carries the flag verbatim.
- **[O]** Left-to-right ordinal (low→high prior achievement); diverging from zero baseline; convergence direction encodes the scissors closing; hollow circle on the line = the mean that sees nothing.
- **[P]** assisted blade #E69F00 (secondary); deficit blade #D55E00 (blocking); mean marker neutral gray hollow; emphasis dot #D55E00 solid. Baseline neutral. 1.5pt blades, 1pt furniture, no text.
- **[E]** Serious exclusions: no "−22pp" or any numeral (the placeholder's annotation is moved to the caption as a labeled hypothetical, if kept at all); no equity-positive overlay (Tutor CoPilot's +9pp is a different, verified finding — prose carries it; mixing it here would imply one dataset); no demographic iconography.

**BLOCK 3 — NEGATIVE:** numerals, percentage labels, data-point markers along the blades, scissor or blade literalism, bar-chart hybrid forms, demographic icons, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 6 components, two lines and two markers — the mean-as-hollow-circle is the single aha and sits at dead center. PASS.

---

### Figure 5 — The counterfactual ladder (Supplementary — cut first; VG + MC)

**Concept:** Minimum credible comparison designs in descending strength: randomized pilot → staggered rollout / waitlist → pre/post with named threats. "Compared to what?" as a three-rung structure, each rung weaker but each honest if its threats are named.

**Type:** Three-tier descending strength schematic.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A compact three-tier vertical schematic, flat unannotated vector, transparent background, no text. Three horizontal rounded rectangles stack with even gaps, widest and most saturated at top, narrower and paler descending. The top tier, deep blue, contains two equal side-by-side interior cells separated by a 1pt divider with a small coin-flip diamond centered on the divider's top edge — randomization splitting equivalent groups. The middle tier, sky blue, contains the same two cells but offset: the right cell shifted rightward along a thin internal timeline arrow — everyone treated, timing staggered. The bottom tier, pale orange, contains a single cell with one small solid vermillion triangle docked at each of its two lower corners — the named threats a pre/post design must carry to stay honest. A thin neutral vertical spine with a downward 1pt arrow links the three tiers along the left edge: descending strength. Flat Okabe-Ito color, strict column alignment, no ornament.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 7 components: 3 tier containers; randomization diamond; stagger offset arrow; 2 threat triangles (one set); descending-strength spine. No inferences — explicit chapter content.
- **[O]** Vertical descent = descending evidential strength; interior anatomy differentiates the designs; threat triangles only on the weakest tier (named, visible — the honesty condition).
- **[P]** randomized #0072B2 (anchor-dark); staggered #56B4E9 (anchor-light); pre/post #E69F00 (secondary); threats #D55E00 (blocking); spine neutral. 1pt, no text.
- **[E]** Serious exclusions: no fourth "no comparison" tier (the chapter does not dignify it); no p-values, power numbers, or sample sizes; no REES/OSF registry iconography.

**BLOCK 3 — NEGATIVE:** ladder literalism, podium/medal imagery, dice clipart, checkmarks, numerals, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components, repeated container anatomy with one varied interior element per tier. PASS. Cut first under density pressure — prose carries this adequately.

---

## Video candidate pass

**Recommended (one): "The missing column" — 75–90s animation fusing Figures 1 and 2.** Open on the pilot deck's world: only the orange assisted bars exist, both conditions rising, indistinguishable, satisfaction confetti equal. Then draw the withdrawal threshold from Figure 1 — the dashed line — and slide the measurement marker across it. The unassisted column fades in under the gray band: one condition drops to vermillion, the other holds at baseline. End by rewinding to the assisted-only view and letting the viewer watch both futures collapse back into identical-looking decks. The animation performs the chapter's central act — the same evidence with and without the designed column — and it is the one sequence in the book where the reveal genuinely requires time as a dimension. All values verified (Bastani), so motion adds no fabrication risk.

Runner-up (not recommended): the reliance-trajectory race toward the withdrawal window (Figure 3 animated) — strong, but animating an admittedly unmeasured prediction risks lending it telemetry authority; the static schematic with its coinage flag is the honest register.
