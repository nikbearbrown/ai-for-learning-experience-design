# CAJAL Figure Intelligence Report — Chapter 5: AI as Design Partner

*Generated 2026-06-07 · /scan silent · Source: chapters/05-ai-as-design-partner.md*

## Detection summary

| # | Concept zone | Heuristic trigger | Rank | Figure type |
|---|---|---|---|---|
| 1 | Fixation displacement (Wadinambiarachchi, CHI 2024) | MC + VG — verified experimental mechanism with two entry points and a substitution step; chapter calls it "the finding worth memorizing" | Critical | Two-path comparison schematic (idea-space) |
| 2 | Floor-raising vs ceiling-raising | VG — the chapter's organizing lens; author comment at line 30 already requests it; conceptual, not data | Critical | Conceptual curve pair over expertise axis |
| 3 | Artifact quality vs designer capability — the two futures | VG + MC — two incompatible conclusions consistent with all the Moore data; the durability gap relocated | Important | Branching-futures timeline |
| 4 | Anatomy of a workflow policy (three columns, dual rationale, enforcement surface) | VG + MC — the deliverable's structural requirements; author comment at line 70 requests a table, figure complements | Important | Policy-anatomy schematic |
| 5 | Narrow verbs beat broad magic (NN/g) | VG — structural comparison claim, qualitative; only longitudinal tool-value record in the field | Supporting | Tool-scope comparison schematic |

PQ discipline note for the whole chapter: the Moore et al. result arrives as "significantly higher for half the assignments, never lower on average" with no effect sizes quoted, the Adobe 83% is an adoption perception measure the chapter itself disqualifies, and the NN/g findings are qualitative. **No verified chartable numbers exist in this chapter.** Every figure below is structural/conceptual and caption-flagged as such — charting "never worse, sometimes better" as bars would fabricate magnitudes.

## Density recommendation

Main expository text ~3,800 words across six sections (Moore study + the unanswerable question, practitioner adoption base, floor/ceiling, fixation, deskilling epistemics, toolchain + policy, Maya case). **Recommend 5 figures: 2 Critical, 2 Important, 1 Supporting.** The chapter's two author comments (line 30 chart, line 46 diagram) map onto Figures 2 and 1 respectively — both confirmed as genuine figure zones, both refined here to survive the no-text-label and proportional-ink rules. The line 70 table should remain a table; Figure 4 depicts the *structure that makes it a policy*, which the table's cells cannot.

## Figures

### Figure 1 — Fixation Displacement: Your Distribution Replaced by Its Distribution (Critical; MC + VG)

**Concept sentence.** AI-assisted ideators produced more output with less variety because fixation enters twice — the prompt commits the designer to a framing before exploration begins, and the generated output then becomes the anchor — so the AI substitutes its own distribution of ideas for the designer's (Wadinambiarachchi et al. 2024, verified).

**Figure type.** Two-path comparison schematic [standard library: paired process diagram with scatter-field outcomes].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram comparing two ideation paths from one shared starting point. At the left edge, center a single blue circle as the shared design brief. From it, two paths separate. Upper path: the circle opens directly into a wide fan of twelve to fifteen small green dots scattered broadly across the upper right region, irregular spacing, wide angular spread, a few dots far from the centerline. Lower path: the circle leads first through a small orange rectangle, then through a larger orange hexagon, and from the hexagon emerges a dense cluster of eighteen to twenty small pink dots packed tightly around a single axis in the lower right region — visibly more dots than the upper fan but confined to a far narrower spread. From the lower-path hexagon, draw one thick curved vermillion arrow sweeping upward toward the upper fan's region and bending back down into the tight cluster, indicating the wide field being pulled into the narrow one. Single-headed straight arrows along each path. Uniform hairline strokes except the one thick displacement arrow. Flat fills, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, two-lane.
- **[C]** Confirmed (CHI 2024 experiment, N=60, verified in text): unassisted baseline higher fluency/variety/originality; AI condition higher fixation, lower variety; fixation enters at prompt-writing and at output-response; displacement of fixation source onto AI outputs. Components: (1) shared brief node, (2) human-path divergent fan, (3) prompt node, (4) AI-output node, (5) AI-path dense narrow cluster, (6) displacement arrow. 6 components. Dot counts encode the verified *direction* (more output, less variety), not measured quantities — caption-flag: "schematic; dot counts illustrative, direction from Wadinambiarachchi et al. 2024."
- **[O]** Left → right = workflow time; upper lane = unassisted, lower = assisted; → = "produces." The two extra nodes on the lower path *are* the mechanism: each is a fixation entry point. Spread angle, not dot count, carries the variety claim — keep upper fan's angular spread visibly ≥3× the cluster's.
- **[P]** Brief #56B4E9 (anchor); human fan dots #009E73 (active — generative divergence); prompt node and AI-output node #E69F00 (secondary — the intermediating artifacts); assisted cluster dots #CC79A7 (composite — the substituted distribution); displacement arrow #D55E00 (blocking — the harm mechanism). 1pt strokes, displacement arrow 2pt. No text labels.
- **[E]** Exclude any numeric originality/fluency scores (study metrics not quoted in chapter); exclude a sad/happy face on either path (participants *felt helped* — affect iconography would invert the finding's point, which belongs in the caption); exclude making the cluster smaller than the fan in dot count (the finding is more output, less variety — fewer dots would misstate it).

**BLOCK 3 — NEGATIVE PROMPT**

> emoticons, face icons, lightbulb clichés, equal spread on both paths, fewer dots in the assisted cluster, numeric scores, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check (graduate LX designer).** Two paths, one contrast (spread vs density), one mechanism arrow. The double-entry of fixation is carried by the two orange nodes — subtle but recoverable from the caption. Directly scaffolds Exercises 2 and 5. Pass.

---

### Figure 2 — Floor and Ceiling: Two Claims, One Evidenced (Critical; VG)

**Concept sentence.** Floor-raising (AI lifting novice output toward competence) and ceiling-raising (AI lifting expert output toward excellence) are different claims with different economics, and only the first has evidence — Moore et al. occupies the left side of this picture; the right side is currently empty.

**Figure type.** Conceptual curve pair over an expertise axis [standard library: schematic line chart, zero-anchored, explicitly non-data].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector schematic of two curves over a horizontal axis. Draw a horizontal baseline axis from left to right and a vertical axis rising from its left end, meeting at a clearly marked zero origin. Along the horizontal axis, place three small evenly spaced position ticks. Draw the first curve as a solid green line starting high on the left, descending smoothly and steadily, approaching but not touching the baseline at the right end. Beneath the left third of this curve, fill the region down to the baseline with a pale green tint, marking the zone where evidence exists. Draw the second curve as a dashed pink line, starting at the baseline's left and rising gently toward the upper right, its entire length dashed, with no fill beneath it at any point. Leave the right two-thirds of the plot area visibly open and white. The two curves should cross near the middle without emphasis at the crossing. Uniform hairline strokes, the solid curve slightly heavier than the dashed, flat fills, generous white space, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal.
- **[C]** Confirmed structure, conceptual content: floor-raising effect large at novice end, tapering with expertise (Moore et al. 2025 left-region evidence; Tutor CoPilot's lowest-rated-tutor concentration as the corroborating signature); ceiling-raising unevidenced (dashed = hypothesis, no data). Components: (1) zero-anchored axis pair, (2) three expertise ticks (novice/mid/expert), (3) solid floor curve, (4) evidence-region tint, (5) dashed ceiling curve, (6) open unevidenced region. 6 components. **Caption-flag mandatory:** "Conceptual schematic, not plotted data; curve shapes assert claim structure, not measured magnitudes. The Moore result is 'never worse, sometimes better' (n=27, one course) — no effect sizes are depicted because none are charted in the source."
- **[O]** X = designer expertise (novice → expert), Y = AI assistance benefit on *artifact quality* (zero-anchored — the zero line matters: "never worse" means the solid curve never dips below it). Solid = evidenced; dashed = unevidenced inference — the line-style semantics do the epistemic work. Tinted region = where data actually exists.
- **[P]** Floor curve #009E73 solid (active — evidenced); evidence tint #009E73 at 15%; ceiling curve #CC79A7 dashed (composite — hypothetical); axes #0072B2 1pt; ticks black. No text labels.
- **[E]** Exclude error bands or confidence ribbons (would imply quantification); exclude letting the floor curve dip below zero (contradicts "never lower on average"); exclude a third curve for "judgment-displacing" (Exercise 4's third code is a usage category, not a benefit curve); exclude bar-chart treatment (bars assert measured values; the author comment's "conceptual bar chart" is upgraded to curves precisely to avoid Proportional Ink violation on unmeasured quantities).

**BLOCK 3 — NEGATIVE PROMPT**

> bars, error bands, data points, confidence ribbons, curve dipping below the baseline, third curve, numeric axis values, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Two curves, one tint, one epistemic convention (solid/dashed). The figure prevents the chapter's named non sequitur ("better junior decks" → "fewer seniors") by making the right side's emptiness visible. Pass.

---

### Figure 3 — The Two Futures: What the A/B Test Measured and What It Couldn't (Important; VG + MC)

**Concept sentence.** Every Moore data point measures the artifact, not the designer — so identical artifact-quality trajectories are compatible with two opposite year-three futures, judgment accelerated or judgment atrophied, and no study in existence distinguishes them.

**Figure type.** Branching-futures timeline [standard library: timeline with bifurcation and measured/unmeasured zones].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector timeline diagram with one measured track and one bifurcating unmeasured track. Draw a horizontal timeline along the bottom from left to right with a single forward arrowhead and three sparse tick marks. In the upper half's left portion, draw a solid blue line rising gently from left toward a vertical dashed divider placed at the one-third mark; beyond the divider, continue the same blue line rising at the same gentle slope to the right edge, unchanged. In the lower half, draw a second line in solid dark blue from the left that reaches the same vertical divider and splits into two diverging branches: an upper branch in green rising steadily to the right edge, and a lower branch in vermillion sagging steadily downward to the right edge. Tint the entire region right of the dashed divider in the lower half with a very pale gray field, leaving the upper half untinted. Mark the branch point with a small open circle. Uniform hairline strokes, flat fills, no curve crossings, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, two-register.
- **[C]** Confirmed: artifact quality under assistance "never worse, sometimes better" (measured, upper track); designer capability over time unmeasured — two incompatible futures both consistent with all rubric scores (chapter's explicit epistemic exercise). Components: (1) timeline, (2) measured artifact-quality track, (3) capability track pre-branch, (4) branch point, (5) ascending future, (6) descending future, (7) unmeasured-zone tint. 7 components. Inference labeling: both branches are *hypotheses* — caption must state "no longitudinal study of designer capability under sustained AI assistance exists; both branches are projections."
- **[O]** Left → right = career time; dashed vertical divider = the boundary of existing evidence (study horizon); upper register = the artifact (measured, untinted), lower register = the designer (unmeasured beyond divider, gray-tinted). The artifact line deliberately does NOT branch — that is the figure's argument: the measured variable cannot distinguish the futures.
- **[P]** Artifact track #56B4E9 (anchor — the only measured thing); capability pre-branch #0072B2; ascending branch #009E73 (active growth); descending branch #D55E00 (blocking — atrophy); unmeasured tint neutral gray 8%; branch circle #0072B2. 1pt. No text labels.
- **[E]** Exclude probability weighting on branches (no evidence favors either — visual symmetry is the honest rendering); exclude branching the artifact line (fabricates a measurable difference the study design excludes); exclude year numerals (the "year three" is rhetorical, not a measured horizon).

**BLOCK 3 — NEGATIVE PROMPT**

> branch thickness asymmetry, probability percentages, branching upper track, calendar numerals, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** One divider, one non-branch, one branch. The hard idea — same data, incompatible conclusions — is exactly what graduate readers struggle to hold, and the unbranching artifact line gives it a single visual anchor. Directly scaffolds Exercise 9's study-design challenge. Pass.

---

### Figure 4 — Anatomy of a Policy That Survives Deadlines (Important; VG + MC)

**Concept sentence.** A workflow policy is a task table with a reviewer: three columns of tasks (AI drafts / AI assists with a named review criterion / never-touch), a never-touch column carrying two distinct rationale tags — risk-based and apprenticeship-based — and an enforcement surface connecting the middle column to a named human check.

**Figure type.** Policy-anatomy schematic [standard library: columnar structure diagram with annotation nodes].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector schematic of a three-column structure with attached governance elements. Draw three tall rounded rectangles side by side, equal width. Left column: light blue, containing three small generic document glyphs stacked vertically. Middle column: orange, containing three document glyphs each connected by a short horizontal line to a small magnifier badge at the column's right edge; from these badges one consolidated line runs upward to a single dark blue circle positioned above the middle column, representing the named reviewer. Right column: rendered with a heavier border and a flat T-shaped stop bar capping its top edge instead of an arrow; inside, three document glyphs, each carrying one or two small corner tags — some glyphs tagged with a small vermillion shield shape, some with a small green sprout or upward-branch shape, at least one glyph carrying both tags. Beneath the right column, a small green dumbbell glyph sits on a short pedestal. Uniform hairline strokes, flat fills, even column spacing, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, three-column.
- **[C]** Confirmed (chapter's deliverable spec + Maya's shipped policy): three task columns; named review criterion per "AI assists" row; dual rationale tags on never-touch (risk-based / apprenticeship-based — the chapter notes students reliably build only the first); gym clause. Components: (1–3) three columns, (4) reviewer node with criterion links, (5) risk tags, (6) apprenticeship tags, (7) stop-bar cap, (8) gym-clause glyph. 8 components — at cap; if crowded, split the gym clause into the caption rather than dropping a tag type.
- **[O]** Left → right = decreasing AI involvement; the reviewer node sits *above* the middle column only — drafting without review (left) and never-touch (right) need no reviewer, which is itself informative. ⊣ stop bar on the right column = blocking semantics: tasks do not flow out of never-touch. Dual tags on single glyphs encode "one or both tags" from the deliverable spec.
- **[P]** AI-drafts column #56B4E9 (anchor); AI-assists column #E69F00 (secondary — conditional); never-touch border and stop bar #D55E00 (blocking); reviewer node #0072B2 (anchor — the enforcement surface); apprenticeship tags #009E73 (active — skill being built); risk tags #D55E00. 1pt. No text labels.
- **[E]** Exclude any specific task names rendered as text; exclude a fourth column (the chapter's structure is exactly three); exclude padlock icons on never-touch (connotes secrecy; the rationale is development and risk, not confidentiality); exclude rendering the reviewer as connected to the left column (drafts are human-owned post hoc, not criterion-reviewed — miswiring fabricates a workflow).

**BLOCK 3 — NEGATIVE PROMPT**

> padlocks, four or more columns, reviewer lines to the left column, arrowhead atop the right column, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Three columns the reader already knows, plus two tag types and one reviewer — the figure's payload is the *wiring* (reviewer to middle column only; tags on the right only), which is precisely what Design Lab #1 grades. Pass.

---

### Figure 5 — Buy Verbs, Not Magic (Supporting; VG)

**Concept sentence.** The NN/g multi-year record finds that narrow, verb-sized AI features genuinely save time while broad "design this whole screen" generators produce plausible output that ignores flows, accessibility, and constraints — so AI features should be evaluated as specific verbs applied to specific artifacts.

**Figure type.** Tool-scope comparison schematic [standard library: paired mapping diagram].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram contrasting precise narrow tool mappings with one broad fuzzy mapping. Upper register: three small green squares in a vertical stack at the left, each connected by its own short straight single-headed arrow to its own small blue document glyph at the right — three clean one-to-one pairs, arrows parallel, spacing even. Lower register: one large orange circle at the left connected by a single wide arrow that fans out into a broad triangular sweep toward a large blue rectangle at the right representing a full screen; render the large rectangle incomplete — two of its corner regions drawn with gaps in the outline, and place three small vermillion open circles along its edges marking the gaps. Keep the upper register's elements small, tidy, tightly aligned; let the lower register's single mapping be visibly larger but terminate in the broken-edged rectangle. Uniform hairline strokes throughout, flat fills, white background, horizontal composition with a thin neutral divider line between registers.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, two-register.
- **[C]** Confirmed (NN/g 2024; 2025, qualitative): specialized narrow features save time (chapter's examples: rename layers, rewrite microcopy, summarize notes — depicted generically, not labeled); broad generators disappoint via ignored flows/accessibility/constraints/edge cases. Components: (1) three narrow-tool pairs (named group), (2) three target artifacts (named group), (3) broad tool node, (4) fan arrow, (5) incomplete screen artifact, (6) gap markers. 6 components.
- **[O]** Upper = narrow scope, lower = broad; → = "operates on"; one-to-one vs one-to-everything is the entire claim. The gaps in the big rectangle carry "plausible-looking output that ignores constraints" — outline breaks, not X marks (the output isn't rejected; it's incomplete in ways that look complete).
- **[P]** Narrow tools #009E73 (active — the evidenced wins); artifacts #56B4E9 (anchors); broad tool #E69F00 (secondary — the disappointing promise); gap markers #D55E00 (blocking — the ignored constraints); divider neutral gray. 1pt. No text labels.
- **[E]** Exclude time-saved quantities (NN/g findings are qualitative — "marginally better" is a quote, not a number); exclude product logos or named tools (the chapter's own extreme-aging flag: verify product capabilities before each offering); exclude a checkmark/X verdict pair (the heuristic is evaluative posture, not binary judgment).

**BLOCK 3 — NEGATIVE PROMPT**

> product logos, brand marks, checkmarks, X marks, percentage time savings, clock icons, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Two mapping shapes, one contrast. Low intrinsic load by design — this is a procurement heuristic, not a mechanism, and the figure should be readable in three seconds. Pass.

---

## Video candidate pass

Criteria applied: transition-mechanism · 3+ causal stages · cyclical return-to-start · below-observation.

**Candidate 1 — Fixation Displacement in Motion.** The designer's wide idea-field forms → the prompt is written (field narrows to the framing committed) → the AI output lands (a new anchor appears) → subsequent ideation re-centers on the output → the designer's distribution has been replaced by the model's, while the felt experience reports "helped." Transition mechanism: yes — displacement is a *shift event*, not a state. 3+ causal stages: four. Below-observation: emphatically — the study's participants experienced help while measured creativity dropped; the divergence between felt and measured is invisible from inside the experience and only animation can show both channels simultaneously.

**Candidate 2 — The Secret-Cyborg Loop.** Restrictive policy → use goes underground → undisclosed use is unauditable → an incident surfaces → policy tightens → more underground use. Genuinely cyclical with return-to-start, and policy-relevant for Exercise 8. But the mechanism is organizational rather than cognitive, the stages are narratively obvious once stated, and the chapter sources it to a coined term (Mollick) rather than measured dynamics — animation would dramatize, not reveal.

**Candidate 3 — Automating the Apprenticeship.** Junior practice tasks absorbed one by one → reps removed → year-three capability divergence. Three stages, but the payoff frame is already fully carried by Figure 3's branching timeline; a video would duplicate a static asset rather than exceed it.

**Recommended: Candidate 1.** It is the chapter's only verified experimental mechanism (Wadinambiarachchi 2024, the chapter's sole no-flag citation in this zone), it satisfies all of transition-mechanism, 3+ stages, and below-observation, and it carries the book's central trap — assisted experience up, capability signature down — into the designer's own chair, which is the chapter's thesis in one motion sequence. The dual-channel design (what the designer feels vs what the idea-space measures) is the rationale: that split exists in time, and no static figure can hold both channels through the displacement event.
