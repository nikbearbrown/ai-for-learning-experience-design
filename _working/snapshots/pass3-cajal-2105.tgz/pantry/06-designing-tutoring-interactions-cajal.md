# CAJAL Figure Intelligence Report — Chapter 6: Designing Tutoring Interactions

*Generated 2026-06-07 · /scan silent · Source: chapters/06-designing-tutoring-interactions.md*

## Detection summary

| # | Concept zone | Heuristic trigger | Rank | Figure type |
|---|---|---|---|---|
| 1 | GPT Base vs GPT Tutor: the answer placed in the prompt so it can be withheld | VG + MC — the chapter's central design move; author comment at line 12 requests it; RCT-validated architecture | Critical | Side-by-side architecture comparison |
| 2 | The hint ladder with reasoning gates (one pattern, not two) | MC — four levels, two gates, a do-not-reveal floor, and an attempt loop; the chapter explicitly merges ladder and gate | Critical | Gated progression schematic |
| 3 | The fading schedule: contraction with a reversal rule | MC — signal → contraction → struggle → re-expansion; the spec's most original and least evidenced section | Critical | Contracting-band timeline with reversal |
| 4 | Gaming the system: the bottom-out loop and its counter-patterns | MC + VG — cyclical exploit (Baker et al. 2004, verified) with four specifiable counters; author comment at line 50 requests adjacent content | Important | Cycle diagram with blocking interventions |
| 5 | Escalation: four trigger families to a human | VG — undepicted structural claim; stopping as a design decision with a learner-side experience | Important | Convergent routing schematic |

Existing author-planned visuals: line 12 diagram (≈ Figure 1, refined), line 50 decision tree (Figure 4 reframes it as the cycle the evidence actually describes — Baker documented a *loop*, and the counters are loop-breakers; the decision-tree version survives in Figure 4's [O] as an alternate), line 72 spec one-pager table (keep as table — it is an inventory, not a structure), Evidence Box table (keep as is).

PQ note: the chapter's verified numbers (+127%, −17%, *d* ≈ 0.76/0.79, 57 prompts) are either already charted in the Chapter 4 report (the sign flip) or single anchor values that do not support a chart without fabricating a comparison; the worked DataWise quantities (SE = 1, z = 2, P ≈ 0.023) are problem content, not findings. No chart figures in this chapter; all five are structural — correct for a patterns chapter.

## Density recommendation

Main expository text ~4,200 words across six sections (the Bastani artifact, ladder, gates, fading, gaming, escalation, DataWise case) — the densest pattern-catalog chapter in Act Two, where each named section *is* a section of the deliverable spec. **Recommend 5 figures: 3 Critical, 2 Important** — one per spec component, which gives `spec/06` builders a visual per section they must write. Resist a sixth figure for the worked DataWise ladder: its content is textual by nature (hint phrasings), and depicting it would require text labels the standard forbids; the resolved spec lives in the line 72 table.

## Figures

### Figure 1 — Same Model, Two Architectures (Critical; VG + MC)

**Concept sentence.** GPT Base and GPT Tutor ran the same model with the same knowledge, but GPT Tutor's prompt carried three layers — the correct answer marked do-not-reveal, the per-problem misconception inventory, and the incremental-hint/attempt-first instruction — so the answer flowed out of one architecture and was structurally withheld by the other.

**Figure type.** Side-by-side architecture comparison [standard library: paired stack diagram with contrasting output paths].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram comparing two system architectures side by side, sharing one foundation. Across the bottom, draw a single wide light-blue rounded rectangle spanning both halves, representing the shared model. Left half: above the foundation, a single small gray rounded rectangle, from which one thick straight vermillion arrow shoots directly upward to a filled vermillion circle at the top — an unimpeded delivery. Right half: above the same foundation, a stack of three distinct layers — bottom layer a dark blue rectangle containing a small key-shaped glyph crossed by a short flat horizontal bar; middle layer an orange rectangle containing three small jagged error-mark glyphs; top layer a green rectangle containing a small ascending three-step glyph. From this stack, a green arrow rises but passes through a small open gate frame before reaching the top, where it ends at three small open circles of increasing size arranged in a short ascending arc, with the filled circle conspicuously absent. Equal halves, a thin neutral vertical divider between them, uniform hairline strokes except the two output arrows at 2pt, flat fills, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, mirrored halves over a shared base.
- **[C]** Confirmed (Bastani et al. 2025, verified — the design document behind the spine result): same model both conditions; Base = generic instruction → direct answer delivery; Tutor = answer+solution held under do-not-reveal + per-problem common-mistakes inventory + incremental-hint/attempt-first instruction → gated hint sequence, answer withheld. Components: (1) shared model base, (2) generic instruction node, (3) direct-answer arrow+terminal, (4) answer-held layer, (5) inventory layer, (6) hint-instruction layer, (7) gated hint-release path. 7 components. The "57 bespoke prompts" count belongs in the caption, not the vector.
- **[O]** Shared base spanning both halves = "same model, same knowledge" — the figure's load-bearing move; do not split the base. Left arrow → = uncontrolled flow (the failure is the directness); right path passes a gate glyph = release governed. The key-with-bar glyph in the bottom-right layer encodes the chapter's most instructive sentence: the answer is *present* (key) and *blocked* (⊣ bar) — presence enables withholding.
- **[P]** Shared model base #56B4E9 (anchor); generic instruction neutral gray; direct-answer arrow and terminal #D55E00 (blocking semantics inverted deliberately: the unimpeded answer is the harm); answer-held layer #0072B2 with #D55E00 bar (anchor content, blocked release); inventory layer #E69F00 (secondary — the content layer); hint-instruction layer and gated path #009E73 (active — the designed release). 1pt strokes. No text labels.
- **[E]** Exclude any brain or robot iconography for the model (the chapter's point is the model is *not* the variable); exclude unequal base sizes (fabricates a capability difference the RCT excludes); exclude a learner figure (human figures barred; the learner's role appears in Figure 2); exclude rendering the right side's withheld answer outside the stack (the answer is inside the prompt — placement is the finding).

**BLOCK 3 — NEGATIVE PROMPT**

> robot icons, brain icons, split or unequal foundations, answer symbol outside the right stack, padlock clichés, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check (graduate LX designer).** One shared base, one contrast, three layers to learn — and the three layers are exactly the three sections of the spec the reader is about to write. The inverted color logic (vermillion for the "successful" delivery) needs one caption sentence; it is the chapter's thesis, so the sentence is free. Pass.

---

### Figure 2 — The Hint Ladder Is a Gated Ladder (Critical; MC)

**Concept sentence.** A real hint ladder runs four levels of increasing specificity — orientation, principle, partial step, targeted correction — with a reasoning gate before advancement, an attempt loop back to the problem at every rung, and a do-not-reveal floor beneath the deepest level, because ladder and gate are one pattern, not two features.

**Figure type.** Gated progression schematic [standard library: vertical stepped sequence with gate nodes and inhibition floor].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram of a four-step descending progression with gates and a sealed floor. Arrange four horizontal rounded rectangles in a vertical column, each slightly wider and more saturated in blue than the one above, so specificity visibly increases downward. Between rung one and rung two, and between rung two and rung three, interrupt the connecting line with a small orange diamond gate; the connector enters the diamond's top and exits its bottom only after a short horizontal stub from the diamond's left receives a small green input circle — a learner contribution required to open the gate. Between rung three and rung four, a plain connector with a short built-in delay coil. From each rung's right edge, a thin green arrow curves up and rightward, exiting toward a small problem-document glyph at the upper right, then returning — attempt loops. Below the fourth rung, draw a thick horizontal vermillion bar spanning the column's full width, with a small key glyph beneath it. Uniform hairline strokes, the floor bar 3pt, flat fills, white background, vertical composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, vertical.
- **[C]** Confirmed (chapter's canonical ladder + gate properties + DataWise shipped spec): four levels (orientation / principle / partial step / targeted correction); gates before L2 and L3 requiring inspectable learner content (which distribution; attempted z); attempt-first instruction at every level; slow-the-bottom delay before L4; do-not-reveal floor (final probability, completed solution path). Components: (1–4) four rungs, (5) two gate diamonds (named group — same mechanism twice), (6) attempt loops to problem glyph (named group), (7) delay coil, (8) do-not-reveal floor with key. 8 components — at cap via the two named splits; if the renderer crowds, drop the delay coil to Figure 4 where slow-the-bottom recurs.
- **[O]** Top → bottom = increasing specificity (the chapter's "least help that keeps the learner working" runs downward); gate diamonds = advancement conditional on inspectable input (→ exits only after the green input docks); attempt loops → problem glyph = the learner works between hints, the ladder is not a corridor; floor = ⊣ inhibition (3pt bar, no arrowhead) — the key beneath repeats Figure 1's presence-enables-withholding motif.
- **[P]** Rungs #56B4E9 → #0072B2 in four stepped saturations (anchor gradient, single hue — not a rainbow); gates #E69F00 (secondary — conditional); learner inputs and attempt loops #009E73 (active — the learner's reasoning); floor bar #D55E00 (blocking); key #0072B2. 1pt. No text labels.
- **[E]** Exclude a fifth rung (the five-level draft is the case study's *failure*; the canon is four); exclude any solution content glyphs inside rungs (rung content is per-problem and textual — depicting it would demand labels); exclude gates drawn as locks (gates are cheap for honest effort — a lock connotes exclusion, the diamond connotes a check); exclude an arrow exiting below the floor (the whole figure exists to assert none does).

**BLOCK 3 — NEGATIVE PROMPT**

> five rungs, padlock gates, arrow passing the bottom bar, answer glyph below the floor, ladder side-rails as literal ladder clipart, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Four rungs, two gates, one floor — the spec's first two sections in one vertical scan, and the attempt loops preempt the most common student misreading (ladder as a chute you slide down). Highest component count in the chapter set, justified by the chapter's own merge of ladder+gate into one pattern. Pass.

---

### Figure 3 — Fading with a Reversal Rule: Contraction Is Not Abandonment (Critical; MC — caption-flag mandatory)

**Concept sentence.** A fading schedule specifies a competence signal, a contraction of support at each threshold, and a reversal rule that re-expands support on struggle — and without the reversal rule it is not graduated withdrawal but abandonment on a timer.

**Figure type.** Contracting-band timeline with reversal event [standard library: area band over trajectory line].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram of a support band contracting in steps around a learner trajectory, with one re-expansion. Draw a horizontal baseline timeline left to right with a single forward arrowhead. Above it, render a wide light-blue horizontal band beginning at full height on the left. At a first vertical dashed threshold line, the band steps down to roughly half height; at a second dashed threshold, it steps down again to a thin strip. Through the band, draw a single dark-green trajectory line rising gently across the figure. Shortly after the second threshold, give the trajectory a visible dip — a downward notch breaking its rise. Directly above the dip, place a small orange upward arrow, and have the band immediately step back up one level for a stretch before contracting again once the trajectory resumes rising. Mark each dashed threshold with a small dark-blue circle on the trajectory where it crosses. Keep all steps rectangular and clean, band edges crisp, uniform hairline strokes, flat fills, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal.
- **[C]** Confirmed lineage, extrapolated application — caption MUST carry the chapter's own flag verbatim in spirit: **"No direct RCT evidence on fading in generative-AI tutoring exists; this schedule is evidence-informed extrapolation from contingency theory (Wood, Bruner & Ross 1976), faded worked examples (Renkl & Atkinson 2003), and expertise reversal (Kalyuga et al. 2003)."** Content: three support tiers (full ladder / compressed / error-flagging only); competence signals at thresholds (consecutive low-hint successes; BKT mastery); reversal rule re-expanding one tier on struggle. Components: (1) timeline, (2) stepped support band with three tiers, (3) two threshold markers (named group — signals), (4) learner trajectory, (5) struggle dip, (6) reversal re-expansion with trigger arrow. 6 components.
- **[O]** Left → right = time-under-instruction; band height = support breadth (Tier 0 → 1 → 2 from the DataWise spec); thresholds dashed = signal-triggered, not calendar-triggered (the case study's third dead end — a week-8 calendar — is exactly what the dashed signal lines deny); the dip-then-re-expansion sequence is the figure's reason to exist: Wood, Bruner & Ross's contingency runs both directions. → on timeline only; no arrow on band edges.
- **[P]** Support band #56B4E9 (anchor — the scaffold); trajectory #009E73 (active — competence); threshold signal markers #0072B2 (anchors — observed signals); reversal trigger arrow #E69F00 (secondary — support returning); nothing in #D55E00 — fading done right has no blocking element, and the absence is semantic. 1pt. No text labels.
- **[E]** Exclude calendar/week numerals (the anti-pattern); exclude a version where the band contracts to zero (Tier 2 is error-flagging, not absence — the thin strip must remain visible); exclude BKT formulae or probability values (the 0.95 threshold is spec content, caption-eligible, not vector content); exclude depicting the no-reversal failure case in the same frame (a ghost-band comparison would double components; the caption can name abandonment-on-a-timer).

**BLOCK 3 — NEGATIVE PROMPT**

> band reaching zero height, calendar icons, week numbers, probability values, smooth ramp instead of steps, second comparison band, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** One band, one line, one dip, one bounce. The hard concept — support as a *responsive* variable with a sign that flips — is carried by a single re-expansion event the eye cannot miss. The mandatory extrapolation caption does the epistemic labeling the vector cannot. Pass.

---

### Figure 4 — Breaking the Bottom-Out Loop (Important; MC + VG)

**Concept sentence.** Gaming the system runs as a loop — help request, hint-burst faster than reading speed, bottom-out hint harvested as the answer, no learning, next problem, repeat — and each counter-pattern (gate every level, slow the bottom, blunt the bottom, watch the logs) breaks or instruments a specific arc of that loop.

**Figure type.** Cycle diagram with blocking interventions [standard library: circular flow with ⊣ counter-nodes and observer node].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram of a four-node circular loop with three interventions and one observer. Arrange four vermillion circles in a clockwise cycle connected by curved vermillion arrows: top node a small raised-hand glyph, right node a triple-chevron burst glyph, bottom node a downward funnel reaching a small filled square, left node an empty outline square. Onto three of the connecting arcs, place interventions that interrupt them: on the top-to-right arc, a small orange diamond whose stem ends in a flat perpendicular bar against the arc; on the right-to-bottom arc, a small coiled spring segment inserted into the arc's path; at the bottom node, replace the small filled square with a half-filled square rotated forty-five degrees, visibly not the same shape as the filled squares elsewhere. To the upper left, outside the loop, draw one dark-blue circle containing a simple eye glyph, with two thin straight lines — no arrowheads — touching the right arc and the bottom node, indicating observation without interference. Uniform hairline strokes, loop arrows slightly heavier, flat fills, white background, square composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, near-square.
- **[C]** Confirmed (Baker et al. 2004; Aleven et al. 2003 — both verified): gaming loop = help request → hint-burst (log-detectable, faster than reading speed) → bottom-out harvest → no learning → repeat; counters = gate every level (⊣ on advancement), slow the bottom (delay before deep hints), blunt the bottom (analogous step, never the literal answer), watch the logs (burst patterns as reliance-trajectory data). Components: (1–4) four loop nodes (named group: the gaming cycle), (5) gate counter with ⊣, (6) delay counter, (7) blunted-bottom substitution, (8) log-observer node. 8 components — at cap via the loop-as-named-group split.
- **[O]** Clockwise cycle = return-to-start (the learner re-enters at the next problem unimproved); counter placements are arc-specific and load-bearing: the gate interrupts *advancement*, the delay sits on the *descent to deep hints*, the blunting replaces the *harvest target itself*, and the observer touches but never blocks — logs are instrumentation, not intervention. ⊣ flat bar on the gate's contact point; observation lines have no arrowheads (no flow). Alternate rendering per the author's line 50 comment: a top-down decision tree — viable, but the cycle is preferred because Baker's finding is recurrence, and the tree hides the return arc.
- **[P]** Gaming loop nodes and arrows #D55E00 (blocking — the harmful circuit); gate and delay counters #E69F00 (secondary — friction mechanisms); blunted bottom #009E73 (active — the design substitution that makes harvesting pointless); log observer #0072B2 (anchor — measurement); observation lines #56B4E9. 1pt, loop arcs 1.5pt. No text labels.
- **[E]** Exclude a learner figure or villain iconography (the chapter's stance: design for the learner you have, no moralizing); exclude a counter on the fourth arc (cross-system evasion via a second AI window is explicitly *not* solvable in this layer — leaving one arc uncountered is the honesty clause drawn); exclude X marks over the loop (the counters make gaming harder and visible, not impossible).

**BLOCK 3 — NEGATIVE PROMPT**

> villain icons, devil horns, X marks over the cycle, a counter on every arc, broken-chain clichés, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** One loop, three interruptions, one watcher. The deliberately uncountered fourth arc rewards the careful reader and sets up Exercise 9's ungated-window problem — the caption should point at it once. Pass.

---

### Figure 5 — Escalation: Four Triggers, One Human, A Designed Handoff (Important; VG)

**Concept sentence.** A tutoring spec names four trigger families that route the learner to a human — repeated failure after the deepest hint, affective distress, boundary conditions, and direct learner request — and for each, the handoff itself is designed: the learner is told, the human receives context, and the wait is bounded.

**Figure type.** Convergent routing schematic [standard library: multi-input router with bidirectional context/feedback pair].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector diagram of four inputs converging on a router that hands off to a single human node. At the left, stack four small rounded rectangles vertically: first containing a repeat-cycle glyph of two chasing arrows around a small jagged error mark; second containing a sharply descending zigzag line; third containing a boundary glyph of a small square with a segment of its border rendered as a brick-edge; fourth containing a simple raised-hand glyph rendered in blue and slightly larger than the other interior glyphs. Four straight single-headed arrows converge from these rectangles into a central dark-blue diamond router. From the router, one heavier arrow runs right to a large green circle. Along that arrow, attach a small document glyph riding above it, indicating context traveling with the handoff. From the green circle, one thin curved arrow returns leftward past the router toward the input stack's region, ending near a small open clock face with a single marked sector. Uniform hairline strokes, the handoff arrow 2pt, flat fills, even vertical spacing, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, convergent.
- **[C]** Confirmed (chapter's four trigger families + handoff experience requirements; DataWise shipped spec): repeated failure (same misconception after deepest level), affective distress ("I give up" language — routed warmly, never to another hint), boundary conditions (out-of-inventory, graded content, privacy disclosures — decline and route), learner request (one click, always visible); handoff carries the interaction summary; learner is told; wait is bounded. Components: (1–4) four trigger nodes (named group: trigger families), (5) router, (6) human node, (7) context-document on handoff arrow, (8) return/acknowledgment arc with bounded-wait clock. 8 components — at cap via the trigger-stack split.
- **[O]** Left → right = escalation flow; four arrows converge but remain distinct to the router (families are separately specified, not pooled); the learner-request node is drawn slightly larger and in anchor blue because it alone is learner-initiated — always one action away; the return arc = the learner-side experience (told, waiting bounded), the component the chapter calls most commonly forgotten after the reversal rule. → semantics throughout; no ⊣ — escalation is a route, not a block, even for boundary declines (decline *and route*).
- **[P]** Repeated-failure and boundary trigger nodes #E69F00 (secondary — system-detected conditions); distress trigger #D55E00 (blocking-urgent — the never-another-hint case); learner-request trigger #56B4E9 (anchor — learner agency); router #0072B2 (anchor); human node #009E73 (active — the resolving capacity); context document #0072B2; return arc #009E73 thin. 1pt. No text labels.
- **[E]** Exclude a help-desk queue or ticket iconography (the chapter's named failure: dumping into a context-free queue satisfies the letter and fails the purpose); exclude human figures (standard bar — the human node is a circle, not a person); exclude rendering distress with tears or emotive faces; exclude a fifth trigger (the taxonomy is exactly four); exclude any arrow from the human back into more AI hints (escalated moments belong to people — a return-to-tutor loop would fabricate a workflow the chapter never licenses).

**BLOCK 3 — NEGATIVE PROMPT**

> ticket icons, queue lines, headset clipart, crying faces, emotive faces, fifth input node, arrow returning from the human to the tutor, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Four inputs, one router, one human, one return arc. The asymmetric coloring of the four triggers does the taxonomy's work without labels, and the return arc gives Exercise 6's "learner-side experience" requirement a visual referent. Pass.

---

## Video candidate pass

Criteria applied: transition-mechanism · 3+ causal stages · cyclical return-to-start · below-observation.

**Candidate 1 — The Fading Schedule Running Both Ways.** Support band at full width → competence signal fires → contraction → learner stumbles → reversal re-expands support → competence resumes → contraction again, deeper. Transition mechanism: yes — contingency is *defined* temporally (support rising with struggle, receding with competence; Wood, Bruner & Ross 1976), and a static band can only show one re-expansion frozen mid-bounce. 3+ causal stages: signal → contraction → struggle → reversal → re-contraction (five). Cyclical: the contract–reverse–contract rhythm is a damped cycle. Below-observation: yes — tier transitions happen inside the system's logic, invisible to the learner except as announced, and invisible to the instructor except in logs.

**Candidate 2 — The Bottom-Out Burst.** Hint requests arriving faster than reading speed → bottom-out → harvest → next problem. Genuinely cyclical with return-to-start and genuinely below-observation (the burst is a log signature, not a visible behavior). Strong second. But its mechanism is fully legible in Figure 4's static loop — the burst's speed is its one irreducibly temporal property, a thin payload for a video asset.

**Candidate 3 — The Ladder Descent Under Gates.** A learner request descending rung by rung, gates opening on inspectable input. 3+ stages, but it is a walkthrough rather than a mechanism — nothing changes state except position, and Figure 2 carries it.

**Candidate 4 — The Withheld Answer's Path.** The answer entering the prompt, never entering the conversation. Conceptually the chapter's sharpest move, but it is a two-state contrast (present/withheld), not a staged transition; Figure 1 is its complete expression.

**Recommended: Candidate 1.** It is the only candidate where time is the *content* rather than the presentation: a fading schedule is a rule about how support changes over time in response to a changing learner, and the reversal rule — the component the chapter says is most commonly forgotten — only demonstrates its meaning when the viewer watches support come *back*. It also carries the chapter's heaviest epistemic flag (zero direct RCTs; evidence-informed extrapolation), and a video's narration track can hold that label on screen for the full duration in a way no figure caption can — the asset teaches the pattern and its evidence status simultaneously, which is this book's whole method.
