# CAJAL Figure Intelligence Report — Chapter 2: The Crutch Effect
*Generated 2026-06-07 · /scan silent · Source: chapters/02-the-crutch-effect.md*

## Detection summary

| Zone | Heuristic | Rank | Type |
|---|---|---|---|
| Chess-academy outcome: system-regulated 64% vs. self-regulated 30% improvement | PQ | Critical | statistical-quantitative (dot plot, zero-anchored) |
| Help-request decision model: rational single choice → accumulated ruinous policy | MC | Critical | cycle diagram / mechanism |
| Escalation curve: help requests per move rising over 12 weeks | PQ | Important | statistical-quantitative (line chart, zero-anchored) |
| Five crutch-producing patterns → "the crutch is the default" | VG | Important | hierarchy-taxonomy |
| Cognitive-debt finding (Kosmyna): EEG connectivity scaling with external support | VG | Supplementary | structural schematic (single-source — mandatory caption flag) |

Triaged to zero (correct zeros): the offloading ledger (the chapter operationalizes it as a four-cell checklist and the spec exercises render it as a table — tabular, not figural; a figure would duplicate the form learners must fill); the desirable-difficulties catalog (the chapter's own `<!-- TABLE -->` marker claims it — rows of text pairs, no spatial structure); the Wang et al. 85%/copy-paste survey numbers (n=40 exploratory sample the chapter explicitly warns circulates beyond its weight — charting would amplify exactly that error; the HEPI triangulation figure carries a [verify] flag — never chart a [verify]); the calculator/LLM disanalogy (a one-sentence contrast, carried perfectly by prose); the DataWise risk-map worked example (procedure, destined for the learner's own spec artifact).

## Density recommendation

For this chapter, I recommend **5 figures using Mechanistic density.** Chapter 2 is the book's mechanism chapter: it must convert a memorable anecdote (one extra button, half the learning) into a causal model the reader can run on new products. That demands the decision-model diagram (the mechanism itself), the two quantitative anchors that discipline it (outcome dot plot, escalation curve — the chapter's own `<!-- CHART -->` marker claims the latter), and the pattern taxonomy that operationalizes it. The Kosmyna schematic is supplementary and deliberately modest: the chapter's pedagogical point is *calibration*, so the figure must be visibly weaker in visual rhetoric than the behavioral figures — a rare case where under-designing is the design.

## Figures

---

### Figure 1 — One Extra Button: 64% vs. 30% (rank: Critical; heuristic: PQ)

**Concept (one sentence):** Over twelve weeks, system-regulated chess students improved 64% while self-regulated students — identical condition plus one on-demand help button — improved 30%, less than half the learning from a single affordance difference.
**Figure type:** statistical-quantitative (horizontal dot plot, zero-anchored, with condition-difference glyph)

**Cognitive Load Check:** Two dots, one zero baseline, one small affordance glyph distinguishing the conditions, one gap bracket. Five components, one comparison. Single pass trivially. Pass.

**Data integrity note:** CAPTION FLAG REQUIRED. Source is a working paper (Bastani et al., reported via Knowledge at Wharton / INSEAD Knowledge, early 2026), not yet peer-reviewed — the chapter holds it to that standard and so must the caption: "Working paper; values as reported in secondary coverage; not yet peer-reviewed." The numbers may be charted because the chapter carries them as its central evidence, but the provisional status travels with the figure. Dots, not bars; zero line visible; both values positive so no negative region needed.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector dot-plot figure, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels. Draw one horizontal axis line at the bottom, 1.5 pt in dark blue-gray, with its zero point clearly marked at the left end by a short vertical anchor tick. Above it, place two horizontal guide rows. On the upper row, set a large bluish-green circular dot positioned far right along the scale. On the lower row, set a vermilion circular dot positioned at slightly less than half the upper dot's distance from zero. At the left margin of each row, draw a small condition glyph: beside the upper row, a minimal clock-face outline glyph indicating system-timed support; beside the lower row, the same clock-face glyph plus one small additional rounded-rectangle button shape outlined in vermilion. Span the horizontal distance between the two dots with a thin vertical-ended bracket in neutral gray emphasizing the gap. Use 1 pt strokes, flat fills, generous spacing, and leave all elements unlabeled for downstream annotation.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed chapter content only, 5 components: system-regulated dot at 64; self-regulated dot at 30 (proportional placement: lower dot at 30/64 ≈ 0.47 of upper dot's offset — Proportional Ink Rule); zero-anchored axis; two condition glyphs whose only difference is one added button shape (the chapter's "entire difference"); gap bracket. Caption must carry the working-paper flag — values not yet peer-reviewed.
[O] Two-row horizontal dot plot; zero at left; rows ordered system-regulated above, self-regulated below; condition glyphs at left margin aligned to rows; gap bracket between dot positions. The "+1 button" glyph difference is the figure's argument — make it the only visual difference between the two row glyphs.
[P] Flat vector, Okabe-Ito: system-regulated (better outcome) #009E73; self-regulated (worse outcome) #D55E00; added-button glyph stroke #D55E00; axis and bracket #0072B2 and neutral gray; 1 pt strokes; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no bars (dot-plot mandate); no axis starting above zero; no chess pieces, chessboards, or game iconography (the domain is incidental to the design lesson and pieces add narrative clutter); no human figures; no exaggerated dot-size difference (encode by position only — equal dot diameters); no percent symbols or numerals; no third row; no arrowheads on the bracket; no trophy/medal icons; no gradient fills; no drop shadows; no implication of time course in this figure (the trajectory belongs to Figure 3).

**BLOCK 3 — NEGATIVE PROMPT:**
bar chart, truncated axis, chess pieces, chessboard pattern, trophies, medals, unequal dot sizes encoding magnitude, numerals, percent signs, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 2 — The Rational Shortcut: One Choice, Accumulated Policy (rank: Critical; heuristic: MC)

**Concept (one sentence):** At each stuck moment the learner faces Option A (struggle: high immediate effort, invisible delayed benefit) versus Option B (ask: low effort, guaranteed progress, invisible delayed cost), and because each B-choice is individually rational, the loop repeated across a semester compounds into the ruinous "always B" policy.
**Figure type:** cycle diagram / mechanism (decision fork feeding a repetition loop with an accumulation outcome)

**Cognitive Load Check:** Seven components: stuck-moment node, decision fork, Option A path with delayed-benefit marker, Option B path with delayed-cost marker, loop-back arrow, repetition multiplier cue, accumulated-outcome terminal. This is the chapter's load-bearing mechanism and the upper bound of single-pass capacity; discipline holds only if the two option paths are strictly symmetric in layout so the reader processes them as one contrast, not two diagrams. Pass with that constraint.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector mechanism diagram, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels. At top center, draw a small neutral-gray circle containing a minimal question-mark-free obstacle glyph: a path line interrupted by a solid block. From it, two 1 pt arrows diverge symmetrically. The left arrow, in bluish-green, leads to a node showing a steep ascending ramp glyph; beyond it, a thin dashed bluish-green arrow continues to a small distant solid green diamond, dashed to signal a delayed and uncertain benefit. The right arrow, in vermilion, leads to a node showing a flat shallow ramp glyph with an immediate solid checkmark-free progress tick; beyond it, a thin dashed vermilion arrow continues to a small distant hollow vermilion diamond signaling a delayed hidden cost. From the right-hand node, draw a prominent curved 1 pt vermilion arrow looping back up to the obstacle node, accompanied by three small stacked repeat-tick marks beside the loop. At bottom right, terminate the loop's accumulation in a wide shallow vermilion wedge that grows from thin to thick left to right. Keep symmetry strict and spacing generous.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed chapter content, 7 components: stuck moment; Option A — struggle (high effort now, delayed/probabilistic/invisible benefit: stronger schema); Option B — ask (low effort, guaranteed progress, delayed/probabilistic/invisible cost); the loop (the policy "always B when stuck"); repetition cue ("run a hundred times across a semester"); accumulation wedge (the −17%/30%-vs-64% outcome class). Dashed strokes on both delayed consequences encode "invisible, delayed, probabilistic" — chapter language, not inference. The growing wedge is interpretive shorthand for accumulation — flag in caption as schematic, not measured.
[O] Vertical fork: obstacle top-center; A-path left, B-path right, mirror-symmetric; delayed consequences rendered smaller and farther (distance = delay); loop-back curve only on the B side; accumulation wedge bottom-right as the loop's product; → arrows throughout, single direction.
[P] Flat vector, Okabe-Ito: Option A / benefit #009E73; Option B / cost #D55E00; obstacle and repetition cues neutral gray; structural strokes #0072B2 where neither valence applies; 1 pt strokes; dashed = delayed/uncertain; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no moral iconography (no devil/angel, no lazy-student imagery — the chapter deletes "lazy" from the vocabulary and the figure must too); no human figures; no brain icons; no loop on the A side (the chapter does not model struggle as self-reinforcing — adding one fabricates a relationship); no equal solidity between immediate and delayed elements (the visibility asymmetry IS the mechanism); no scale or numbers on the wedge; no clock faces; no more than one loop arrow; no gradient fills; no drop shadows; no red-green adjacency (green and vermilion paths separated by the full diagram width).

**BLOCK 3 — NEGATIVE PROMPT:**
angel and devil icons, sleeping or lazy student imagery, brain icons, human figures, loop arrows on the struggle path, numeric annotations, clock faces, balanced solid strokes for delayed outcomes, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 3 — The Escalation Curve (rank: Important; heuristic: PQ)

**Concept (one sentence):** Self-regulated students' help requests rose continuously across the twelve weeks — reaching a tip every three to four moves by the end, still rising at study close — making the escalation trajectory the crutch effect's earliest measurable signal.
**Figure type:** statistical-quantitative (single line chart, zero-anchored y-axis)

**Cognitive Load Check:** One rising line, two axes, one endpoint marker, one open-continuation cue. Four components. Trivial single pass. Pass.

**Data integrity note:** CAPTION FLAG REQUIRED, twice over. (1) Working paper, as Figure 1. (2) The chapter's prose verifies only the endpoint ("every three to four moves" by week 12) and the direction ("escalated over time," "still rising at the study's end"); the intermediate curve shape (the chapter's own figure marker sketches ~0.1 → ~0.25 per move) is reconstruction, not published data points. Caption: "Curve shape schematic; endpoint and direction as reported; working paper, not yet peer-reviewed." Render the line without data-point markers — markers would assert observations that are not confirmed.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector line chart, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels. Draw an L-shaped axis frame in dark blue-gray at 1.5 pt: a horizontal axis with twelve small evenly spaced tick marks, and a vertical axis anchored at zero where the two axes meet, with four unlabeled tick marks. Plot one smooth monotonically rising concave-up curve in vermilion, 1.5 pt, beginning very low near the zero origin and rising steadily to roughly two and a half times its starting height at the rightmost tick. Do not place dot markers along the curve. At the curve's right end, continue it briefly past the final tick as a short dashed vermilion segment angled still upward, signaling that the rise had not saturated when measurement stopped. Beneath the curve, fill the area down to the axis with a flat vermilion tint at 8% opacity. Add one thin horizontal reference line in neutral gray near the curve's endpoint height. Keep the composition spare, with generous margins and no gridlines.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Chapter-confirmed content, 4 components: x = weeks 1–12 (twelve ticks); y = help requests per move, zero-anchored; one rising curve (low start → endpoint ≈ one tip per 3–4 moves); dashed continuation = "still rising at the study's end" (chapter-stated, not inferred); endpoint reference line = the tips-every-3–4-moves level. Intermediate curve shape is schematic — caption-flag; working paper — caption-flag. No data-point markers (no observations to assert).
[O] Single panel; origin at lower left; time flows right; smooth markerless line; light area fill under curve to read accumulation; dashed overshoot past final tick.
[P] Flat vector, Okabe-Ito: escalation curve #D55E00 (the negative/blocking trajectory); axes #0072B2 dark variant or blue-gray; reference line neutral gray; under-curve tint 8% of #D55E00; 1 pt strokes (curve 1.5 pt); no text labels; unannotated blank vector.
[E] EXCLUSIONS: no data-point dots or markers on the curve (unconfirmed observations); no numeric axis values; no second line (no system-regulated trajectory is reported — drawing one would fabricate data); no plateau or downturn at the right edge (contradicts "still rising"); no y-axis break or non-zero start; no annotation arrows; no smoothing flourishes implying confidence bands; no confidence intervals (none published); no gridlines; no gradient fill; no drop shadows; no clock or calendar icons.

**BLOCK 3 — NEGATIVE PROMPT:**
data point markers, second comparison line, confidence bands, plateauing curve, numeric labels, calendar icons, gridlines, axis break, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 4 — The Five Crutch-Producing Patterns: The Default Profile (rank: Important; heuristic: VG)

**Concept (one sentence):** Five named design patterns — complete answers on request, no reasoning requirement, unrestricted access, engagement-optimized friction removal, and no fading — jointly constitute the crutch default: the zero-design outcome that standard product practice ships.
**Figure type:** hierarchy-taxonomy (five pattern modules converging on one default outcome)

**Cognitive Load Check:** Five pattern glyph-modules plus one convergence terminal: six components. Glyphs must be maximally distinct silhouettes (gift/answer, open gate, always-open door, smoothed slope, constant-width beam) so the reader chunks them as five nameable things in one pass. Pass.

**Source fidelity note:** The fifth pattern (no fading) is flagged in the chapter as evidence-informed extrapolation, "the least-studied pattern in GenAI tutoring." Encode that status visually — dashed outline on that module — and state it in the caption. Visual evidence-status encoding is itself a chapter discipline (the Evidence Box habit); the figure should model it.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector taxonomy diagram, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels. Arrange five equal rounded-square modules in a single vertical column on the left, each outlined in vermilion at 1 pt and containing one distinct minimal glyph in flat vermilion: first, a hand-free delivery glyph of a complete document arriving instantly (document with motion lines); second, an open gate glyph drawn as two posts with no bar between them; third, a doorway glyph with three radiating availability ticks above it; fourth, a perfectly smooth frictionless ramp glyph with a small sphere at its base; fifth, a horizontal support beam of constant thickness running edge to edge — and render this fifth module's outline dashed rather than solid. From each module, draw a thin 1 pt arrow converging rightward into a single larger rounded-rectangle terminal outlined in vermilion at 1.5 pt, containing a minimal crutch-like angled support bar glyph. Keep all five arrows parallel-fanning and orderly, modules evenly spaced, generous white space throughout.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed chapter content, 6 components: the five patterns (complete answers on request; no reasoning requirement before help; unrestricted access throughout practice; engagement-optimized friction removal; no fading) converging on the default-crutch terminal ("the zero-design outcome"). Dashed outline on "no fading" = chapter's own extrapolation flag, stated in caption. Glyph vocabulary is interpretive shorthand — caption notes glyphs are mnemonic, not product screenshots.
[O] Five-module left column, top-to-bottom in chapter order; → arrows fanning right into one terminal; equal module sizes (no pattern ranked above another — the chapter treats them as a checklist, not a hierarchy of severity); terminal larger than any single module (the convergence is the claim).
[P] Flat vector, Okabe-Ito: all five patterns and terminal in #D55E00 (the blocking/negative family — this is a hazard taxonomy); structural arrows neutral gray; module fills white; 1 pt strokes (terminal 1.5 pt); dashed stroke reserved exclusively for the extrapolated fifth pattern; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no severity ordering cues (no size gradient, no numbering badges — checklist, not ranking); no product logos or photo-solver app imagery (the chapter's photo-solver example is a category, not a target — keep it in prose); no green elements anywhere (nothing in this figure is protective); no human figures; no skull/warning-triangle melodrama; no sixth module; no crossing arrows; no icons requiring cultural reading (mascots, emojis); no gradient fills; no drop shadows; no dashed strokes on any module except the fifth.

**BLOCK 3 — NEGATIVE PROMPT:**
severity ranking numbers, size-graded modules, app logos, smartphone screenshots, mascot characters, skull icons, warning triangles, emoji, green accents, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 5 — Cognitive Debt: A Candidate Mechanism, Held at Its Weight (rank: Supplementary; heuristic: VG)

**Concept (one sentence):** In the Kosmyna et al. preprint, EEG functional connectivity scaled inversely with external support — Brain-only strongest and most distributed, Search intermediate, LLM weakest — a single-source, small-n candidate neural mechanism that earns attention only through convergence with independent behavioral evidence.
**Figure type:** structural schematic (three-condition ordinal gradient; deliberately modest visual rhetoric)

**Cognitive Load Check:** Three condition panels with a simple density gradient, one support-level axis cue, one prominent provisional-status frame. Five components. Single pass. Pass — and the figure must *feel* lighter than Figures 1–4; visual weight is an epistemic claim here.

**Data integrity note:** MANDATORY CAPTION FLAG — this is the chapter's own teaching: n=54 (~18/group), crossover n=18; preprint with a published critical commentary; EEG connectivity is an engagement proxy, not a learning outcome; authors themselves disclaimed "brain damage" framings; peer-reviewed venue [verify] per the chapter. Caption template: "Single-source preprint (Kosmyna et al., arXiv:2506.08872); ordinal pattern only; engagement proxy, not a performance endpoint; shown for convergence with behavioral findings, not as standalone evidence." No numbers exist in the chapter to chart — the figure encodes ordering only, and must visibly encode its own provisional status (dashed frame).

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector schematic, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels. Enclose the entire composition in a single dashed neutral-gray rounded-rectangle frame at 1 pt, signaling provisional status. Inside, arrange three equal square panels in a horizontal row. In each panel, draw the same abstract node-and-link motif: eight small circular nodes in fixed identical positions connected by thin arcs — never a brain silhouette. In the left panel, render the connecting arcs dense and dark: roughly twelve arcs in solid strong blue spanning the full node field. In the middle panel, render roughly seven arcs in lighter blue, shorter and more local. In the right panel, render only three or four pale, short arcs, leaving most nodes unconnected. Below the three panels, draw one thin horizontal axis arrow in orange pointing rightward, with three small evenly spaced step-up rectangles above it growing left to right, indicating increasing external support across the panels. Keep everything flat, sparse, and visually quiet, with 1 pt strokes and wide margins.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed ordinal pattern only, 5 components: three conditions (Brain-only, Search, LLM) as identical node fields differing only in arc density/extent (most distributed → intermediate → weakest — the chapter's exact ordering); external-support axis increasing rightward; dashed provisional frame around the whole figure (single-source status, chapter-mandated calibration). Arc counts are arbitrary illustrative quantities — caption-flag as schematic; no published values are depicted.
[O] Three equal panels, left to right = increasing external support, decreasing connectivity; identical node positions across panels so only the arcs vary; support axis below; dashed frame outermost. Visual weight deliberately subordinate to the chapter's behavioral figures.
[P] Flat vector, Okabe-Ito: connectivity arcs #0072B2 family (strong → pale, never a rainbow scale — one hue, varying tint and count); support axis #E69F00 (secondary); nodes neutral gray; dashed frame neutral gray; 1 pt strokes; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no brain silhouettes, head outlines, or EEG-cap imagery (the authors' own FAQ disclaims "brain scan" framing — anatomical imagery imports it); no lightning bolts or electricity clichés; no numeric values or percentages (none exist in the chapter); no red/vermilion anywhere (this figure makes no harm claim — it shows an engagement gradient); no rainbow or heatmap color scales; no fourth panel (the crossover session is prose-only — depicting it would overweight an n=18 sub-result); no solid outer frame (the dashed frame is the epistemic status); no glow effects; no human figures; no laptop/phone icons; no drop shadows; no gradient backgrounds.

**BLOCK 3 — NEGATIVE PROMPT:**
brain silhouettes, head outlines, EEG caps, electrodes, lightning bolts, glowing effects, heatmaps, numeric values, fourth panel, laptop icons, phone icons, solid heavy frame, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

## Video candidate pass

- **Figure 1 — 64% vs. 30%: STATIC SUFFICIENT.** A two-value endpoint comparison; no transition, no cycle. The temporal story lives in Figures 2 and 3.
- **Figure 2 — Rational Shortcut Loop: VIDEO CANDIDATE** (criterion: cyclical + 3+ causal stages: stuck → choose B → progress → stuck again → policy accumulation). A 25–30 s looping animation that runs the fork once (both paths shown, B chosen), then accelerates the loop — each successive cycle faster, the delayed-cost diamond growing slightly each pass while the wedge thickens — makes the chapter's core claim (individually rational, cumulatively ruinous) perceptible as tempo. Format: 2D flat-vector loop animation, seamless cycle, escalating cadence, no narration dependency.
- **Figure 3 — Escalation Curve: VIDEO CANDIDATE** (criterion: 3+ causal stages / temporal accumulation). A draw-on animation of the curve across twelve weeks qualifies, but it animates a consequence rather than a mechanism, and its data-integrity flags (schematic shape, working paper) argue against giving it motion's added authority.
- **Figure 4 — Five Patterns: STATIC SUFFICIENT.** Taxonomy; no state change.
- **Figure 5 — Cognitive Debt: STATIC SUFFICIENT.** A calibration exercise; animation would add exactly the rhetorical weight the chapter instructs us to withhold.

**Close: 2 candidates, ONE recommended — Figure 2.** Rationale: the decision loop is the chapter's mechanism and the only concept here where time is constitutive rather than incidental — the entire argument is that the catastrophe exists only in repetition, which a static figure can assert but only a loop running at escalating tempo can demonstrate. Figure 3's animation would spend motion-budget on a schematically reconstructed curve from a working paper; Figure 2's spends it on settled decision-architecture logic.
