# CAJAL Figure Intelligence Report — Chapter 4: Reading the Evidence

*Generated 2026-06-07 · /scan silent · Source: chapters/04-reading-the-evidence.md*

## Detection summary

| # | Concept zone | Heuristic trigger | Rank | Figure type |
|---|---|---|---|---|
| 1 | The 20-in-800 evidence state (Stanford SCALE census) | PQ — verified proportional quantity; the chapter's reorganizing number, never depicted | Critical | Proportional unit chart with magnified inset |
| 2 | Four-endpoint distinction + Bastani sign flip (+48% / −17%) | PQ + MC — verified effect pair that disagrees in sign; four-step measurement sequence | Critical | Diverging bar pair on a measurement timeline |
| 3 | Claim-autopsy taxonomy (interaction design / outcome / borrowed) | MC + VG — three-pile sort with per-pile verification routes; structural claim shown only in prose | Important | Classification flowchart |
| 4 | Three-bucket decision discipline + risk-asymmetry tiebreak | MC — sequential gated decision with burden-of-proof flip | Important | Decision flowchart with blocking terminal |
| 5 | Cohen vs Kraft effect-size recalibration | PQ + VG — verified published thresholds; the same number reads differently under two benchmark systems | Supporting | Dual zero-anchored benchmark band |

Existing author-planned tables (four-endpoint classification table at line 32; vendor-claim deconstruction table at line 62) are complementary, not duplicated: Figure 2 visualizes the sign flip the endpoint table can only list, and Figure 3 visualizes the sorting *procedure* the deconstruction table records the *output* of.

## Density recommendation

Main expository text runs ~3,500 words across seven sections (opening case, SCALE census, endpoints, effect-size fluency, vendor deconstruction, durability gap + three buckets, Priya case). **Recommend 5 figures: 2 Critical, 2 Important, 1 Supporting** — one figure per ~700 words of argumentative text, at the upper-middle of the series band. This is the book's epistemology chapter; its claims are mostly proportional and procedural, which is exactly the territory where figures outperform prose. Do not add a sixth figure for the LAUSD/AllHere case: its dollar figures are explicitly "as reported," and the PQ rule forbids charting unverified numbers — the case works as narrative.

## Figures

### Figure 1 — The Evidence-State Map: Twenty Causal Studies Inside Eight Hundred (Critical; PQ)

**Concept sentence.** Of 800+ academic studies of AI in K-12 education, only ~20 rigorously measure causal impact — the proportional fact the chapter says should reorganize how the reader reads everything else, and which a unit chart makes visceral in a way "about 20 of 800" never will.

**Figure type.** Proportional unit chart (waffle grid) with magnified inset [standard library: proportional quantity — unit grid + detail callout].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector unit chart depicting a small verified subset inside a large field of studies. Draw a rectangular grid of 800 small uniform squares arranged forty wide by twenty tall, evenly spaced, each square identical in size so that area is exactly proportional to count. Render the full field of squares in pale blue. Within the grid, fill exactly twenty squares in deep saturated blue, clustered in one corner region rather than scattered, so the subset reads as a coherent core. From that corner, extend two thin straight connector lines outward to a separate magnified inset panel at the right: a clean rectangular frame containing the same twenty deep-blue squares enlarged, arranged five wide by four tall, with generous white space around them. Keep the connector lines straight and unobtrusive. Maintain strict alignment of all grid rows and columns. Use only two values of blue plus white background. All strokes hairline-thin and uniform. Flat fills, no outlines on individual squares beyond a faint white gap between cells. Composition horizontal, grid occupying the left two-thirds, inset the right third.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm single-column width, 300 DPI, vector, white background, horizontal composition.
- **[C]** Confirmed content (Stanford SCALE 2026, as reported in chapter): 800-unit field; 20-unit causal core; magnified inset of the core. Components: (1) 40×20 unit grid, (2) 20 highlighted causal cells, (3) inset panel, (4) connector pair. 4 components — under cap. The chapter's update ("repository has since passed 1,100 papers without the causal core growing proportionally") is NOT depicted — a moving number; carry it in the caption as text, flagged "repository count as of publication."
- **[O]** Grid left two-thirds, inset right third; connectors run grid-corner → inset frame (→ = magnification reference, the only arrows present). Proportional Ink: every unit = 1 study; zero-anchored by construction (counts are areas; no axis to truncate).
- **[P]** Field mass #56B4E9 at 35% tint (anchor, background population); causal core #0072B2 full saturation (anchor, the evidentially load-bearing subset); connectors #0072B2 at 1pt. No text labels anywhere in the vector.
- **[E]** Exclude any third category coloring (descriptive vs perceptual vs correlational splits are not given as verified counts — depicting them fabricates proportions); exclude the 1,100 figure from the graphic; exclude scattered placement of the 20 (reads as random sampling, which misstates the census); exclude pie/donut treatment (angle encoding obscures the 2.5% ratio).

**BLOCK 3 — NEGATIVE PROMPT**

> pie chart, donut chart, scattered highlighted cells, three or more colors, percentage symbols, numeric annotations, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check (graduate LX designer).** One ratio, two colors, one magnification. Germane load only: the reader's single takeaway — the field is 40× thinner than its publication volume — is the figure's only message. Pass.

---

### Figure 2 — Four Endpoints, One Sign Flip (Critical; PQ + MC)

**Concept sentence.** "The AI improved learning" can mean four different measurements taken at four points in a sequence — and the Bastani RCT proves the first two can disagree in sign within the same condition (+48% assisted, −17% unassisted), which means assisted-only evaluation is structurally incapable of detecting a crutch.

**Figure type.** Diverging bar pair on a measurement-sequence schematic [standard library: zero-anchored diverging bars + process timeline].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector chart combining a measurement timeline with two diverging bars. Across the lower portion, draw a thin horizontal timeline running left to right, marked by four evenly spaced circular station nodes. Above the first station, draw a vertical bar rising from a clearly ruled horizontal zero baseline to a height representing forty-eight units, filled in light blue. Above the second station, draw a vertical bar descending below the same zero baseline to a depth representing seventeen units, filled in vermillion orange — bar heights exactly proportional, sharing one baseline so the sign reversal is unmistakable. Above the third and fourth stations, draw two empty dashed rectangular outlines of modest equal height in light gray, unfilled, signaling measurements not yet taken. Between station one and station two on the timeline, place a small vertical break symbol — two short parallel slashes — marking the point where the tool is withdrawn. Single forward arrowhead at the timeline's right end. All strokes uniform hairline weight, flat fills, generous white space, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal.
- **[C]** Confirmed: Bastani et al. 2025, +48% assisted / −17% unassisted (verified, chapter spine). Components: (1) timeline with 4 endpoint stations, (2) +48 bar, (3) −17 bar, (4) zero baseline, (5) withdrawal break mark, (6) two dashed empty frames (transfer, retention). 6 components — at cap, no split needed. The empty transfer/retention frames are an *inference-labeled* depiction of the chapter's claim that the retention column is "essentially empty across the field" — caption must say so explicitly. Do NOT plot LearnLM's +5.5pp in the transfer slot: different study, different scale; co-plotting fabricates a comparison the literature never ran.
- **[O]** Timeline lower band, left → right = measurement sequence (assisted → unassisted → transfer → retention); → = temporal order only. Bars rise/fall from one shared zero baseline directly above stations 1–2. Withdrawal break sits between stations 1 and 2 — the causal hinge. Proportional Ink: 48:17 height ratio exact; zero-anchored shared baseline mandatory.
- **[P]** Assisted bar #56B4E9 (anchor — a product metric, not a good); unassisted deficit bar #D55E00 (blocking — the harm signal); timeline and stations #0072B2; empty frames neutral 40% gray dashed; baseline black 1pt. No text labels.
- **[E]** Exclude truncated or dual axes; exclude plotting engagement/satisfaction as a third bar (chapter says they are not learning endpoints — charting them beside real endpoints launders them); exclude any retention-slot data (the field has none; an empty frame is the honest mark); exclude green for the +48 (it is not a positive finding — it is the seduction).

**BLOCK 3 — NEGATIVE PROMPT**

> truncated axis, broken axis, separate baselines, third data bar, filled transfer or retention bars, percentage labels, numerals, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Two bars, one baseline, one break mark, two honest blanks. The sign flip carries the entire intrinsic load; nothing decorative competes. The dashed empties add one extra concept (absence-as-data) the caption must cash out. Pass.

---

### Figure 3 — The Claim Autopsy: Three Piles, Three Verification Routes (Important; MC + VG)

**Concept sentence.** Every sentence on a vendor page sorts into exactly one of three piles — interaction design claim, outcome claim, borrowed evidence — and each pile licenses a different, differently priced verification route (use the product; demand causal evidence and tier it; trace the citation to its true product class).

**Figure type.** Classification flowchart [standard library: single-sorter three-branch flowchart with action terminals].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector flowchart depicting a document being sorted into three streams, each ending in a distinct verification action. At the left, draw a rectangle with a folded corner representing a source document, containing three or four thin horizontal placeholder rules. One arrow leads right from the document into a diamond-shaped sorting node. From the diamond, three arrows fan rightward to three parallel horizontal lanes. Top lane: a bright green rounded rectangle, then an arrow to a terminal icon of a magnifying glass over a small gear, signifying direct hands-on testing. Middle lane: an orange rounded rectangle, then an arrow to a terminal icon of a four-step tier pyramid with only the upper steps emphasized, signifying demand for ranked causal evidence. Bottom lane: a vermillion rounded rectangle, then an arrow to a terminal icon of a return-curved arrow pointing back toward a different small document, signifying tracing a citation back to its true source. Keep lanes evenly spaced, arrows straight and single-headed, all strokes uniform hairline weight, flat fills, white background, horizontal composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal, three-lane.
- **[C]** Confirmed (chapter's own taxonomy): three claim categories with three verification routes; ESSA tiering attaches to the outcome lane only. Components: (1) source document, (2) sorter diamond, (3–5) three category nodes, (6–8) three verification terminals. 8 components — at cap; if the renderer crowds, split the ESSA tier pyramid into a companion micro-figure ("Figure 3b — the four ESSA tiers as steps") rather than shrinking lanes.
- **[O]** Left → right = procedure order; → = "proceeds to." Lanes strictly parallel, equal height, to assert category equality (no pile is dismissible — the chapter's Mentora lesson is that the design-claim pile nearly got misfiled). Tier pyramid drawn 4 steps, top two steps full-saturation, bottom two pale — the chapter's claim that most products cluster at Tiers 3–4.
- **[P]** Interaction-design lane #009E73 (active — cheaply verifiable today); outcome lane #E69F00 (secondary — requires evidence that usually doesn't exist); borrowed-evidence lane #D55E00 (blocking — route back, do not credit); document and sorter #56B4E9/#0072B2 (anchors). 1pt strokes. No text labels.
- **[E]** Exclude any percentage split among piles (no verified distribution exists); exclude a fourth "true/false" branch (the taxonomy is about claim *kind*, not truth value); exclude rendering the borrowed lane as a trash bin (borrowed evidence is informative about the adjacent class — it is rerouted, not discarded).

**BLOCK 3 — NEGATIVE PROMPT**

> trash can icons, checkmark and X verdicts, unequal lane sizes, branching beyond three lanes, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** One sort, three routes, three terminals. The graduate reader already met all three piles in prose; the figure's job is making the *procedure* rehearsable before the Priya case asks them to run it. Pass.

---

### Figure 4 — The Three-Bucket Discipline and the Burden-of-Proof Flip (Important; MC)

**Concept sentence.** Any proposed design decision passes through two evidence gates — causal direction established? locally pilotable with an unassisted endpoint? — and where both fail and harm is unmeasurable on pilot timescales, risk asymmetry flips the burden of proof onto the feature: decline.

**Figure type.** Decision flowchart with blocking terminal [standard library: two-gate decision tree].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector decision flowchart with one entry, two diamond gates, and three terminals. At top center, draw a small rounded rectangle as the entry node. An arrow descends to the first diamond gate. From this diamond, one arrow exits right to a green circular terminal containing a simple forward-check motif. The diamond's other arrow descends to a second diamond gate. From the second diamond, one arrow exits right to an orange circular terminal containing a small flask or measurement-vial motif. The second diamond's remaining arrow descends to a final small square node representing an asymmetry test: inside it, draw a tilted balance beam with one pan visibly heavier. From the asymmetry node, a short connector ends in a flat perpendicular stop bar — a blunt T-shaped inhibition terminal in vermillion — rather than an arrowhead. Keep the spine vertical, the two affirmative exits horizontal and parallel, all strokes uniform hairline weight, flat fills, generous white space, vertical composition.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, vertical.
- **[C]** Confirmed (chapter's own framework): gate 1 = causal direction established + low/symmetric error cost → decide; gate 2 = suggestive evidence + unassisted-endpoint pilot feasible → pilot with measurement; residual + asymmetric unmeasurable risk → decline. Components: (1) entry, (2) gate 1, (3) decide terminal, (4) gate 2, (5) pilot terminal, (6) asymmetry node, (7) decline stop. 7 components.
- **[O]** Vertical spine = descending evidence strength; → = "proceeds to"; the decline terminal uses ⊣ (flat stop bar, not arrowhead) — inhibition semantics: the feature is blocked, not routed. The tilted balance inside node 6 is the risk-asymmetry tiebreak: compounding irreversible harm outweighs cheap foregone convenience.
- **[P]** Decide terminal #009E73 (active); pilot terminal #E69F00 (secondary — conditional path); decline stop bar #D55E00 (blocking); gates and entry #56B4E9/#0072B2 (anchors); balance beam #0072B2. 1pt. No text labels.
- **[E]** Exclude a loop from decline back to entry (the chapter does not promise re-entry; Exercise 8 treats that as an open challenge); exclude equal-pan balance (symmetry would erase the argument); exclude percentage weights on branches (no verified base rates for bucket membership).

**BLOCK 3 — NEGATIVE PROMPT**

> arrowhead on the decline terminal, feedback loops, balanced scale pans, probability annotations, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Two binary gates and one tiebreak; matches the worked Priya disposition exactly (her Mentora lands at terminal 5). The ⊣ stop bar is the figure's one nonstandard element and the caption should gloss it once. Pass.

---

### Figure 5 — The Same Effect, Two Rulers: Cohen vs Kraft (Supporting; PQ + VG)

**Concept sentence.** The identical effect size reads "small" on Cohen's never-field-derived ruler and "large" on Kraft's education-specific one — and the Cognitive Tutor's ≈0.20 at-scale result flips from pathetic to impressive depending on which ruler the reader is holding.

**Figure type.** Dual zero-anchored benchmark band [standard library: paired horizontal scale bands with shared axis].

**BLOCK 1 — Illustrae paste**

> Create an unannotated vector chart of two horizontal benchmark bands sharing one zero-anchored scale. Draw a single horizontal axis line running left to right from a clearly marked zero origin tick to a maximum at the far right, with thin unlabeled ticks at proportional positions for five hundredths, two tenths, five tenths, and eight tenths of the full span. Above the axis, render the first band as a horizontal strip divided at two tenths, five tenths, and eight tenths into four segments of stepped blue intensity, palest at left, deepest at right. Below the axis, render the second band as a strip divided at five hundredths and two tenths into three segments of stepped orange intensity, palest left, deepest right — its deepest saturation beginning where the upper band is still pale. Drop two thin vertical reference lines through both bands: one at the two-tenths position, one at just under eight tenths, each topped by a small pink diamond marker. Uniform hairline strokes, flat fills, exact proportional spacing, horizontal composition, white background.

**BLOCK 2 — FULL SCOPE**

- **[S]** 89mm, 300 DPI, vector, white background, horizontal.
- **[C]** Confirmed thresholds: Cohen 0.2 / 0.5 / 0.8; Kraft <0.05 small, 0.05–0.20 medium, >0.20 large (Kraft 2020, verified). Reference markers: ≈0.20 (Pane et al. 2014 Cognitive Tutor year two, verified) and ≈0.79 (VanLehn 2011 human tutoring, verified). Components: (1) shared zero-anchored axis, (2) Cohen band, (3) Kraft band, (4) threshold ticks, (5–6) two reference markers. 6 components.
- **[O]** Single shared axis = single reality; two bands = two interpretive rulers. Marker at 0.20 lands in Cohen's palest segment and Kraft's deepest simultaneously — the flip is the figure. Proportional Ink: linear scale, zero origin, no truncation; segment widths exactly proportional to threshold intervals.
- **[P]** Cohen band: #0072B2 at 4 stepped tints (sequential single-hue, not rainbow); Kraft band: #E69F00 at 3 stepped tints; reference markers #CC79A7 (composite — observed results being read against both rulers); axis black 1pt. No text labels; the caption carries the numbers.
- **[E]** Exclude the contested 0.40 hinge as a third band (the chapter presents it as an argument, not a benchmark — caption may mention it, the vector may not assert it); exclude the "36% below 0.05" distribution histogram (verified as a sentence, but layering a distribution onto benchmark bands doubles the figure's intrinsic load — Kraft's distributional motivation belongs in the caption); exclude improvement-index percentile conversion (a second unit system in one graphic).

**BLOCK 3 — NEGATIVE PROMPT**

> third benchmark band, histogram overlay, percentile scale, logarithmic spacing, numeric tick labels, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

**Cognitive Load Check.** Two bands, one axis, two markers — directly serves Exercise 4, which requires students to defend funding choices "using Kraft, not Cohen." Sequential tints stay within two hues; no scale gymnastics. Pass.

---

## Video candidate pass

Criteria applied: transition-mechanism · 3+ causal stages · cyclical return-to-start · below-observation.

**Candidate 1 — The Withdrawal Sequence (the sign flip in motion).** Learner practices with the tool (assisted performance climbing) → tool withdrawn → unassisted measurement → the bar that was rising turns out to have been borrowing height from the tool. Transition mechanism: yes — the flip *happens at* the withdrawal event, which a static figure can only mark with a break symbol. 3+ causal stages: practice → externalization of effort → withdrawal → deficit revealed. Below-observation: yes — pilot reports never run the withdrawal stage, which is exactly the chapter's complaint. Builds directly on Figure 2.

**Candidate 2 — The Claim-Autopsy Pipeline.** A vendor sentence travels: extraction → sorting → endpoint labeling → tier tagging → disposition. 4 causal stages and genuinely procedural, but no hidden mechanism — every stage is human-visible paperwork; animation adds sequence, not revelation.

**Candidate 3 — Evidence vs Marketing Divergence.** Two curves over two decades: evidence maturing slowly while marketing visibility spikes inverse to it (the Product A/B opening). Temporal, but two-stage and essentially a comparison; also the visibility curve has no verified data series, so motion would imply quantification the chapter never makes.

**Recommended: Candidate 1.** It animates the chapter's single most load-bearing claim — that assisted and unassisted endpoints can disagree in sign — and the disagreement is intrinsically temporal: the deficit exists *during* assisted practice but is observable only *after* withdrawal, which is the definition of below-observation. Verified anchor numbers (+48/−17) keep the animation honest, and the same asset previews Chapter 6's fading material, where designed withdrawal becomes the intervention rather than the test.
