# CAJAL Figure Intelligence Report — Chapter 15: The Full Integration

*Generated 2026-06-07 · /scan silent*

## Detection summary

The capstone chapter is structural rather than evidential — its figures depict document architecture and argument anatomy, not findings. (1) The chapter carries its own `<!-- DIAGRAM -->` placeholder: **the specification as a decision-argument spine** with fourteen branches ending in filled (guardrailed) or open (open-question) circles, §13/§14 highlighted. Fourteen branches breaks the 6–8 component cap; the scan resolves this by clustering the fourteen sections into four argument arcs plus the two no-vendor-carries sections — Critical figure. The placeholder's "highlighted in red" is honored with Okabe-Ito vermillion #D55E00 (no green anywhere in the figure, so no red-green conflict). (2) **The decision trace** — need → evidence → designed/declined/deferred → how-we-know — is the document's atomic unit, a clean 4-step MC chain with a 3-way branch, undepicted. (3) **The declined-feature dossier** — steelman → evidence → harm pathway → reopen condition — with the harm pathway itself an interior 4-step causal chain (trust miscalibration → reduced verification → flattened reliance curve → concentrated deficit); the Study Buddy worked example makes this the chapter's emotional center — Important. (4) **The documentation lineage** — safety case / model card / datasheet / system card → integration specification, with the withdrawal claim as the element no ancestor carries — a genealogy with a deliberate gap, Important and caption-flagged (lineage claim, [verify] pending on Mitchell/Gebru/Madaio). (5) The **compliance-theater test** (implementable? absence detectable?) is a 2-question gate — small, Supplementary, cut-first. The defense run-sheet `<!-- TABLE -->` stays a table. The closing Bastani table reprise is already a table and belongs to Chapter 14's chart vocabulary — no new figure; the book should not close on a duplicate.

PQ findings: no chartable numbers native to this chapter. The Evidence Box numbers are inherited (charted in Ch14 or flagged [verify]/[contested]); "~20 high-quality causal studies in 800+ papers" is a synthesis estimate — caption-grade, not chart-grade. Nothing to chart; correct for a chapter about argument structure.

## Density recommendation

**4 figures** (1 Critical, 2 Important, 1 Supplementary) + the optional compliance gate only if layout wants a small inline glyph. The chapter already ships an Evidence Box table, a reprise table, and a run-sheet table placeholder; more than four figures would crowd the closing register. Order: Fig 1 (spine) replacing the existing placeholder at the cold open; Fig 2 (decision trace) at the "argument, not a binder" paragraph; Fig 3 (dossier anatomy) beside the Study Buddy blockquote; Fig 4 (lineage) at the ancestors section; Fig 5 (compliance gate) optional at the Madaio section.

## Figures

### Figure 1 — The specification as one argument: spine, arcs, and the two sections nobody requires (Critical; VG + MC)

**Concept:** "The document is not a binder of artifacts. It is one argument with fourteen exhibits." A central spine — the learning claim, *what the student can do without the AI* — with the fourteen sections as evidence branches, each terminating in either a closed (guardrail in place) or open (open question, measurement attached) state, and the negative specification and open questions set apart as the sections that make the rest believable. Fourteen literal branches exceed the component cap; the figure clusters them into the four argument arcs the chapter's walkthrough implies (claim & evidence posture; interaction & adaptivity design; boundaries & assessment; learner side & evaluation), four branches per arc rendered as repeated sub-twigs within one visual unit.

**Type:** Radial-spine argument diagram (vertical spine, clustered branch arcs, terminal-state coding).

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A structured argument diagram in flat unannotated vector, transparent background, no text. A bold vertical 2pt deep-blue spine runs down the center of an 89mm field, anchored at top by a single deep-blue circle — the claim everything serves. From the spine, four horizontal arc-clusters branch alternately left and right, each cluster a thin 1pt bracket fanning into a tight group of small terminal circles, most filled solid sky blue (settled, guardrailed) with a few left as open 1pt rings (open, measurement attached) — roughly eleven filled and three open across the whole figure. Below the lowest cluster, two distinct branches diverge from the spine's foot, set apart by extra whitespace and drawn in vermillion: one ending in a solid vermillion octagon — the features declined — and one ending in a larger open vermillion ring with a small solid teal dot waiting just outside it — the open questions, each with its measurement standing by. The spine visibly continues through and past these two, terminating in a small downward arrowhead. Flat Okabe-Ito color, strict bilateral rhythm, generous spacing, no decoration of any kind.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm width, full-page-height tolerance, 300 DPI, vector, transparent.
- **[C]** 8 components: claim anchor; spine; 4 arc-clusters (one repeated unit); filled-terminal set; open-terminal set; declined-features branch (octagon); open-questions branch (ring + waiting measurement dot); terminal arrowhead. Inference labeled: the four-arc clustering is **CAJAL's grouping of the chapter's fourteen sections, not the chapter's own taxonomy** — caption states the clustering is editorial and the annotation layer names the fourteen sections within the brackets.
- **[O]** Vertical spine, top-down argument order matching the instructor's walkthrough; branches alternate sides; closed vs. open terminals carry the "done means accounted for, not closed" thesis; the two vermillion branches sit last and apart — placement encodes "the sections nobody requires."
- **[P]** spine and claim #0072B2 (anchor); settled terminals #56B4E9; open terminals #56B4E9 open ring; declined branch #D55E00 (blocking — honoring the placeholder's red callout, Okabe-Ito-safe); waiting measurement #009E73 (active); brackets neutral gray. 2pt spine, 1pt elsewhere, no text.
- **[E]** Serious exclusions: no per-section icons (fourteen icons is clip-art death); no page counts or "31 pages" numerals; no Study Buddy content (Figure 3's job); no binder/folder imagery — the figure's entire point is the negation of the binder.

**BLOCK 3 — NEGATIVE:** binder, folder, or document-stack imagery, tree-of-life literalism, mind-map bubbles, fourteen distinct icons, section numerals, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components with the four clusters as one repeated gestalt; the eye path is spine-down to the two vermillion outliers, which is exactly the chapter's reading order. Filled/open distinction is shape-redundant (solid vs. ring), colorblind-safe. PASS.

---

### Figure 2 — The decision trace: the document's atomic unit (Important; MC)

**Concept:** Every section reduces to one repeatable unit: what the learner needed to be able to do → what the evidence said → what was designed, declined, or deferred → how you will know. Four steps, with step three a three-way branch and step four either an endpoint pointer or an honest "no endpoint — open." A reviewer enters at any touchpoint and reaches evidence in two hops — the trace is the hop structure.

**Type:** Linear process chain with one 3-way branch and a verification loop-back.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A horizontal four-station process chain in flat unannotated vector, transparent background, no text. Station one: a deep-blue circle — the capability the learner needed. A 1pt arrow leads to station two: a sky-blue square sitting on a small stack of two thin underlying plates — the evidence consulted, with its sources beneath it. A second arrow reaches station three, the decision fork: a neutral-gray diamond from which three short branches exit — upward to a solid teal-green rounded rectangle (designed), straight ahead to a solid vermillion octagon (declined), downward to an open orange ring (deferred). From all three branch terminals, thin 1pt lines reconverge into station four at far right: a small deep-blue measurement marker — the same survey-marker glyph family as the evaluation chapter — standing for how-you-will-know. From the declined octagon, one additional thin dotted teal line arcs forward to touch station four as well: even a "no" carries its reopen condition. A faint 15% gray return arc runs under the whole chain from station four back to station one. Flat color, even spacing, immaculate alignment.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 8 components: need circle; evidence square with source plates; decision diamond; designed terminal; declined octagon; deferred ring; endpoint marker; reopen dotted arc (+ faint return arc counted with it as the loop gesture). No inferences — the trace anatomy is quoted chapter structure.
- **[O]** Left-to-right; → between stations; three-way fan at the diamond with reconvergence (every path, including no, ends at a measurement); dotted arc = reopen condition; return arc = the trace is re-enterable at any point.
- **[P]** need #0072B2; evidence #56B4E9; designed #009E73 (active); declined #D55E00 (blocking); deferred #E69F00 (secondary); endpoint #0072B2; reopen arc #009E73 dotted. Diamond neutral. 1pt, no text.
- **[E]** Serious exclusions: no specific DataWise decisions populated into the stations (the figure is the unit, not an instance); no "two hops" counter glyph (caption can say it); no file-name iconography.

**BLOCK 3 — NEGATIVE:** flowchart software aesthetics, swimlanes, checkmark/X glyphs, gavel or scale-of-justice imagery, document icons, text labels, words, gibberish letters, numerals, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components, one fork, one reconvergence — reads as a single sentence. The reconvergence (all three outcomes end in measurement) is the figure's argument and is structurally unmissable. PASS.

---

### Figure 3 — Anatomy of a documented "no": the declined-feature dossier (Important; MC + VG)

**Concept:** The four-part dossier — steelman → evidence for declining (with endpoint types) → harm pathway → reopen condition — instantiated by the Study Buddy decline. The harm pathway is itself a four-link causal chain (trust miscalibration → reduced verification → flattened reliance curve → unassisted deficit concentrated in the comforted learners). The reopen condition is what separates a falsifiable position from a mood — the figure must end open, not closed.

**Type:** Nested anatomy schematic — one dossier container with four interior strata, the third stratum exploded into a mini causal chain, the fourth holding an open gate.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A vertical dossier-anatomy schematic in flat unannotated vector, transparent background, no text. One tall rounded-rectangle container in neutral 10% gray holds four horizontal strata separated by 1pt dividers. Stratum one: an orange upward-pointing chevron pair cradling a small orange circle — the steelman, the feature's genuine appeal honestly elevated. Stratum two: three small sky-blue squares in a row, each sitting on a thin pedestal tick — the evidence items, each with its endpoint type beneath it. Stratum three, the tallest: a left-to-right causal micro-chain of four small vermillion circles connected by 1pt arrows, each circle slightly larger than the last, the final one twice the first's diameter — the harm pathway compounding from miscalibrated trust to concentrated deficit. Stratum four: a teal-green gate glyph — two vertical posts with the bar between them drawn lifted at an angle, visibly openable — beside a small teal measurement marker — the reopen condition, a specific study that would reverse the no. Outside the container's bottom edge, a solid vermillion octagon seals the dossier's lower-left corner like a stamp, small and final. Flat Okabe-Ito color, calm spacing, strict alignment, nothing decorative.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 8 components: dossier container; steelman chevron glyph; evidence row (one set of three); harm micro-chain (one unit of four linked circles); reopen gate; reopen measurement marker; decline octagon stamp; dividers. Inferences labeled in caption: the Study Buddy evidence base carries the chapter's own flags — Bhat & Long (AIES 2025) **[contested — pending primary-source check]**, Common Sense Media **[verify figures]**; the dossier *form* is the figure's claim, and the form is the chapter's.
- **[O]** Top-down read in dossier order; harm chain runs → with monotonic growth encoding compounding; the gate drawn open is mandatory — a closed gate would render the position as technophobia, the exact misreading the chapter forbids.
- **[P]** steelman #E69F00 (secondary — genuine appeal, honestly colored); evidence #56B4E9; harm chain #D55E00 (blocking); reopen gate and marker #009E73 (active — the live, falsifiable element); stamp #D55E00; container neutral. 1pt, no text.
- **[E]** Serious exclusions: no chatbot/persona/avatar imagery for Study Buddy (anthropomorphic cues in a figure about declining anthropomorphic cues would be self-refuting); no focus-group percentages (none verified); no n=344 (flagged contested).

**BLOCK 3 — NEGATIVE:** robot or chatbot mascots, speech bubbles, heart icons, smiley faces, prohibition-sign clichés, rubber-stamp texture, text labels, words, gibberish letters, numerals, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components, but the four strata are one container's interior and the harm chain is a single directional unit. The open gate is the terminal image — the figure ends on falsifiability, matching the prose. PASS.

---

### Figure 4 — The lineage and the gap: what no ancestor asks (Important; VG)

**Concept:** The specification's genealogy — safety case (argument-with-evidence), model cards / datasheets / system cards (intended use, boundaries, subgroup results, limitations) — and the exact point the inheritance stops: **no industry documentation template contains a withdrawal claim.** The new genre member inherits the family anatomy and adds the one element none of the ancestors carry. Caption-flag: lineage claim, sources [verify] (Mitchell 2019, Gebru 2021; safety-case practice cited from literature).

**Type:** Genealogy/comparison schematic — ancestor row with shared-anatomy slots, descendant below with one novel filled slot the ancestors show empty.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A two-generation comparison schematic in flat unannotated vector, transparent background, no text. The upper row holds three ancestor cards: same-sized rounded rectangles in pale neutral tints, each containing an identical interior anatomy of four small slot squares — three slots filled solid sky blue (use, boundaries, evaluation disclosed) and the fourth slot present in every card but conspicuously empty, drawn as a faint 1pt dashed outline only. Thin 1pt descent lines run from all three ancestors, converging into a single larger descendant card centered below. The descendant card repeats the same four-slot anatomy — three slots filled sky blue, inherited — but its fourth slot is filled with a solid deep-blue measurement-marker glyph, the survey-marker form used throughout the book's evaluation figures, and that slot alone carries a 2pt teal-green border. The empty dashed slot in each ancestor and the filled, bordered slot in the descendant occupy the identical interior position, so the eye aligns them vertically in one pass. Flat Okabe-Ito color, exact grid alignment, generous whitespace, no ornament.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 7 components: 3 ancestor cards (one repeated unit); shared four-slot interior anatomy (one set); dashed empty slots; descent lines; descendant card; withdrawal-slot marker; teal emphasis border. Inference labeled: rendering the withdrawal slot as *present-but-empty* in the ancestors is an interpretive move — the documents do not have an empty slot, they lack the construct entirely; caption states the dashed outline is the book's reading of the gap, per "no withdrawal construct anywhere in it."
- **[O]** Genealogical top-down; convergent descent lines (multiple ancestors, one heir); positional rhyme between empty and filled fourth slots carries the entire argument; no arrows beyond plain descent lines.
- **[P]** ancestor cards neutral 10–15% gray tints; inherited slots #56B4E9; withdrawal marker #0072B2 (anchor); emphasis border #009E73 (active — the live new obligation); dashed gaps neutral gray. 1pt base, 2pt emphasis, no text.
- **[E]** Serious exclusions: no logos or paper-title typography (Mitchell/Gebru flagged [verify]); no fourth ancestor for safety cases as a separate card — fold safety-case ancestry into the caption to hold the cap, since its contribution (argument-not-description) is structural rather than slot-shaped; no timeline years.

**BLOCK 3 — NEGATIVE:** family-tree foliage, scroll or certificate imagery, corporate logos, DNA helix metaphors, timeline dates, text labels, words, gibberish letters, numerals, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components built from one repeated card anatomy; the single difference (empty vs. filled fourth slot) is the figure's only variable — minimal load, maximal point. PASS.

---

### Figure 5 — The compliance-theater gate (Supplementary — cut first; MC)

**Concept:** The mechanical test that separates a guardrail from a wish: can this sentence be implemented, and could its absence be detected? Two sequential gates; failing either routes the sentence back to Pattern Card rework. Madaio et al.'s checkbox-decay finding ([verify]) is the prose anchor; the figure is just the gate pair.

**Type:** Two-gate filter schematic, inline-scale.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A small horizontal two-gate filter schematic in flat unannotated vector, transparent background, no text. At left, a loose stack of three thin neutral-gray rounded bars — candidate guardrail sentences. A 1pt arrow carries them rightward through gate one: a pair of short vertical deep-blue posts with a narrow gap — implementability. One gray bar deflects downward at the first gate, falling along a thin dotted vermillion path to a small orange ring below — returned for rework. The surviving bars continue by arrow through gate two: a second post pair in sky blue with a small detection tick centered above the gap — absence detectability. A second bar deflects down the same dotted vermillion return path. The single bar that clears both gates exits right, recolored solid teal green and seated into a small bracket frame — a buildable guardrail, locked into the specification. The two return paths merge into one loop arc that runs back beneath the gates toward the starting stack. Flat color, small scale, strict alignment, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 60mm inline tolerance (89mm standard if set as a full figure), 300 DPI, vector, transparent.
- **[C]** 7 components: candidate stack; gate one posts; gate two posts with detection tick; passing bar (recolored); bracket seat; deflection paths; return loop. No inferences — the two questions are quoted chapter mechanics.
- **[O]** Left-to-right with → only; downward deflection = failure; return loop = rework, not deletion (the Pattern Cards are the antidote, not the trash).
- **[P]** gates #0072B2 / #56B4E9; pass #009E73 (active); deflection/fail #D55E00 (blocking) with #E69F00 rework ring; candidates neutral. 1pt, no text.
- **[E]** Serious exclusions: no checkbox imagery (the figure is *against* checkboxes); no policy-document icon; no seven-defect peer-review list (table territory).

**BLOCK 3 — NEGATIVE:** checkboxes, clipboards, magnifying glasses, funnel clichés, rubber stamps, text labels, words, gibberish letters, numerals, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components, single path with two filters — trivially parsed. PASS. First cut under any density pressure.

---

## Video candidate pass

**Recommended (one): "Assembly is the last design decision" — 90s animation of Figure 1's spine assembling from the fourteen artifacts.** Open on fourteen scattered neutral cards drifting in loose chronological order — the binder state. First pass: they snap into course-week sequence and visibly fail (a reviewer probe enters and bounces — no two-hop path to evidence). Then the reorder: the deep-blue spine draws itself top-down, cards regroup into the four arcs, terminals resolve filled or open, and as the seams meet, two contradiction sparks flash at junctions (the fading schedule one file promised and another never instrumented) and persist as open rings rather than healing — recorded, not resolved. Last to attach, with deliberate delay: the two vermillion branches, the declined octagon and the open-questions ring with its waiting teal measurement dot. Close on the reviewer probe re-entering at a random touchpoint and reaching evidence in two hops. This is the chapter's thesis — a folder becoming an argument — and assembly is intrinsically temporal: it is the one capstone idea a static figure can only show the after-state of.

Runner-up (not recommended): the four canonical attacks as an animated defense exchange — better served by the run-sheet table; animating dialogue without text labels is not viable under the no-text discipline.
