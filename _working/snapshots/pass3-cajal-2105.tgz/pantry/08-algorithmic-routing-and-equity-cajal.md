# CAJAL Figure Intelligence Report — Chapter 8: Algorithmic Routing and Equity: Auditing the Personalization Layer
*Generated 2026-06-07 · /scan silent*

## Detection summary

The densest chapter scanned in this block; six figure-worthy structures confirmed in the revised text:

1. **The proxy-driven remedial feedback loop** — the chapter's load-bearing mechanism (data plan → latency/breaks → read as struggle → remedial drill → displaced higher-order work → depressed next-unit performance → more remediation), with the off-ramp failure mode (exit keyed to the loop's own estimate) as a blocked exit. The author's own placeholder calls for exactly this. MC, Critical.
2. **Bias entry points along the pipeline** (Baker & Hawn 2022): training data, proxy features, measurement/labels, representation, deployment feedback loops — five entry stages feeding two harm classes. VG.
3. **Classical tracking vs. algorithmic routing** — visible/contestable vs. invisible/continuous; the author placeholder specifies a table; the figure supplies the structural comparison the table rows describe. VG.
4. **The task-diet divergence** — identical 62% diagnostic, 40% vs. 8% higher-order share by week six, fork points at weeks two, three, four. PQ — values are stipulated worked-case numbers (DataWise 101 fiction), chartable only with an explicit "illustrative case, not empirical data" caption.
5. **The DEWS false-alarm proportion** — 74% wrong among flagged students; verified (The Markup, April 2023, per chapter). PQ, clean to chart. The subgroup skew (falls disproportionately on Black and Hispanic students) has **no published magnitude in the chapter** — directional caption only, never a split bar.
6. **The counter-pattern set with theater twins** — five counter-patterns, each carrying a named failure mode ("the failure mode column is not decoration"). VG.

**Numbers requiring caption-flag handling:** the Ofqual ~40% downgrade figure carries [verify against BBC/Ofqual primary reporting] — it appears in no figure; if editors want it visualized later it must wait on verification. The exercise-5 base-rate arithmetic (20% base rate implication) is a student computation, not a chapter claim — excluded. The TNTP "seven additional months" is verified-adjacent but a duration metaphor resistant to honest charting ("months of growth" is a derived equivalence) — prose carries it; no figure.

## Density recommendation

Main expository body ≈ 3,600 words across six sections, each section housing one of the structures above. **Six figures** — the chapter is at the top of the band and earns it: this is the book's equity spine, the harm is explicitly "invisible at the level of any single decision," and invisibility-made-visible is the precise job of figures. If production forces a cut, Figure 6 (counter-pattern twins) folds back into the author's planned table; cut nothing else.

## Figures

---

### Figure 1 — The loop with no exit (Critical; MC)

**Concept:** The proxy-driven remedial feedback loop, end to end, with the off-ramp failure mode as a blocked exit: the system is locally correct at every node and unjust around the cycle. "No demographic field at any node; disparity in output anyway."

**Type:** Closed-cycle mechanism diagram with one blocked exit.

**BLOCK 1 — Illustrae paste:**
A closed-loop mechanism diagram rendered as a flat, unannotated vector illustration. Six flat rounded-rectangle nodes arranged in a clean clockwise hexagonal cycle, connected by single-headed 1pt orange arrows that flow head-to-tail without interruption around the full ring. The first node, at the nine o'clock position, is visually distinct: an open outline in blue rather than a fill — the entry condition standing outside the system proper. The remaining five nodes are filled in muted blue. From the node at the four o'clock position, one additional arrow attempts to leave the cycle, pointing outward and down toward a small green circle outside the ring — an exit path — but this arrow is stopped halfway by a bold burnt-orange perpendicular bar, a clean T-stop. The exit arrow visibly originates from the same node the cycle's return arrow feeds, making the blockage legible as structural, not accidental. Center of the ring: empty negative space — conspicuously nothing at the hub. Flat white background, geometric precision, uniform stroke weight, no text, no icons inside nodes, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Near-square; hexagonal ring centered, exit stub lower right.
- **[C]** 8 components (at cap): (1) entry node, open outline — income-correlated connectivity condition; (2) signal node — latency and session breaks; (3) interpretation node — model reads struggle; (4) routing node — remedial drill; (5) displacement node — higher-order work displaced; (6) confirmation node — next-unit performance depressed, arrow returning to node 3 closing the loop [inference: the cycle closes at interpretation, not at entry — the connectivity condition persists outside the loop; this topology is faithful to "next unit's data duly confirms weakness"]; (7) blocked exit arrow with ⊣ bar — the off-ramp keyed to the loop's own estimate; (8) external exit target circle.
- **[O]** Clockwise circulation; → arrows head-to-tail; the ⊣ T-stop is perpendicular to the exit arrow and is the figure's only interruption. The empty hub is deliberate: no villain at the center.
- **[P]** Cycle arrows secondary #E69F00 (the running process — not "active/good," not yet "blocking"); nodes anchor #56B4E9, entry node open-stroke #0072B2; exit arrow and target active #009E73 (the legitimate escape); block bar blocking #D55E00. The only #D55E00 element is the bar — pop-out preserved.
- **[E]** Serious exclusions: no demographic icons or person figures (the chapter's point is that no demographic field exists in the system — the figure must enact that absence), no ZIP-code/map imagery, no second loop for Learner A (the divergence belongs to Figure 4), no center label or hub element.

**BLOCK 3 — NEGATIVE:**
Figure-specific: human figures or avatars, map or pin imagery, phone/desktop device icons, dollar signs, X-marks instead of the clean T-stop, arrows entering the hub, drop-shadow ring effects, more than one blocked exit. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Six nodes is the ceiling for a single cycle; the ring schema is pre-attentive, and the lone ⊣ carries the chapter's sharpest finding (the off-ramp failure mode, "live in the wild").

---

### Figure 2 — Five doors into the pipeline (High; VG)

**Concept:** Baker & Hawn's structural map — bias enters at every stage: training data, correlated features/proxies, measurement/labels, representation, deployment feedback. No protected attribute required at any door.

**Type:** Linear pipeline with five labeled-by-position entry arrows and a feedback return.

**BLOCK 1 — Illustrae paste:**
A horizontal pipeline schematic rendered as a flat, unannotated vector illustration. Five flat rectangles in muted blue sit in a left-to-right row, connected by short 1pt blue arrows — a processing pipeline. Into each of the five rectangles, one arrow descends from above at a slight uniform angle, each in burnt orange, each entering the top edge of its stage — five separate entry points, visually identical in weight, no stage exempt. The five orange arrows originate from five small orange circles floating in a loose upper band, deliberately unconnected to each other. From the fifth pipeline stage, a long 1pt orange arrow sweeps underneath the entire pipeline back to the first stage — a feedback return completing the system. At far right, the pipeline's output arrow forks into two short branches ending in two small distinct shapes: a filled pink square and a filled pink triangle — two downstream harm classes. Flat white background, orthogonal-plus-gentle-curve routing, generous vertical spacing between the entry band, pipeline, and return path, no text, uniform strokes, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Wide landscape; three horizontal bands (entry sources / pipeline / feedback return).
- **[C]** 8 components (at cap): (1) pipeline of five stages as one chained component — train data, features, labels, representation, deployment, left to right; (2–6) five entry arrows with source dots [inference: rendering the five bias mechanisms as identical arrows asserts equal visual weight, an editorial flattening of differing prevalences — labeled INFERENCE, caption should note entry points differ in mechanism and evidence base]; (7) deployment-feedback return arrow; (8) output fork to two harm glyphs (allocative square / representational triangle).
- **[O]** Left-to-right pipeline; entries top-down →; feedback return right-to-left beneath, single-headed, rejoining stage one — the only long curve permitted. Harm fork at far right, 30° spread.
- **[P]** Pipeline stages anchor #56B4E9, pipeline flow arrows anchor #0072B2; bias entry arrows and source dots secondary #E69F00; feedback return secondary #E69F00 (same mechanism class); harm glyphs composite #CC79A7. No #D55E00 — nothing here is a designed block; everything flows, which is the problem.
- **[E]** Serious exclusions: no scales-of-justice or gavel iconography, no race/income symbolic imagery, no fifth-stage explosion or alarm motif, no attempt to depict the "unknown bias territory" (an undepictable negative — caption only).

**BLOCK 3 — NEGATIVE:**
Figure-specific: justice imagery, person silhouettes, database-cylinder clichés rendered with shading, alarm/warning triangles with exclamation marks, entry arrows of varying thickness implying ranked severity, red arrows. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. The repeated entry-arrow motif is one pattern read five times, not five patterns; the fork adds the chapter's two-harm taxonomy at near-zero added load.

---

### Figure 3 — Tracks you can see, tracks you can't (High; VG)

**Concept:** Classical tracking vs. algorithmic routing — discrete, visible, contestable tracks with an assignment moment a family could fight, versus continuous, individualized, invisible tracks with no moment of assignment and no results day. "Visibility and contestability are the modern equivalents of the rights that made classical tracking fightable."

**Type:** Two-panel structural comparison.

**BLOCK 1 — Illustrae paste:**
A two-panel comparison rendered as a flat, unannotated vector illustration, panels side by side with a thin gray divider. Left panel: from a single starting dot, three thick, clearly separated horizontal paths in blue branch at one shared fork point and run parallel to the right edge — three discrete tracks. At the fork sits a prominent open green circle enclosing the branch point — a visible, bounded moment of assignment. Each track carries one small green square gate near its start — a place where the path can be contested. Right panel: from an identical starting dot, eight thin lines fan out gradually and continuously, no shared fork, each line bending individually at many small points, spreading into a smooth wedge — continuous individualized divergence. No circle marks any moment; no gate sits on any line; where the left panel's green circle would be, the right panel has only a faint dashed empty circle outline, the absence made visible. Flat white background, 1pt strokes except the three left-panel tracks at 2pt, no text, geometric precision, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape; two equal panels, shared baseline geometry so start dots align.
- **[C]** 7 components: left — (1) start dot and shared fork; (2) three discrete tracks as one component; (3) assignment-moment circle; (4) contest gates on tracks [inference: gates summarize "a placement meeting a family could fight" — labeled INFERENCE]. Right — (5) start dot; (6) eight-line continuous fan as one component [inference: eight lines chosen to read as "individualized, many" against the left's three — count is editorial]; (7) dashed empty circle — the missing assignment moment.
- **[O]** Left-to-right time in both panels; no arrowheads needed on tracks (paths, not processes) except a single small → at each panel's right edge indicating continuation. The dashed empty circle must sit at the geometric position mirroring the left panel's solid circle.
- **[P]** Tracks and fan anchor #56B4E9 (left at 2pt, right at 1pt); start dots anchor #0072B2; assignment circle and contest gates active #009E73 (the rights — the things you can act on); dashed absence outline blocking #D55E00 at 50% opacity (a removed right). No green-adjacent-to-red placement: the dashed circle sits in empty space.
- **[E]** Serious exclusions: no school-building or classroom imagery, no honors/regular/remedial ranking cues (track heights equal — the figure is about visibility, not hierarchy), no learner dots traveling the paths (Figure 4 owns trajectories), no Ofqual reference (its ~40% figure is verify-flagged).

**BLOCK 3 — NEGATIVE:**
Figure-specific: ladder or podium imagery, ranked vertical ordering of tracks, school icons, padlocks, eye icons, magnifying glasses, learner avatars, converging-then-diverging crossover lines. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Thick-three vs. thin-many is a one-glance contrast; the solid circle / dashed circle pair carries contestability without a single word.

---

### Figure 4 — Same start, different diets (High; PQ — illustrative case values)

**Concept:** The task-diet divergence: two learners, identical 62% diagnostic, diverging to 40% vs. 8% higher-order task share by week six, with fork points at weeks two (session break scored as failures), three (latency spike trips classifier), four (remediation exit keyed to its own estimate). **Verification status: stipulated DataWise 101 worked-case values — chartable under the hard rule ONLY with the caption stating these are illustrative case numbers, not study data.** This figure is the chapter's video-candidate substrate.

**Type:** Zero-anchored two-line divergence chart over six week positions.

**BLOCK 1 — Illustrae paste:**
A minimal divergence chart rendered as a flat, unannotated vector illustration. A horizontal baseline at the bottom and a vertical baseline at the left meet at a true zero origin. Six unlabeled tick positions divide the horizontal extent evenly. Two 1.5pt lines begin at exactly the same point above the first tick — visibly a single shared origin dot in dark blue — then separate: the upper line, in blue, climbs steadily to a high terminal dot at roughly two-fifths of the vertical extent; the lower line, in orange, declines shallowly to a terminal dot just above the baseline. The vertical gap between terminal dots is the figure's focal negative space. Along the lower line, three small open orange diamonds mark the second, third, and fourth tick positions — fork events where the path bent downward. Each diamond sits exactly at a visible change in the lower line's slope. No gridlines, no numeric labels, no shading between lines. Flat white background, geometric precision, generous margins, Okabe-Ito palette, zero-anchored axes drawn as plain 1pt lines.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape; vertical scale runs 0–50% with the zero baseline visible (40% and 8% plot at 0.80 and 0.16 of plot height) [inference: weekly intermediate values are not given in the text — both polylines interpolate between the stated start-equality and week-six endpoints, with slope changes at the three named fork weeks; caption must state interpolation].
- **[C]** 7 components: (1) zero-anchored axis pair; (2) shared origin dot; (3) upper trajectory polyline; (4) lower trajectory polyline; (5–7) three fork-event diamonds at weeks two, three, four.
- **[O]** Left-to-right time; lines never cross after departure; the three diamonds attach to the lower line only — every fork is a downward bend, matching the text's mechanism. Terminal dots slightly enlarged (2× line weight) to anchor the 40/8 contrast.
- **[P]** Upper line and origin anchor #0072B2; lower line secondary #E69F00; fork diamonds blocking #D55E00 outlines (decision points where harm entered); axes 60% gray. Orange line with red-orange diamonds is within-family and colorblind-safe; no green present.
- **[E]** Serious exclusions: no shaded "gap" fill between lines (dramatizes beyond the data), no learner icons at line ends, no percentage callouts in the render (caption carries 40%/8% with the illustrative-case flag), no extension past week six.

**BLOCK 3 — NEGATIVE:**
Figure-specific: area fill between lines, gridlines, numeric labels, smoothed bezier curves, more than three event markers, icons of phones or desktops at the line origins, crossing lines. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Two lines, one shared origin, three event marks. The single-origin dot does the "same starting score" work; the terminal gap does the rest.

---

### Figure 5 — Three wrong for every one right (Medium; PQ — verified value)

**Concept:** DEWS false-alarm rate: when the system predicted a student would not graduate on time, it was wrong about 74% of the time (The Markup, 2023 — verified per chapter). An icon-array proportion makes the base-rate failure physical. The disproportionate burden on Black and Hispanic students is directional in the chapter with no magnitude — caption sentence only, never a subdivided array.

**Type:** Zero-anchored icon array (50 units).

**BLOCK 1 — Illustrae paste:**
A proportion icon-array rendered as a flat, unannotated vector illustration. A neat grid of fifty identical small circles, ten columns by five rows, evenly spaced, every circle the same diameter with 1pt strokes — a population of flagged predictions. Thirty-seven of the circles, filling the grid in reading order from the top-left, are open outlines in burnt orange — predictions that proved false. The remaining thirteen circles, completing the grid at the bottom-right, are solid filled blue — predictions that proved correct. The two groups are distinguished only by fill and hue; size and spacing are uniform throughout, and no dividing line, bracket, or border separates them — the proportion must be read from the count itself. Generous white margin surrounds the grid. Flat white background, geometric precision, perfect alignment, no text, no icons beyond the plain circles, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Square; 10×5 grid, gutter equal to circle radius.
- **[C]** 2 components: (1) false-alarm subset — 37 open orange circles [inference: 74% of 50 = 37; rounding exact, no distortion]; (2) correct-prediction subset — 13 solid blue circles. Far below cap; the figure's power is its emptiness of structure.
- **[O]** Reading-order fill (top-left start) so the orange mass dominates first contact; no arrows, no flow — a census, not a process.
- **[P]** False alarms blocking #D55E00 (open stroke, white fill); correct predictions anchor #0072B2 (solid). Two colors total. No green anywhere near the orange.
- **[E]** Serious exclusions: no subdivision by race or ethnicity (no magnitudes published in the chapter — fabrication risk; the skew is a caption sentence), no student pictograms (person-shaped icons would aestheticize the harm), no second array for the 2021-internal-audit detail (prose carries it), no percentage numeral in the render.

**BLOCK 3 — NEGATIVE:**
Figure-specific: person-shaped pictograms, subdivided or color-banded subgroups, percentage numerals, pie charts, a highlight ring around any single circle, varying circle sizes. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Two visual classes, one proportion, zero structure to parse. The lowest-load figure in the chapter, deliberately — the number needs no help.

---

### Figure 6 — Every pattern has a theater twin (Medium; VG)

**Concept:** The five counter-patterns (floor constraints, visible routing, off-ramps, human-in-the-loop, co-design), each paired with its failure mode — "a counter-pattern implemented as theater is worse than none." The solid form and its hollow twin.

**Type:** Five-pair solid/hollow schematic row.

**BLOCK 1 — Illustrae paste:**
A paired-glyph schematic rendered as a flat, unannotated vector illustration. Five vertical pairs arranged in an evenly spaced horizontal row. Each pair consists of an upper glyph and a lower glyph of identical silhouette: the upper rendered solid in green with a 1pt stroke, the lower rendered as a dashed orange outline with white fill — the implemented pattern above, its hollow theater twin below, same shape, no substance. The five silhouettes differ across pairs and are simple geometric forms: a thick horizontal bar (a floor), an open eye-shaped lens made of two arcs, an arrow bending out of a small loop, a circle overlapping a square, and two overlapping rounded rectangles. Between each upper and lower glyph runs a short vertical 1pt gray connector, emphasizing that each twin derives from its original. The row sits on an implied baseline with generous spacing; no enclosing frames, no text, flat white background, geometric precision, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Wide landscape strip; five pairs at equal pitch.
- **[C]** 5 components (each solid+twin pair counted as one): (1) floor bar / symbolic floor; (2) lens / data-dump dashboard; (3) loop-exit arrow / exit keyed to the loop [inference: glyph vocabulary is invented shorthand for the five named patterns — labeled INFERENCE; typeset labels will be added in layout beneath each pair]; (4) circle-square overlap (human-in-loop) / rubber stamp; (5) overlapping rectangles (co-design) / harvested participation.
- **[O]** Top row = real, bottom row = theater; vertical connectors, no arrowheads (derivation, not flow). Strict silhouette identity within each pair is the load-bearing constraint — the *only* difference may be solid-vs-dashed-hollow.
- **[P]** Implemented glyphs active #009E73 (solid); theater twins blocking #D55E00 (dashed stroke, hollow) — green and red-orange never touch: vertical separation plus gray connectors keep them non-adjacent, and the solid/hollow double-encoding makes the figure legible in grayscale and to deutan/protan viewers without relying on the hue pair. Connectors 50% gray.
- **[E]** Serious exclusions: no theater-mask iconography, no checkmark/X pairing, no sixth pair for the efficiency objection (prose argument, not structure), no ranking or size differences among the five pairs.

**BLOCK 3 — NEGATIVE:**
Figure-specific: theater masks, checkmarks and crosses, padlock icons, thumbs up/down, size hierarchy among pairs, enclosing boxes per pair, hue-only differentiation between twin rows. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS — conditionally. Five pairs is ten glyphs; the identical-silhouette constraint and one repeated relation (solid→hollow) compress it to one rule read five times. If layout testing shows strain, this is the designated cut (content folds into the author's planned counter-pattern table).

---

## Video candidate pass

Criteria sweep:
- **Task-diet divergence over time (Figure 4 substrate, powered by Figure 1's loop):** transition-mechanism ✓ (each fork event converts a signal into a routing change); 3+ causal stages ✓ (signal → interpretation → routing → displacement → confirmation); cyclical ✓ (the remedial loop iterates weekly); below-observation ✓ (the chapter's own thesis — "invisible at the level of any single decision"; no learner, teacher, or log row ever sees the divergence happening, only its residue). Four for four, and the zone briefing's instinct is confirmed by the text.
- **Remedial loop alone (Figure 1):** strong on mechanism and cycle but static topology; it is the *engine* of the divergence video rather than a separate candidate.
- **Bias entry pipeline (Figure 2):** taxonomy, not process. Fails transition-mechanism.
- **DEWS proportion:** single revealed quantity; a beat inside another video at most.

**RECOMMENDED (one): The divergence, week by week.** A 60–75 second piece fusing Figures 1 and 4: open on two identical dots at one origin (62% = 62%); each week, the loop turns once in a corner inset — signal, interpretation, routing, displacement, confirmation — and with each turn the lower trajectory bends down at its fork diamond while the upper climbs; the off-ramp arrow appears at week four and is stopped by the ⊣ bar in the loop inset; final frame holds the terminal gap with the loop still quietly turning. The argument the chapter makes in 600 words — locally rational, globally unjust, no villain, no moment to contest — exists fully only in the time domain, which is exactly what print cannot supply.
