# CAJAL Figure Intelligence Report — Chapter 13: AI Literacy and Developmental Calibration

*Generated 2026-06-07 · /scan silent*

## Detection summary

The chapter carries five figure-grade conceptual structures, none currently depicted. (1) **Objective-indexed appropriate reliance** — the book's own two-axis extension of the trust-calibration literature (AI correctness × whether the task warrants assistance) is described entirely in prose; it is the chapter's most original construct and is genuinely two-dimensional — VG at maximum strength, and the structure the whole learner-side layer calibrates toward. (2) **The implicit-curriculum asymmetry** — orientation module vs. interface as two teaching channels of wildly unequal dosage ("twenty minutes of module against a semester of interface"); the comparison is the chapter's engine and exists only rhetorically. Note: the 20-minutes/40-hours pairing is illustrative rhetoric, not measured data — PQ correctly declines to chart it; the structure renders as channel-width comparison, caption-flagged illustrative. (3) **The mirror architecture** — guardrail spec (system side) reflected into the learner-side layer through four named interaction patterns; an undepicted symmetry, MC+VG. (4) **The five-tier developmental progression** — protection → modeling → scaffolded exploration → collaborative inquiry → autonomous critical agency. The chapter itself rules the calibration: the progression logic is inference-not-evidence, and the circulating minute-counts/supervision percentages are **evidence-free** — the figure depicts progression logic ONLY, no quantities, caption-flagged. (5) **The framework skeleton** — Long–Magerko / UNESCO / OECD share a four-part anatomy (knowledge, use, critique, creation) with critique as the unserved dimension; a taxonomy comparison, Supplementary.

Two `<!-- TABLE -->` placeholders (audit template, pattern specs) are authored as tables and should remain tables; no figure duplicates them. The five-tier markdown table stays; Figure 4 complements it by carrying the progression *logic* the table's rows cannot show as motion.

PQ findings: SAILD pre/post gains are reported as "statistically significant" without effect magnitudes in-text — nothing chartable without fabrication. Wang et al. n=40 is flagged directional — do not chart. Common Sense "three in four US teens" carries [verify] — do not chart. Zero legitimate quantitative figures in this chapter; that is itself consistent with the chapter's epistemic posture and should not be fought.

## Density recommendation

**4 figures** (1 Critical, 3 Important) + 1 optional Supplementary (cut-first). The chapter is ~4,700 words of main text with two authored tables already planned; five vector figures is the ceiling before the figures start competing with the tables. Spacing: Fig 1 at the appropriate-reliance section, Fig 2 at the reframe/orientation-fallacy section, Fig 3 at the four-patterns/mirror section, Fig 4 at the five-tier section, Fig 5 (optional) at the framework-landscape section.

## Figures

### Figure 1 — The appropriate-reliance quadrant: correctness × objective (Critical; VG)

**Concept:** Objective-indexed appropriate reliance — the book's own extension. The decision-support literature indexes reliance to one axis (is the AI right?); this chapter adds a second (does the learning objective warrant assistance?). Accepting a *correct* answer can be the inappropriate move when the struggle was the point. Only a 2×2 can show that the danger quadrant is the one where the AI is right and the task says no.

**Type:** Quadrant diagram (2×2 conceptual matrix), unannotated vector; labels and axis names applied at layout.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A clean two-by-two quadrant diagram on a transparent background, built as flat unannotated vector geometry with no text anywhere. Two perpendicular 1pt axis lines in neutral dark gray cross at center, dividing an 89mm square field into four equal quadrant zones, each a pale flat tint. Upper-left quadrant tinted pale sky blue containing a single solid sky-blue circle with a short rightward arrow — assistance accepted, correctly. Lower-right quadrant tinted pale vermillion containing a vermillion octagon outline — assistance refused, correctly. The two remaining quadrants carry the failure modes: upper-right tinted pale orange with an orange circle pierced by a thin vermillion diagonal slash (the correct answer that should have been declined — the chapter's signature hazard), lower-left pale reddish-purple with a reddish-purple broken-outline circle (wrong advice accepted). The upper-right hazard quadrant carries a slightly heavier 1pt border than its siblings, the only emphasis in the composition. Flat color, no gradients, no shadows, generous whitespace, precise geometric alignment throughout.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm single-column width, 300 DPI, flat vector, transparent background.
- **[C]** 7 components: 2 axis lines; 4 quadrant tint fields; 4 quadrant glyphs (counted as one glyph set of four); 1 emphasis border on the hazard quadrant. Inference labeled: the vertical axis (objective warrants assistance / objective requires unassisted practice) is **the book's own synthesis, not an established research construct** — caption must carry the chapter's own attribution flag.
- **[O]** Square 2×2 field, horizontal axis = AI correctness (left correct → right incorrect is NOT used; use left = accept-warranted, right = decline-warranted to keep reading order; final mapping fixed at layout with annotation layer), vertical axis = objective indexation. Arrow glyph → in accept quadrant only; octagon = block/decline.
- **[P]** Okabe-Ito semantic: appropriate-accept #56B4E9 (anchor); appropriate-decline #D55E00 (blocking); the correct-but-objective-violating hazard #E69F00 (secondary) slashed with #D55E00; over-reliance failure #CC79A7 (composite). Neutral gray axes. 1pt strokes, no text.
- **[E]** Serious exclusions: no probability or confidence numbers (none exist); no learner personas; no third axis for expertise stage (prose handles the adult translation); algorithm-aversion vs. over-reliance terminology lives in the caption, not the geometry.

**BLOCK 3 — NEGATIVE:** quadrant labels rendered as text, percentage values, gauge or dial metaphors, checkmark/X clipart, traffic-light triads, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components, one relation type (quadrant membership), one emphasis point. Single-glance structure; the asymmetry of the hazard quadrant carries the whole argument. PASS.

---

### Figure 2 — Two teaching channels: the orientation module vs. the interface (Important; VG + MC)

**Concept:** The interface is the curriculum. A thin, brief channel (orientation module: teaches *about* AI) and a massive, continuous channel (the interaction loop: teaches *how to rely on* AI) both feed the learner's mental model of AI — and the interface "wins. It always wins." The orientation-module fallacy is the undepicted comparison.

**Type:** Comparative flow schematic — two parallel channels of strongly unequal width converging on one target node.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A horizontal flow schematic in flat unannotated vector, no text, transparent background. At left, two source shapes stacked vertically: a small orange rounded rectangle above, a large sky-blue rounded rectangle below, the blue one roughly four times the area of the orange. From each, a channel flows rightward to a single anchor node at far right — a deep-blue circle representing the learner's internal model. The orange channel is a thin 1pt line that terminates early in a small orange dot before resuming faintly as a dotted path: instruction that ends. The blue channel is a broad tapered band, far wider, composed of a repeating sequence of six small sky-blue circles riding the band like beads — recurring interactions, arriving continuously. Where both paths reach the deep-blue learner node, the blue band visibly wraps and shades the node's perimeter while the orange dotted line merely touches it. Flat Okabe-Ito color, generous whitespace, strict horizontal alignment, no arrowheads other than standard small triangular terminals, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 6 components: orange module source; thin orange path (dotted continuation); blue interface source; broad blue band with bead repetitions (one component); deep-blue learner-model node; band-wrap emphasis at the node. Inference labeled: the dosage ratio drawn (~4:1 area) is **illustrative, not measured** — the chapter's "twenty minutes vs. forty hours" is rhetorical contrast; caption must flag the proportions as schematic, not data.
- **[O]** Left-to-right flow; → terminals only; module channel above, interface channel below; convergence on single right anchor.
- **[P]** module/secondary #E69F00; interface/active recurring contact #56B4E9; learner-model anchor #0072B2. 1pt strokes; band fill flat; no text.
- **[E]** Serious exclusions: no clock faces or hour counts (numbers are evidence-free rhetoric); no Wang et al. percentages (n=40, flagged); no "good/bad lesson" valence coloring — the figure shows dosage asymmetry, not verdicts; the four repair patterns belong to Figure 3, not here.

**BLOCK 3 — NEGATIVE:** clock icons, hourglass icons, numerals of any kind, screen mockups, browser chrome, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 6 components, one relation (flow into the model), one comparison (channel width). The argument is carried by a single visual variable — width/continuity. PASS.

---

### Figure 3 — The mirror: guardrail spec reflected into the learner-side layer (Important; VG + MC)

**Concept:** "The learner-side layer is the mirror image of the guardrail specification." System side states what the AI may do; learner side states what the learner can understand, question, and control — carried by four recurring patterns: provenance display, error-spotting, prompt examination, restriction rationale. The chapter's structural thesis ("the guardrail spec made legible") has no depiction.

**Type:** Bilateral mirror schematic — two columns reflected across a central axis, four pattern bridges crossing it.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A symmetric vector schematic on transparent background, no text. A thin vertical 1pt dashed line in neutral gray bisects the composition: the mirror plane. On the left, one tall deep-blue rounded rectangle — the system-side guardrail specification — containing four small solid vermillion squares stacked vertically along its inner edge: restrictions, what the AI may not do. On the right, a same-sized sky-blue rounded rectangle — the learner-side layer — containing four small teal-green circles in mirrored positions: enablements, what the learner is equipped to see and do. Four horizontal 1pt connector lines cross the mirror plane, each linking one vermillion square to its teal counterpart, each terminating in a small standard arrowhead pointing rightward — every restriction translated into a legible learner-facing pattern. The geometry is strictly mirror-symmetric: same heights, same spacing, the left column's squares and the right column's circles aligned row for row. Flat Okabe-Ito fills, even whitespace, no other ornament.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 7 components: mirror axis; system-side container; learner-side container; 4 restriction squares (one set); 4 enablement circles (one set); 4 bridge connectors (one set); rightward arrowheads. The four bridges = the chapter's four named patterns (provenance, error-spotting, prompt examination, restriction rationale) — applied as annotation labels at layout, not in the vector.
- **[O]** Vertical mirror axis center; left = system side, right = learner side; → bridges left-to-right (the spec is made legible, direction matters — translation flows outward to the learner).
- **[P]** system container #0072B2 (anchor-dark); restrictions #D55E00 (blocking); learner container #56B4E9 (anchor-light); enablement patterns #009E73 (active); axis neutral gray dashed. 1pt, no text.
- **[E]** Serious exclusions: no fifth/sixth pattern (the DataWise build adds dashboard and no-AI-zone map — worked-example variants; the canonical four keep the figure clean and the caption can note the extensions); no UNESCO competency mapping; no interface mockups.

**BLOCK 3 — NEGATIVE:** literal mirror or reflection rendering, glassy surfaces, lock-and-key clipart, shield icons, eye icons, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 7 components, two relation types (containment, bridge translation), strict symmetry doing the mnemonic work. Vermillion squares and teal circles are shape-differentiated as well as color-differentiated (colorblind-safe redundancy). PASS.

---

### Figure 4 — The developmental progression: protection to autonomous critical agency (Important; VG)

**Concept:** The five-tier calibration logic as *progression*, not table rows: supervision recedes as critical autonomy grows, protection at the youngest tier being a positive design objective. Strictly the progression logic — the chapter rules the minute-counts and supervision percentages evidence-free and omits them; this figure must too. Caption-flag mandatory: **inference, not evidence; no study has tested these tiers** (and the Piagetian substrate is contested).

**Type:** Staged progression schematic — five stations on a left-to-right track with two complementary recede/grow wedges.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A horizontal five-stage progression schematic, flat unannotated vector, transparent background, no text or numerals anywhere. Five evenly spaced station nodes sit on a thin 1pt neutral baseline running left to right, connected by short standard rightward arrows. The leftmost station is a closed vermillion ring fully enclosing a small dot — protection, deliberate enclosure. Each successive station opens the ring progressively: a ring with one gap, a ring with a wider gap, a broken ring of arcs, and finally at far right a free-standing teal-green dot with no ring at all — autonomous critical agency. Above the baseline, a long flat orange wedge tapers from thick at left to a point at right: adult supervision receding. Below the baseline, a mirrored teal-green wedge grows from a point at left to thick at right: learner autonomy and critical demand rising. The two wedges are exact complements in silhouette. Flat Okabe-Ito color, even spacing, geometric precision, no icons, no figures, no clutter.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm (acceptable at 120mm landscape if layout permits), 300 DPI, vector, transparent.
- **[C]** 8 components: baseline; 5 station glyphs (one set); 4 inter-station arrows (one set); supervision wedge; autonomy wedge. Inference labeled: the entire structure is **design inference, no evidentiary tier boundaries** — caption carries the chapter's own epistemic flag plus the Papert caveat that the boundaries can move.
- **[O]** Left-to-right; → between stations; wedges above/below baseline as complementary silhouettes; opening-ring glyph encodes enclosure→freedom without any age numerals.
- **[P]** protection/enclosure rings #D55E00 (blocking, fading in stroke weight across stations); learner dot #009E73 (active); supervision wedge #E69F00 (secondary); autonomy wedge #009E73 at 40% tint with full-strength edge. Neutral baseline. 1pt, no text.
- **[E]** Serious exclusions — these are the figure's hard discipline: **no ages, no minute-counts, no supervision percentages** (evidence-free per the chapter; charting them would manufacture the false precision Chapter 4 deconstructs); no sharp tier boundary ticks (boundaries are contested — stations, not fences); no Common Sense risk figures ([verify] flagged); no companion-AI iconography.

**BLOCK 3 — NEGATIVE:** numerals, age ranges, clock or timer icons, percentage marks, children or human silhouettes, school iconography, staircase metaphors with hard risers, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components at the cap, but two of them (the wedges) are a single complementary gestalt and the station glyphs are one repeated form varied monotonically. Effective load ~4 chunks. PASS.

---

### Figure 5 — The framework skeleton beneath the named frameworks (Supplementary — cut first; VG)

**Concept:** Long–Magerko, UNESCO, and OECD AILit differ in counts and vocabulary but share a four-part skeleton — knowledge, use/skill, critical/ethical, creation/design — with critique as the systematically unserved dimension. "Teach the skeleton as the stable core and the named frameworks as the replaceable layer."

**Type:** Layered taxonomy schematic — three framework strata above, one shared four-bone skeleton below, the critique bone highlighted.

**BLOCK 1 — Illustrae paste (S+C+O+P):**
A two-level alignment schematic in flat unannotated vector, no text, transparent background. The upper level holds three horizontal rounded rectangles side by side in pale neutral tints — three named frameworks — each subdivided by thin 1pt interior lines into a different number of small cells (five, four, and four segments respectively), visibly different internal anatomies. Below them, separated by clear whitespace, one wide foundation bar divided into four equal solid segments: deep blue, sky blue, orange, and reddish purple — the shared skeleton. Thin 1pt connector lines drop from each upper framework into the foundation bar, several lines from each, converging so that every framework touches all four foundation segments. The third foundation segment — the critique segment, orange — is drawn with a heavier outline and sits slightly proud of the bar's baseline, and notably the connector lines reaching it are dotted rather than solid: the dimension every framework names and every interface underserves. Flat color, strict alignment, generous spacing, nothing decorative.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector, transparent.
- **[C]** 8 components: 3 framework strata (one set); their interior subdivisions (one set); foundation bar; 4 skeleton segments (one set); solid connector fan (one set); dotted connectors to critique; critique emphasis outline. Inference labeled: the four-part skeleton is **the chapter's synthesis across frameworks**, and "critique is the unserved dimension" is the chapter's gap-analysis claim — caption attributes both to the book, not the frameworks.
- **[O]** Vertical: replaceable layer above, stable core below; connectors descend; dotted = underserved linkage.
- **[P]** knowledge #0072B2; use #56B4E9; critique #E69F00 (secondary, emphasized — the gap); creation #CC79A7; framework strata neutral 15% gray tints. 1pt, no text.
- **[E]** Serious exclusions: no competency counts as numerals (17/12 etc. live in prose); no logos or institutional marks; no EU AI Act element (regulatory beat is prose-only); no attempt to map individual competencies cell-to-cell (fabricated precision).

**BLOCK 3 — NEGATIVE:** organization logos, flags, document icons, numerals, skeleton/bone literalism, pillar or temple metaphors, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** 8 components, but the connector fans risk visual noise if more than 3 lines per framework are drawn — constrain to 3 per stratum (one per visible touch, critique dotted) at production. CONDITIONAL PASS; cut first if density pressure appears.

---

## Video candidate pass

**Recommended (one): "The interface teaches with perfect attendance" — 60–90s animation of Figure 2's mechanism.** Open on the learner-model node, blank. The orange module channel fires once — a brief pulse, a small deposit on the node — then goes dormant (dotted). The blue interface channel then begins its bead stream: hint after hint, answer after answer, each bead landing on the node and tinting it more deeply blue, week markers accruing silently. Mid-video, swap the lesson valence: same stream, but each bead now carries the rationale glyph from the DataWise third attempt (Figure 3's teal circles) — the node's accretion pattern visibly reorganizes. Close on the two end states side by side: same dosage, different curriculum. This animates the one claim the chapter cannot demonstrate on paper — that dosage × design, not content, writes the learner's model of AI — and it reuses two figure vocabularies without introducing new components.

Runner-up (not recommended this cycle): the five-tier ring-opening progression as a 20s morph — elegant but it risks reifying an inference-only framework with motion-graphics authority; the static figure's caption flag is the safer carrier.
