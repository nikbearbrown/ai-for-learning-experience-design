# CAJAL Figure Intelligence Report — Chapter 1: Two Layers of Change
*Generated 2026-06-07 · /scan silent · Source: chapters/01-two-layers-of-change.md*

## Detection summary

| Zone | Heuristic | Rank | Type |
|---|---|---|---|
| Three-condition Bastani results table (+48/−17, +127/≈0) | PQ | Critical | statistical-quantitative (dot plot, dual endpoint panels) |
| Two-layer pattern: AI in design practice vs. AI in the learning experience, with dual-layer crossing zone | VG | Critical | conceptual map / comparison panels |
| "Whose cognitive work?" feature-routing diagnostic (feature → layer → governing questions) | MC | Important | process flowchart |
| Engagement–learning dissociation (four-pillars telemetry vs. learning outcome; GPT Base as high-engagement/negative-learning case) | VG | Supplementary | statistical-quantitative (conceptual quadrant) |

Triaged to zero (correct zeros): the Two-Layer Audit output format (the chapter's own `<!-- TABLE -->` marker specifies a table — tabular, not figural); the four endpoint types (assisted/unassisted/transfer/retention — a vocabulary list, no structure to depict beyond what Figure 1 already shows); the DataWise 101 worked example (narrative procedure, carried by prose and the audit table); adoption statistics (83–87% — vendor-commissioned and convenience-sample numbers the chapter itself uses only as triangulation; charting them would grant visual authority the chapter explicitly withholds — caption-flag territory, and no figure is the honest choice).

## Density recommendation

For this chapter, I recommend **4 figures using Mixed density.** This is the book's foundational chapter: it installs one decisive quantitative result (the three-condition table), one organizing taxonomy (the two layers), and one operational diagnostic (the routing question). Each of those three is load-bearing for all fifteen chapters and each is a different figure species — so the density is necessarily mixed rather than purely foundational. The fourth (engagement quadrant) is supplementary: it earns its place because the engagement-vs-learning dissociation is the chapter's named ambush and is intrinsically spatial (two constructs that readers assume co-vary, shown not co-varying), but the chapter survives without it. More than four would begin illustrating prose that argues perfectly well on its own.

## Figures

---

### Figure 1 — The Three-Condition Result: Assisted Gains, Unassisted Outcomes (rank: Critical; heuristic: PQ)

**Concept (one sentence):** The same AI deployment can produce a large assisted-performance gain and a negative unassisted-learning outcome at once — GPT Base (+48% assisted, −17% unassisted), GPT Tutor (+127% assisted, no deficit), control at baseline — so neither endpoint is a proxy for the other.
**Figure type:** statistical-quantitative (horizontal dot plot, two endpoint panels, shared zero line)

**Cognitive Load Check:** Six data marks (three conditions × two endpoints), one zero line, one shaded negative region. A graduate LX designer parses this in a single working-memory pass: scan panel one (both AI dots far right of zero), scan panel two (one dot at zero, one dot left of zero in the negative region). The figure's entire argument is the spatial reversal between panels. Pass.

**Data integrity note:** All values are from the verified, published RCT (Bastani et al. 2025, *PNAS*). The chapter carries them as confirmed. Chart them. Caption should carry the chapter's scope caution (one school, one country, one subject, one term) — decisive on design-dependence, not on effect-size generalization. "No significant deficit" for GPT Tutor unassisted must be plotted as a dot at zero with an uncertainty whisker, never as a positive value.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector dot-plot figure, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels anywhere. Build two horizontally stacked panels sharing one vertical zero-anchored baseline that runs prominently through both panels in dark blue-gray at 1.5 pt. In the upper panel place three circular dot markers on three horizontal guide rows: one neutral light-gray dot exactly on the zero line, one vermilion dot far to the right of zero, and one bluish-green dot roughly twice as far right as the vermilion dot. In the lower panel place three dots on matching rows: the neutral gray dot on the zero line, the bluish-green dot on the zero line carrying a short horizontal uncertainty whisker, and the vermilion dot clearly left of the zero line inside a subtly shaded light-gray negative region that fills the area left of the baseline. Connect each condition's upper and lower dots with a thin 0.5 pt vertical hairline so the reversal reads as one trajectory. Use 1 pt strokes, generous white space, and leave all axes as clean unlabeled tick-marked lines.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector (SVG/EPS), white background.
[C] Confirmed chapter content only: three conditions (GPT Base, GPT Tutor, control) at two endpoints (assisted practice, unassisted exam). Six dots total: control 0/0; GPT Base +48 assisted / −17 unassisted; GPT Tutor +127 assisted / 0-with-whisker unassisted ("no significant deficit" — depicted as parity with uncertainty, an interpretation faithful to the source, not an inference). Components (6): three condition dot-pairs, zero baseline, negative-region shading, condition hairline connectors. No other data.
[O] Two stacked horizontal panels (assisted above, unassisted below); one shared vertical zero line spanning both; dots positioned proportionally (+127 ≈ 2.6× the +48 offset; −17 offset proportional on the same scale); negative region shaded only left of zero in the lower panel; thin vertical hairlines linking each condition's pair → reading order is top-to-bottom reversal.
[P] Flat vector, Okabe-Ito semantic mapping: GPT Tutor (protective/positive) #009E73; GPT Base (harm-producing) #D55E00; control (neutral) light gray #BBBBBB; zero baseline #0072B2 anchor; negative-region fill 8% gray. 1 pt strokes, no text labels, unannotated blank vector for downstream labeling.
[E] EXCLUSIONS: no bars (bars hide the negative direction and violate the dot-plot mandate); no truncated or non-zero-anchored axis; no 3D depth; no gradients on dots; no red-green pairing; no dual-headed arrows; no trend lines implying continuity between conditions; no smiley/sad iconography moralizing the outcomes; no exaggeration of the −17 offset beyond proportional scale (Proportional Ink Rule); no plotting GPT Tutor unassisted as positive; no second y-axis; no legend boxes; no callout bubbles; no decorative grid; no drop shadows.

**BLOCK 3 — NEGATIVE PROMPT:**
bar chart, truncated axis, axis not anchored at zero, exaggerated effect sizes, positive dot for parity result, emoji faces, trend curves between discrete conditions, dual axes, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 2 — The Two Layers: AI in Design Practice and in the Learning Experience (rank: Critical; heuristic: VG)

**Concept (one sentence):** AI operates in two distinct layers — Layer 1 where the designer is the user (workflow compression, deskilling risk) and Layer 2 where the learner is the user (learning damage risk) — with some features crossing both, and the Bastani-style deficit can only originate in Layer 2.
**Figure type:** conceptual map / comparison panels (two planes with a crossing zone)

**Cognitive Load Check:** Two planes, four feature markers (the chapter's (a)–(d) course-assistant example), one crossing zone, one hazard marker. Seven components. The reader's single pass: see two separated horizontal planes, see features sitting on one or the other, see the overlap band, see the hazard glyph confined to the lower plane. Pass — provided feature markers are simple glyphs, not mini-illustrations.

**Source fidelity:** This matches the chapter's own `<!-- INFOGRAPHIC -->` marker (two planes, features mapped, crossing point, different evidence standards per plane). The chapter flags the two-layer taxonomy as the book's own construct, "synthesized from the practice literature," untested as a predictor — the caption should carry that honest label; the figure itself depicts the taxonomy, which is confirmed chapter content.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector conceptual diagram, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels of any kind. Draw two broad horizontal rounded-rectangle planes stacked with clear vertical separation: an upper plane outlined in orange representing the designer's workflow layer, and a lower plane outlined in sky blue representing the learner's experience layer. Place one simple person-free workstation glyph (document-and-gear motif) at the left edge of the upper plane and one simple screen-and-dialogue-bubble motif at the left edge of the lower plane, both as minimal geometric glyphs. Distribute four small circular feature markers: two solid orange circles on the upper plane, two solid sky-blue circles on the lower plane. Between the planes draw a narrow vertical overlap band in reddish purple where one additional circle, half orange and half blue, sits spanning both planes. Inside the lower plane only, add one small vermilion warning diamond near its right edge. Connect upper plane to lower plane with a single thin downward arrow at the left margin. Use 1 pt strokes, flat fills, and generous spacing.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed chapter content only, 7 components: Layer 1 plane (designer-as-user); Layer 2 plane (learner-as-user); two Layer 1 feature markers (quiz-bank generation, summary drafting); two Layer 2 feature markers (24/7 question answering, module recommendation); one dual-layer feature marker in a crossing zone (AI-generated feedback — authored in Layer 1, delivered in Layer 2, per the chapter); one hazard marker on Layer 2 only (the only plane capable of a Bastani-style deficit). The downward arrow depicts "the learner inherits Layer 1 outputs" — stated in the chapter, not inferred.
[O] Two stacked horizontal planes, upper = Layer 1, lower = Layer 2; crossing zone as a narrow vertical band bridging both at center-right; feature dots sit on their plane; the dual feature straddles; hazard diamond bottom-right of Layer 2; single thin → from upper to lower plane at left (outputs flow down). Reading order: top plane, bottom plane, crossing band, hazard.
[P] Flat vector, Okabe-Ito: Layer 1 / designer-side #E69F00 (secondary); Layer 2 / learner-side #56B4E9 (primary anchor); crossing-zone band #CC79A7 (composite); hazard marker #D55E00 (negative); plane fills 5% neutral gray; 1 pt strokes; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no human figures (the planes are roles, not people — glyphs stay abstract); no stacking that implies hierarchy of importance (planes are parallel domains — equal widths mandatory); no arrows from Layer 2 back to Layer 1 (not in chapter); no more than five feature markers; no vendor or product iconography (no robot mascots, no brand-shaped logos); no hazard markers on Layer 1 (the chapter restricts the deficit to Layer 2); no gradient fills; no isometric depth; no decorative network meshes; no clip-art computers; no dual-headed arrows; no callout leader lines.

**BLOCK 3 — NEGATIVE PROMPT:**
robot mascots, brand logos, human figures, people at desks, hierarchy pyramid, bidirectional arrows between layers, hazard icons on the upper plane, network mesh decoration, isometric 3D planes, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 3 — The Routing Diagnostic: Whose Cognitive Work? (rank: Important; heuristic: MC)

**Concept (one sentence):** Layer assignment is performed feature-by-feature through one diagnostic question — whose cognitive work does this AI replace or restructure? — which routes a feature either to Layer 1 governing questions (output quality, accuracy, designer skill maintenance) or to Layer 2's scaffold-or-crutch question.
**Figure type:** process flowchart (single decision diamond, two branches)

**Cognitive Load Check:** Six components: feature input node, decision diamond, two branch paths, two terminal question-cluster nodes, plus a recursion cue (next feature loops back). One decision, two exits — minimal branching factor, single pass guaranteed. Pass.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector flowchart, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, containing no text labels. Begin at the top with a small rounded rectangle in neutral light gray representing a single product feature, drawn as a minimal puzzle-piece glyph inside the rectangle. Draw a 1 pt arrow downward into a central decision diamond outlined in strong blue, containing a simple abstract head-silhouette outline split into two halves — left half orange, right half sky blue — to denote the question of whose cognition is touched. From the diamond, draw two diverging 1 pt arrows: the left arrow flows to a rounded rectangle outlined in orange containing a checkmark-and-magnifier glyph cluster; the right arrow flows to a rounded rectangle outlined in sky blue containing a paired glyph of a supporting bracket and a broken crutch-like angled bar, the bracket in green and the angled bar in vermilion. From the bottom of the layout, draw one thin curved return arrow from below the terminal nodes back up to the feature node, indicating the audit repeats per feature. Keep all shapes flat, evenly spaced on a vertical spine, with generous margins.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed chapter content, 6 components: (1) feature node — the unit of analysis ("Products do not have layers. Features do."); (2) decision diamond — "whose cognitive work does this AI replace or restructure?"; (3) Layer 1 branch terminal — governing questions: output quality, accuracy verification, what skill the human stops practicing; (4) Layer 2 branch terminal — governing question: scaffold or crutch; (5) per-feature recursion arrow; (6) split-cognition glyph inside the diamond. The scaffold/crutch glyph pairing (bracket vs. broken bar) is a visual metaphor for chapter vocabulary — flag as interpretive in caption, not chapter-asserted iconography.
[O] Vertical spine, top-to-bottom: feature → diamond → two diverging branches (Layer 1 left, Layer 2 right), → arrows only; recursion as a thin return curve on the far left margin. Branch arrows equal length and equal weight — the diagnostic does not privilege either layer.
[P] Flat vector, Okabe-Ito: decision diamond stroke #0072B2 (primary anchor); Layer 1 branch and terminal #E69F00; Layer 2 branch and terminal #56B4E9; scaffold glyph #009E73; crutch glyph #D55E00; feature node neutral light gray; 1 pt strokes; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no third branch (the chapter's "both layers" case is handled by running the diagnostic per feature, not by a tri-fork — adding one would fabricate a decision path); no product-level input (input is a single feature); no weighting cues making one branch look preferred; no Bastani numbers in this figure (they live in Figure 1); no swimlanes; no more than one decision diamond; no flowchart-template clip art; no rounded arrows looping through the diamond; no icons of specific products; no gradient fills; no drop shadows; no human figures.

**BLOCK 3 — NEGATIVE PROMPT:**
three-way branch, swimlane layout, multiple decision diamonds, product logos, weighted or thickened preferred path, numeric annotations, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

### Figure 4 — Engagement Is Not Learning: The Dissociation Quadrant (rank: Supplementary; heuristic: VG)

**Concept (one sentence):** Behavioral engagement and durable learning are independent dimensions — the GPT Base condition occupied the high-engagement/negative-learning quadrant, the most satisfying condition in the study being the most harmful one.
**Figure type:** statistical-quantitative (conceptual 2×2 quadrant; positions ordinal, not metric)

**Cognitive Load Check:** Two axes, four quadrants, three condition markers. Five working components. Single-pass read: locate the marker high on the engagement axis but below zero on the learning axis. Pass.

**Data integrity note:** The chapter supports the *ordering* (GPT Base maximal engagement, negative learning; GPT Tutor high engagement, no deficit; control baseline) but supplies no engagement metric values. Marker positions are therefore ordinal/conceptual — caption must say "positions schematic, ordering per Bastani et al. 2025 and Hirsh-Pasek et al. 2015 framework." Do not let the figure imply measured engagement coordinates. The EVER-routine reference in the chapter carries a [verify] flag — keep EVER out of the figure entirely.

**BLOCK 1 — ILLUSTRAE PASTE BLOCK:**
Create an unannotated blank vector quadrant chart, single column 89 mm wide, 300 DPI minimum, flat vector on a white background, with no text labels anywhere. Draw a square plot area divided by one vertical axis line and one horizontal axis line crossing at center, both 1.5 pt in dark blue-gray; the horizontal axis represents learning outcome with its zero at the crossing point, and the vertical axis represents engagement intensity anchored at zero at the bottom edge. Lightly shade the upper-left quadrant in pale vermilion tint at 10% opacity and the upper-right quadrant in pale green tint at 10% opacity. Place three flat circular markers: a vermilion circle high in the upper-left quadrant, a bluish-green circle at comparable height in the upper-right quadrant, and a neutral light-gray circle exactly on the vertical axis at mid-height. Give the vermilion marker a thin halo ring of small radiating tick marks suggesting telemetry activity, and keep the other two markers plain. Use 1 pt strokes, no gridlines, and leave wide margins for downstream labeling.

**BLOCK 2 — FULL SCOPE PROMPT:**
[S] Single column, 89 mm width, 300 DPI minimum, vector, white background.
[C] Confirmed orderings only, 5 components: horizontal axis = unassisted learning outcome (zero at center crossing — negative region exists and is used); vertical axis = engagement (zero-anchored at bottom); GPT Base marker (high engagement, negative learning); GPT Tutor marker (high engagement, non-negative learning); control marker (baseline learning, lower engagement). Positions are ordinal — the chapter gives no engagement values; caption-flag as schematic. The telemetry-halo on GPT Base is interpretive shorthand for "maximal engagement telemetry" — label as inference in caption.
[O] Classic quadrant: axes cross at learning-zero; engagement increases upward; learning increases rightward; the two upper quadrants subtly tinted to oppose each other (harm tint upper-left, benefit tint upper-right); three markers only.
[P] Flat vector, Okabe-Ito: GPT Base #D55E00; GPT Tutor #009E73; control neutral light gray #BBBBBB; axes #0072B2; quadrant tints 10% opacity of #D55E00 and #009E73 respectively (spatially separated, never adjacent blends — colorblind-safe by hue and position). 1 pt strokes; no text labels; unannotated blank vector.
[E] EXCLUSIONS: no metric tick values (positions are ordinal — printed scales would fabricate data); no trend line or arrow connecting the three markers (no trajectory exists between conditions); no fourth marker; no smile/frown faces; no app-interface screenshots; no streak-flame or badge iconography; no axis breaks; no lower-quadrant markers (no condition observed there — leave empty, do not decorate); no gradient backgrounds; no drop shadows; no 3D tilt; no rainbow scales.

**BLOCK 3 — NEGATIVE PROMPT:**
numeric axis values, scatter trend line, connecting arrows between markers, emoji faces, flame icons, badge icons, app screenshots, extra data points, text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion

---

## Video candidate pass

- **Figure 1 — Three-Condition Result: VIDEO CANDIDATE** (criterion: transition-mechanism). The figure's argument is temporal: practice with AI present → AI withdrawn → unassisted exam reversal. A 20–25 s animation that first grows the assisted dots rightward, then visually removes the AI affordance (interface element dissolving), then resolves the unassisted dots — GPT Tutor settling on zero, GPT Base sliding left into the shaded negative region — enacts the Withdrawal Test rather than describing it. Format: 2D flat-vector motion graphic, two-panel morph, no narration dependency, loopable.
- **Figure 2 — Two Layers: STATIC SUFFICIENT.** A taxonomy of planes; no state change, no cycle. Animation would add motion without mechanism.
- **Figure 3 — Routing Diagnostic: STATIC SUFFICIENT.** One decision, two exits — below the 3+ causal-stage threshold; the recursion loop is trivially read statically.
- **Figure 4 — Dissociation Quadrant: STATIC SUFFICIENT.** Positional claim, single state.

**Close: 1 candidate, and it is the ONE recommended — Figure 1.** Rationale: the chapter's deepest misreading risk is treating the table as two static columns rather than as a before/after withdrawal event; motion is the only modality that makes the removal of the tool — the causal hinge of the whole book — perceptually explicit, and the chapter's signature mechanic (the Withdrawal Test) is literally a transition.
