# CAJAL Figure Intelligence Report — Chapter 11: Trust, Transparency, and the Designed Relationship
*Generated 2026-06-07 · /scan silent*

## Detection summary

Scan of the revised chapter (≈6,070 words) finds one central mechanism (cue → implied claim → induced false belief = affective misinformation), one genuine evidentiary tension the chapter holds without resolving falsely (disclosure costs trust per Schilke & Reimann, yet concealment is empirically, legally, and thetically unavailable), one classic undepicted framework (Lee & See calibrated trust: misuse/disuse/resolution), one emblematic spec pattern (the five-requirement escape hatch — author DIAGRAM placeholder present at line ~72), one assembly structure (six spec files → nine-cell per-touchpoint guardrail table), and one cluster of verified survey percentages (WGU Labs, n=545).

- **MC hits:** the cue-as-claim mechanism (design cue → claim about inner state → learner belief → claim false → miscalibrated reliance: five steps, undepicted — the chapter's Critical figure). The transparency dilemma resolution (disclose-as-label → trust cost; conceal → triple block; relational metadata as the exit: three branches converging).
- **VG hits:** Lee & See calibration (overtrust/misuse vs. distrust/disuse — a two-region structure the field always draws and this chapter doesn't yet); the escape-hatch five-requirement spec (placeholder honored, Figure 3); the guardrail assembly (six files into one table, holes made visible — the chapter's own integration-test metaphor).
- **PQ hits (verified):** WGU toplines carried without [verify] flags: 89% can tell bot from person; 76% prefer a person for complex/sensitive issues; 65% trust staff/faculty on AI ethics; 50% trust fellow students; 65% know how to escalate. The "40%+ of non-users can't find the human" segment figure carries an explicit [verify] — **excluded** from any chart, caption-mention only. Schilke & Reimann's n>3,000 / 13 experiments are study-scale facts, not chartable outcomes (no effect sizes carried in chapter — correctly so; do not fabricate).
- **Existing placeholders:** TABLE cue-audit template (line ~24 — should remain a typeset table; Figure 1 below depicts the *mechanism*, not the audit grid) and DIAGRAM escape-hatch spec (line ~72 — absorbed as Figure 3).
- **Register note (per Ch11 sensitivity):** the chapter carries litigation over a teenager's death and a 344-user survey including trauma reenactment. **No figure depicts the Setzer case, the litigation timeline, the survey's harm themes, or any person.** All figures stay strictly diagrammatic, sober, and mechanism-level — matching the chapter's own design-analysis register. The Bhat theme list and the legal timeline remain prose.

## Density recommendation

**Six figures.** The chapter is the act's integration checkpoint and its densest in undepicted structure; each of the six carries a distinct, non-overlapping idea (mechanism, dilemma, spec pattern, calibration field, assembly schematic, survey floor). Do not exceed six: the case-study section (Stat Sage) is narrative and self-illustrating in prose, and the litigation material must not be figured. Cognitive Load Check passed at six: one idea per figure, the only chart (Fig. 6) is five plain bars, and the two flowcharts never exceed eight components.

## Figures

### Figure 1 — Every Cue Is a Claim (Critical; MC)

**Concept:** the affective-misinformation mechanism: an anthropomorphic design cue (typing delay, memory talk, affirmation) makes an implicit claim about an inner state; the learner forms the belief; the system has no such state, so the belief is false — misinformation about the relationship. Parallel honest path: an honest signal makes a true claim and produces a calibrated belief. The audit bans false claims, not warmth.

**Type:** two-path mechanism diagram with inhibition mark.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Two horizontal three-node chains stacked with clear vertical separation, each reading left to right. Upper chain: a small pulsing-dots motif rendered as three solid circles inside a rounded speech-bubble outline (the cue), an arrow to a heart-outline shape inside a thought-bubble outline (the implied inner-state claim), an arrow to a filled circle inside a head-profile-free abstract container — a plain rounded square — representing the belief the learner now holds. Immediately after this third node, a bold vermillion inhibition bar (perpendicular blunt-ended stroke) stands between the belief and a hollow dashed outline of the heart shape: the claimed inner state does not exist; the belief points at nothing. Lower chain: a small open ledger-like rectangle with three tally marks abstracted as short bars (the honest signal), an arrow to an unadorned check-free document outline (the true claim), an arrow to a filled circle in green inside the same plain rounded-square container — a belief that lands on something real, with a solid green terminal node behind it. Flat vector, 1pt, no text; the upper chain in warm pink and vermillion, the lower in blue and green.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 8 components (cap): upper chain — cue node, implied-claim node, induced-belief node, inhibition bar + hollow referent; lower chain — honest-signal node, true-claim node, calibrated-belief node with solid referent. Layout labels: "cue → claim → belief → (no referent)" / "signal → true claim → calibrated belief." The "belief is misinformation" framing is Bhat & Long's published claim — cite in caption; the honest-path parallel is the chapter's design move — label as design pattern.
- **[O]** two parallel left-to-right chains; → between nodes; ⊣ only on the upper chain, after the belief node — placement matters: the harm is the unmet referent, not the warmth itself.
- **[P]** anthropomorphic-cue chain composite #CC79A7 (synthetic-relationship hue) with blocking #D55E00 reserved for the inhibition bar and hollow referent; honest chain anchor #0072B2 with active #009E73 terminal. 1pt, no text.
- **[E]** exclusions — serious: no human figures, no faces, no child or teen iconography, no Character.AI or product trade dress, no broken-heart cliché, nothing that dramatizes the litigation material. The heart outline is the *claimed* state and must be an outline-only abstraction; if the heart reads as sentimental in proof, substitute a thought-bubble glyph. No depiction of the six Bhat survey themes.
- **Cognitive Load Check:** two chains, one break, four hues — at the ceiling but passes; the parallel structure does the comparative work.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no faces or emoji, no chat-app interface chrome, no avatars, no broken hearts, no tears or distress imagery, no robot icons, no speech bubbles containing letterforms, no brand styling. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 2 — The Transparency Dilemma and Its Exit (High; MC)

**Concept:** the chapter's central design tension drawn without false resolution: disclosure-as-label carries a measured trust cost (Schilke & Reimann); concealment is triple-blocked (empirical — 89% already know; legal — EU AI Act Art. 50; thetical — calibration requires knowing what the helper is); the supported exit is disclosure-as-relational-metadata carrying the four facts (what is acting; what it may/may not do; who oversees; how to reach them). Honestly labeled a design hypothesis.

**Type:** branching decision flow with one blocked branch and one transformed branch.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A single node at top center in deep blue — the design problem — splitting into two descending branches. Left branch: an arrow leads to a plain rectangular tag shape (a label, sticker-like, with a small punched hole), and from it a short arrow descends to a downward-pointing solid orange triangle: the measured cost, value lost. Right branch: an arrow toward a solid dark shape (concealment) is cut by three parallel vermillion inhibition bars stacked in close sequence across the arrow shaft — three independent blocks on one path — and the concealed node beyond them is rendered hollow and dashed, unreachable. From the left branch's tag node, a third path curves down and rightward to the resolution: the same tag shape redrawn larger and integrated into a horizontal chip-like bar containing four small distinct compartments in a row, each compartment a simple filled square in blue-green family — metadata traveling with the interaction rather than stuck at the door. A small green upward triangle sits beside it: cost partially repaid. Flat vector, 1pt, no text, sober spacing, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 8 components: problem node, label-tag node, cost marker (▼), concealment path with triple ⊣ and hollow node, four-compartment metadata chip, recovery marker (▲). Layout labels: branches "disclose as label" / "conceal"; the three bars "89% already know · Art. 50 · calibration thesis"; chip compartments = the four facts. Caption must carry the chapter's own epistemic flag: relational metadata is a **design hypothesis, not a validated pattern** [contested — active research].
- **[O]** top-down branch; → on open paths; ⊣ ×3 on the concealment path only; curved → from label to chip showing transformation, not addition.
- **[P]** problem and metadata chip anchor #0072B2/#56B4E9; trust-cost marker secondary #E69F00; concealment blocks blocking #D55E00; recovery marker active #009E73 (never adjacent to the vermillion bars — separated by the chip). 1pt, no text.
- **[E]** exclusions: no Schilke effect sizes (none carried in chapter — do not fabricate bars); no courtroom/legal iconography for Art. 50; no depiction of "trust" as a gauge or meter (false precision); the WGU 89% appears only as a caption citation on the first inhibition bar.
- **Cognitive Load Check:** three branches, one transformation — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no scales of justice, no gavels, no masks or blindfolds for concealment, no shield icons, no literal stickers with writing, no balance-beam imagery, no gauge dials. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 3 — The Single-Click Escape Hatch: Five Requirements (High; VG — honors author placeholder)

**Concept:** the chapter's emblematic pattern as a spec diagram: a central escape-hatch node with the five non-negotiable requirements arrayed around it — visible (at every touchpoint), one action, functional (staffed queue, stated response time), never penalized, logged (escalation as evaluation metric). The fire-exit standard: measured by findability in the bad moment.

**Type:** hub-and-requirements spec schematic.

**BLOCK 1 — Illustrae paste (unannotated vector):**
A central rounded-square node in solid green containing a simple open-doorway glyph — a rectangle with one side open and a short outward arrow through the opening — the exit itself, active and real. Around it, five satellite rounded rectangles at even radial spacing (roughly a pentagon), each connected to the center by a plain 1pt line (not arrows — these are requirements, not flows). Each satellite carries one minimal glyph: an open eye outline (visible); a single dot with one short arrow (one action); a small queue of three aligned squares with a clock-circle outline (functional, staffed, response time); a hand-flat-open outline with no barrier mark (never penalized — rendered as an *absence*: a doorway glyph with no turnstile, if the hand reads poorly); a small ledger rectangle with tally bars (logged). All satellites in blue family; the center alone in green. Below the composition, set apart by white space, a single dashed hollow doorway outline in vermillion — the unstaffed hatch, worse than none. Flat vector, even geometry, no text, no ornament.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 7 components: central hatch, five requirement satellites, one counter-example (dashed unstaffed hatch). Layout labels: the five requirement names; counter-example caption "an unstaffed escape hatch is worse than none — it teaches learners the exit is fake" (chapter's own annotation, near-verbatim). All five requirements are the chapter's explicit spec — no inference flags.
- **[O]** radial hub with plain connector lines; the only arrow in the figure is inside the doorway glyph (the exit action itself); counter-example isolated below.
- **[P]** hatch active #009E73; requirement satellites anchor #56B4E9 with #0072B2 strokes; failed hatch blocking #D55E00 dashed. Green and vermillion separated by the full satellite ring — no adjacency. 1pt, no text.
- **[E]** exclusions: no fire imagery, no alarms, no emergency-red flooding (vermillion confined to the single counter-example); no staffing-org detail; the WGU inversion (least comfortable learners least able to find the exit) is Figure 6's caption territory, not geometry here.
- **Cognitive Load Check:** hub + 5 + 1, single glyph per node — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no flames, no fire-exit running-man pictograms (human figure), no EXIT letterforms, no alarm bells, no telephone icons, no checklist checkmarks on satellites, no padlocks. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 4 — Calibrated Trust: The Field Between Misuse and Disuse (Medium-High; VG)

**Concept:** Lee & See's design goal as a conceptual field: trust matched to actual local capability. The calibration band runs diagonally; above it, overtrust → misuse (relying where the system fails); below it, distrust → disuse (rejecting help where it works). Resolution — trust that discriminates by zone — appears as the band tightening. Conceptual space only: no axes, no ticks, no fake quantities.

**Type:** two-dimensional conceptual region diagram (non-quantitative — no axis furniture).

**BLOCK 1 — Illustrae paste (unannotated vector):**
A large square field bounded by a plain 1pt neutral frame — explicitly not a chart: no tick marks, no axis arrows, no gridlines, no origin emphasis. A wide diagonal band runs corner to corner from lower left to upper right, rendered as a smooth green ribbon with soft straight edges: the calibration zone, where reliance tracks capability. The triangular region above the band is tinted in pale flat orange, carrying a single small glyph — a filled circle leaning on a dashed, visibly incomplete support strut: weight placed on what cannot hold it. The triangular region below the band is tinted in pale flat blue, carrying its own single glyph — a solid sturdy support strut standing unused beside a filled circle that leans away from it: help present, refused. Inside the green band, two small filled circles sit directly on top of two solid struts of different heights — reliance proportioned to what is actually there. Flat matte vector, three tints plus glyph strokes, 1pt, no text, no legend, no decoration.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 6 components: bounding frame, diagonal calibration band, overtrust region + glyph, distrust region + glyph, two in-band calibrated glyph pairs. Layout labels: field edges "system capability (local task)" and "learner trust" set as margin text outside the frame at typesetting — the vector itself carries no axis machinery; regions "overtrust → misuse" / "distrust → disuse" / band "calibrated." Cite Lee & See (2004) in caption; the band-as-ribbon rendering is this book's depiction — label as adaptation.
- **[O]** diagonal organization, lower-left to upper-right; no arrows anywhere — this is a state space, not a flow.
- **[P]** calibration band active #009E73; overtrust region secondary #E69F00 pale tint; disuse region anchor #56B4E9 pale tint; glyph strokes #0072B2. Orange and green meet only at the band edge as flat tints (Okabe-Ito orange/green pair is colorblind-distinguishable; no red-green pairing). 1pt, no text.
- **[E]** exclusions: no Bansal explanation-effect overlay (one idea per figure — the explanations-increase-wrong-acceptance finding stays prose); no Bastani replication imagery; no numeric trust scores (none exist); resolution (zone-wise discrimination) is caption, not a second diagram.
- **Cognitive Load Check:** one field, three regions, four glyph clusters — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no axis arrows, no tick marks, no gridlines, no plotted curves or data points implying measurement, no gauge or dial imagery, no trust-meter clichés, no scatter texture. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 5 — The Assembly: Six Files, Nine Cells, and the Holes (Medium-High; VG)

**Concept:** the guardrail specification as integration test: six spec files (05–10) converge into one per-touchpoint table of nine cells; assembly makes the holes visible — an empty cell (a decision to ship the default), a contradiction between two source files, an orphan touchpoint no file covered (the chapter's nudge-email case).

**Type:** convergence-and-grid structural schematic.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Upper register: six small document-card rectangles in a row, each a plain rounded rectangle with a subtly different single accent stripe along its top edge — six distinct sources, equal weight, in muted blue tones. From each card a thin 1pt line descends, converging into a single wide grid below: one horizontal row of nine equal square cells, boldly framed — the per-touchpoint guardrail row. Seven of the nine cells are filled with flat solid blue; the geometry of the convergence lines shows different cards feeding different cells. Three deliberate defects interrupt the order: one cell is entirely empty — white, hairline-framed, conspicuous by absence against its filled neighbors; one cell is split diagonally into two clashing solid tones, orange and pink, with a small vermillion inhibition bar at the split — two sources disagree; and to the right of the grid, slightly detached, floats one hollow dashed ninth-cell-sized square connected to nothing — the touchpoint no file ever mentioned. Flat vector, 1pt, strict alignment, no text, no embellishment.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** at the 8-cap counting grouped units: source-file row (6 cards as one register), convergence lines, nine-cell row, empty-cell defect, contradiction-cell defect with ⊣, orphan cell. Layout labels: cards "spec/05–spec/10"; cells per the chapter's nine (touchpoint; identity/disclosure; permitted; forbidden; gates/fading; routing; content/feedback; assessment role; escalation); defects "[GAP — shipped default]", "[CONTRADICTION]", "[ORPHAN]". Caption carries the chapter's discipline verbatim in spirit: an empty cell is not a missing decision — it is a decision to ship the default.
- **[O]** top-down convergence; thin plain lines (not arrows — provenance, not flow); ⊣ only at the contradiction split.
- **[P]** source cards anchor #56B4E9 with #0072B2 accents; filled cells #0072B2; contradiction tones secondary #E69F00 vs. composite #CC79A7 with blocking #D55E00 bar; orphan dashed #D55E00. 1pt, no text.
- **[E]** exclusions: no attempt to render actual cell contents or the Stat Sage case specifics; six touchpoints × nine cells full matrix rejected (54 cells — Cognitive Load fail); one row stands for all.
- **Cognitive Load Check:** one row, three defects — passes; the full matrix variant explicitly rejected.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no spreadsheet chrome, no checkmarks in filled cells, no folder icons, no funnel imagery, no puzzle pieces, no more than three defects, no color-coding of all nine cells individually. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

### Figure 6 — The Floor Numbers (Medium; PQ)

**Concept:** the verified WGU Labs toplines (n=545 online students, fielded Sept 2025) that set the transparency layer's floor: 89% can tell bot from person; 76% prefer a person for complex or sensitive issues; 65% trust staff/faculty to use AI ethically; 65% know how to escalate to a human; 50% trust fellow students. The pair 65/50 shows the integrity-anxiety gap; the 65% escalation topline implies the third who cannot find the human.

**Type:** zero-anchored horizontal bar chart, five bars.

**BLOCK 1 — Illustrae paste (unannotated vector):**
Five horizontal bars of equal height with even gaps, all growing rightward from one shared crisp vertical baseline at the left — the zero anchor. Bar lengths, top to bottom: 89, 76, 65, 65, 50 on a common scale whose full extent (100) is marked only by a faint hairline frame behind each bar, so each bar reads against a complete whole. The top bar (89) in deep blue. The second (76) in lighter blue. The third and fourth bars (65, 65) in the same lighter blue, with the fourth bar's missing remainder — the rightmost 35-portion of its hairline frame — tinted pale vermillion: the third of students who cannot find the human, the only emphasized absence in the chart. The fifth bar (50) in orange. No gridlines, no tick marks, no axis labels in the vector, no numerals. Flat matte fills, 1pt outlines, generous left margin reserved for typeset row labels. Sober, even, unornamented; the single designed emphasis is that one shaded gap.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300DPI, flat vector.
- **[C]** 7 components: zero baseline, five data bars, one emphasized-gap tint. Layout labels per row: "can tell bot from person — 89%"; "prefer a person for sensitive issues — 76%"; "trust staff to use AI ethically — 65%"; "know how to escalate to a human — 65%"; "trust fellow students — 50%." Caption flags, mandatory: single institution; online population skewing older/non-traditional; the "40%+ of non-users can't find the human" segment figure is **[verify] and excluded** — only the 65% topline is charted; the gap tint is the arithmetic complement (≈35%), an emphasis of verified data, not a new datum.
- **[O]** shared left zero anchor; descending order except the thematic 65/65 pairing; emphasized absence on the escalation row only.
- **[P]** bars anchor #0072B2 (89) and #56B4E9 (76, 65, 65); peer-trust bar secondary #E69F00; gap tint pale blocking #D55E00. 1pt, no text in vector.
- **[E]** exclusions: the unverified non-user segment breakdown; "reliance drift" behavioral claims (no numbers carried); any cross-survey mixing with Schilke & Reimann or Bhat.
- **Cognitive Load Check:** five bars, one emphasis — passes.

**BLOCK 3 — NEGATIVE:**
Figure-specific: no truncated baseline, no pie/donut, no pictogram people-rows (human figures), no icons per bar, no numerals baked into vector, no dual-axis tricks, no more than one emphasized gap. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

---

## Video candidate pass

Candidates considered: (a) the cue-audit transformation — the Stat Sage interface element by element: typing dots, memory talk, "I believe in you," each cue paused, its implicit claim surfaced, then replaced live by its honest equivalent (instant reply, visible log metadata, evidence-grounded encouragement), ending on the four-fact header chip; (b) the overcorrection arc — vendor default → stripped "INPUT RECEIVED" hostility → honest warmth, teaching that the audit bans false claims, not warmth; (c) the assembly walkthrough — six files converging, the nudge-email orphan discovered.

**Recommended: (a) the cue-audit transformation (75–100s).** It demonstrates the chapter's core move (every cue is a claim; audit which claims are true) as an *action the viewer can repeat on any interface*, uses only the chapter's own before/after copy, requires no human characters, and stays entirely clear of the litigation material. Register requirement: sober UI-anatomy treatment — screen elements and annotations only, no persona voice, no synthetic warmth in the narration itself. Candidate (b) folds into (a) as a 15-second coda if length allows.
