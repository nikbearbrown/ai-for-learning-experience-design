# CAJAL Figure Intelligence Report — Chapter 9: AI-Generated Content and Feedback: Where Judgment Stays Human
*Generated 2026-06-07 · /scan silent*

## Detection summary

Five figure-worthy structures confirmed in the revised text; two align with the author's own placeholders:

1. **The explicit-criteria / tacit-judgment boundary with the stakes rule** — the chapter's central distinction ("a specifiability gradient, not a quality gradient") plus its one governing dynamic ("the boundary tightens as stakes rise"). The author's placeholder specifies the two-column taxonomy; this scan adds the stakes-shift arrow to the same figure, because the static boundary without the movement rule is half the concept. VG, Critical.
2. **The pipeline shift** — production queue with judgment embedded → near-zero-cost generation → validation queue; "speed moved forward in the pipeline; the bottleneck moved to judgment." MC; the chapter's video candidate.
3. **The perception/performance split** (IRRODL 2024, n=108) — equal performance, significantly lower engagement. The author's placeholder asks for two dashboards. PQ — **constrained: the chapter reports direction and significance, not magnitudes.** Quiz-score equality and engagement deficit have no published effect sizes in the text, so panels render the *pattern* (overlap vs. separation) with an explicit not-to-scale caption; n=108 and the verified status go in the caption; the "distraction, discomfort, disconnectedness" triad keeps its [verify] flag and stays out of the figure.
4. **Proxy versus construct, both directions** — BABEL on the evaluation side (gibberish satisfies the proxies, earns top scores) and the plausible-distractor problem as its "generation-side twin." The chapter explicitly mirrors them; the figure should too. VG.
5. **Partnership over replacement** — the AI-plus-teacher allocation (AI takes criteria-explicit passes, human attention freed for misconception and motivational work), "the best-performing design" on current evidence, echoing Tutor CoPilot's architecture. VG.

**Numbers requiring caption-flag handling:** the retention/revision-depth findings carry [verify — re-anchor before print] — no figure may chart them; Figure 4's caption may reference revision-shallowness only as flagged. The 77-study review and RELC scoping review carry [verify exact citation] — direction-verified, citation-pending; neither contributes a chartable quantity anyway. Hwang & Lee 2025 carries [verify — pin citation]; Figure 5 depicts the architecture pattern, which is multiply sourced (hybrid feedback configuration is direction-verified), not the Hwang & Lee effect size — caption keeps the flag. The DataWise boundary table and Evidence Box are typeset tables, already author-planned; no figure assigned.

## Density recommendation

Main expository body ≈ 3,300 words across six sections plus apparatus. **Five figures.** The chapter is argument-dense but table-rich — two author-planned tables (boundary spec, evidence box) already absorb the structured content, so figures concentrate on the four conceptual structures tables cannot hold plus one constrained PQ. Do not add a sixth; the boundary-spec four-column content must stay tabular or it will compete with Figure 1's gradient logic.

## Figures

---

### Figure 1 — The specifiability gradient (Critical; VG)

**Concept:** The explicit-criteria / tacit-judgment boundary — AI handles what can be written down in a rubric before the work arrives; degrades where judgment happens in situ — with the stakes rule as a movable line: high stakes shift the boundary left, shrinking the AI zone.

**Type:** Two-field boundary schematic with stakes-shift vector.

**BLOCK 1 — Illustrae paste:**
A two-field boundary schematic rendered as a flat, unannotated vector illustration. A wide horizontal rectangle divided into two unequal fields by a single vertical dashed line in dark blue, positioned right of center. The left field, slightly tinted in pale blue, contains five small crisp geometric shapes — squares and right-angled forms — arranged in a tidy grid: regular, repeatable, specifiable. The right field, untinted white, contains four soft asymmetric blob-like forms with smooth irregular outlines, loosely scattered: tacit, contextual, unspecifiable in advance. The two shape vocabularies must contrast sharply — machined versus organic — while sharing scale and stroke weight. Above the dashed boundary line, a single horizontal orange arrow points leftward, short and emphatic, indicating the line's direction of travel; beneath the arrow, a second dashed vertical line in lighter orange stands to the left of the blue one — the boundary's high-stakes position, ghosted. No shapes cross either line. Flat white background, 1pt strokes, generous spacing, no text, geometric precision, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Wide landscape; boundary at ~60% width, ghost boundary at ~40%.
- **[C]** 6 components: (1) framing rectangle with two-field tint split; (2) primary boundary line (dashed); (3) explicit-criteria shape set, gridded geometric forms [inference: shape vocabulary — machined vs. organic — is invented visual shorthand for specifiable vs. tacit; labeled INFERENCE, typeset labels arrive in layout]; (4) tacit-judgment shape set, irregular organic forms; (5) stakes-shift arrow (leftward); (6) ghosted high-stakes boundary position.
- **[O]** Left = AI-suitable, right = human-required, matching the author placeholder's column order; the shift arrow points LEFT only — single-headed, the rule has one direction ("tightens as stakes rise"; the rightward relaxation is a governance decision, not a gradient, and is excluded). Ghost line lighter and thinner (0.75pt) than primary.
- **[P]** Primary boundary anchor #0072B2; left-field tint #56B4E9 at 15% opacity; geometric shapes anchor #0072B2 outlines; organic shapes composite #CC79A7 outlines; stakes arrow and ghost boundary secondary #E69F00. No green, no red-orange — nothing here is endorsed or blocked; it is a map.
- **[E]** Serious exclusions: no subject-matter icons (code brackets, pencils, calculators — the boundary is explicitly NOT "easy vs. hard subjects" and any subject iconography would re-teach the misconception the chapter retires), no robot/human figures at the field ends, no quality or difficulty axis, no third field.

**BLOCK 3 — NEGATIVE:**
Figure-specific: subject-matter icons, robot or human silhouettes, brain imagery, checkmarks, difficulty stars, a rightward arrow, shapes straddling the boundary line, more than two dashed verticals. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Two shape families, one line, one arrow, one ghost. The machined/organic contrast is processed pre-attentively; the stakes rule costs one additional fixation.

---

### Figure 2 — The bottleneck moved (High; MC)

**Concept:** The pipeline shift: when generation was expensive, judgment rode inside the production queue; near-zero-cost generation breaks the coupling and the queue re-forms in front of validation. "Speed moved forward in the pipeline; the bottleneck moved to judgment."

**Type:** Before/after stacked pipeline comparison.

**BLOCK 1 — Illustrae paste:**
A before-and-after pipeline comparison rendered as a flat, unannotated vector illustration, two horizontal pipelines stacked with generous vertical separation. Top pipeline (before): at left, a queue of five small blue circles waiting; then a very wide rectangle in blue — the production stage — containing, embedded within its area, a smaller nested pink rectangle, judgment living inside production; then a narrow blue rectangle — a thin final check; then one output circle at right. The wide rectangle visibly throttles the queue. Bottom pipeline (after): the same left-to-right anatomy transformed — the production rectangle now tiny, barely wider than a circle; immediately after it, a long queue of nine small circles crowding before a very wide pink rectangle — judgment, now standing alone and enlarged, holding the queue; then the output circle. The nested pink rectangle from the top pipeline and the standalone pink rectangle below must read as the same element relocated and grown. A thin gray downward arrow between pipelines marks the transformation. Flat white background, 1pt strokes, no text, aligned stage positions, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape; two pipelines sharing left/right margins so stage displacement is measurable by eye.
- **[C]** 8 components (at cap): top — (1) input queue (five dots); (2) wide production stage; (3) nested judgment block; (4) output node. Bottom — (5) shrunken production stage; (6) swollen mid-pipeline queue (nine dots) [inference: queue lengths are qualitative magnitudes, not data — labeled INFERENCE]; (7) standalone enlarged judgment/validation stage; (8) transformation arrow between pipelines.
- **[O]** Left-to-right flow, → single-headed connectors between stages; queue dots unconnected (waiting, not flowing). The before/after vertical alignment is load-bearing: the pink block's migration rightward-and-larger IS the argument. Width ratios: top production ≈ 4× its bottom counterpart; bottom judgment ≈ 3× its top nested counterpart.
- **[P]** Pipeline stages and queue dots anchor #56B4E9 with #0072B2 strokes; judgment blocks composite #CC79A7 (the judgment chain — the chapter's "chain of judgments"); transformation arrow 50% gray; output nodes active #009E73. No blocking color — nothing fails here; the system reorganizes.
- **[E]** Serious exclusions: no dollar signs or cost iconography (the economics are the cause; the figure shows the effect), no clock faces, no "validation theater" variant panel (a third pipeline would break the cap and the theater concept is a caption/prose payload), no document or page icons for content items — plain circles only.

**BLOCK 3 — NEGATIVE:**
Figure-specific: dollar signs, clocks, hourglasses, document icons, factory imagery, funnel shapes, a third pipeline, dashed "future" pipeline, differing dot sizes within a queue. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. One anatomy read twice; the only cognitive work is registering two size swaps and one queue relocation — which is precisely the chapter's one-sentence thesis.

---

### Figure 3 — Two dashboards, one module (High; PQ — direction-only, magnitudes withheld)

**Concept:** The perception/performance split (IRRODL 2024, n=108, verified): quiz performance equivalent between AI-instructor and human-instructor video; engagement significantly lower for AI. **Hard-rule handling: the chapter publishes direction and significance, not magnitudes — the figure renders overlap vs. separation as a pattern, with the caption stating "directional rendering; effect magnitudes not depicted to scale" plus n and source.** Matches and disciplines the author's split-dashboard placeholder.

**Type:** Two-panel paired-trace schematic, zero-anchored baselines.

**BLOCK 1 — Illustrae paste:**
A two-panel paired-trace schematic rendered as a flat, unannotated vector illustration, panels side by side, equal size, each with its own plain zero baseline along the bottom and a short vertical baseline at left meeting it at a true origin. Left panel: two 1.5pt horizontal-trending lines — one blue, one orange — running left to right at identical height, so closely overlapping that they visually braid into near-coincidence; their two terminal dots land at the same height. Right panel: the same two lines begin at a shared height at the left edge, then separate early — the blue line holding nearly level, the orange line sagging in a smooth shallow decline to a visibly lower terminal dot. The contrast between panels must be instant: braided-equal on the left, opened-wedge on the right. No gridlines, no tick marks, no shading between lines, no numerals. A thin gray divider separates the panels. Flat white background, geometric precision, generous margins, Okabe-Ito palette only.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape; two equal panels, shared baseline geometry, both y-baselines zero-anchored and drawn.
- **[C]** 6 components: (1) left panel axis pair; (2) braided equal trace pair (performance) [inference: traces are schematic renderings of "indistinguishable" and "significantly lower" — no published curves exist; caption must carry the not-to-scale statement]; (3) left terminal dots, same height; (4) right panel axis pair; (5) diverging trace pair (engagement/watch-time); (6) right terminal dots, separated.
- **[O]** Left-to-right within panels (time/sequence); human-instructor line blue in both panels, AI-instructor line orange in both — consistent assignment is mandatory so the reader tracks conditions across panels; divergence in the right panel begins in the first third, per "after the first few minutes" in the author placeholder.
- **[P]** Human-instructor traces anchor #0072B2; AI-instructor traces secondary #E69F00; baselines 60% gray; terminal dots match their line colors. Two hues total, colorblind-safe pair.
- **[E]** Serious exclusions: no numerals anywhere (no fabricated magnitudes), no dashboard chrome, screens, or UI framing (the author placeholder's "dashboard" framing invites interface clutter — the data pattern, not the software, is the concept), no learner-quote triad imagery ("distraction, discomfort, disconnectedness" is [verify]-flagged and verbal), no third line for hybrid conditions.

**BLOCK 3 — NEGATIVE:**
Figure-specific: numerals, dashboard or browser chrome, video-player icons, play buttons, face icons, gridlines, shaded confidence bands, crossing lines in the left panel, dramatic cliff-drop in the right panel. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Two panels, two lines each, one contrast: braid versus wedge. The figure teaches "the dashboard that shows success and the dashboard that shows the warning are not the same dashboard" in a single saccade pair.

---

### Figure 4 — The shell without the core (Medium; VG)

**Concept:** Proxy versus construct, mirrored: BABEL on the evaluation side — an automated scorer reads the measurable shell (structure, sophistication, length) and a hollow artifact passes; the plausible-distractor problem on the generation side — a distractor with the shell of wrongness but no misconception core diagnoses nothing. Same failure shape, both directions; the misconception-inventory fix is the core restored.

**Type:** Mirrored two-panel core/shell schematic.

**BLOCK 1 — Illustrae paste:**
A mirrored two-panel schematic rendered as a flat, unannotated vector illustration. Each panel is built around one shell-and-core motif: a large circle with a robust 2pt outline (the shell) that may or may not contain a solid filled core. Left panel (evaluation): two shell circles side by side — the first contains a solid pink core centered inside; the second is conspicuously empty, pure outline around white space. Both shells are identical in size and stroke. Beneath each, an identical short green arrow points down to an identical small green check-substitute: a plain filled circle — the scorer's identical verdict. The visual scandal is symmetry: full and hollow receive the same mark. Right panel (generation, mirrored composition): two shell circles again — the first empty, the second containing a solid pink core; from each, an arrow points upward into a small grid of four squares, a test item; only the cored shell's arrow is drawn solid, the hollow shell's arrow is dashed. A thin vertical gray divider separates panels. Flat white background, 1pt strokes except 2pt shells, no text, exact bilateral balance, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Landscape; two panels mirror-composed about the central divider.
- **[C]** 8 components (at cap): left — (1) cored shell; (2) hollow shell; (3–4) two identical verdict arrows-plus-marks [inference: identical verdict marks render "gibberish reliably earned top scores" — the equality of treatment, not any score value]; right — (5) hollow shell with dashed uplink; (6) cored shell with solid uplink; (7) item grid target; (8) panel divider.
- **[O]** Left panel reads downward (artifact → verdict); right panel reads upward (distractor → item) — opposed flow directions reinforce the mirror; → single-headed throughout; dashed = connection asserted but not real (merely plausible wrongness), solid = mapped to a named misconception.
- **[P]** Shells anchor #0072B2; cores composite #CC79A7 (the construct — the real thing); verdict arrows/marks active #009E73 (the scorer approves both — deliberately uncomfortable); item grid anchor #56B4E9; dashed uplink 60% gray. The discomfort of green approving a hollow shell is the figure's pedagogical sting and is intentional.
- **[E]** Serious exclusions: no essay/page iconography, no letterforms or pseudo-text inside shells (BABEL is about gibberish — rendering gibberish would put gibberish letters in the figure, a standard-list violation), no score numerals, no e-rater or product reference, no third shell per panel.

**BLOCK 3 — NEGATIVE:**
Figure-specific: pseudo-text, lorem-ipsum textures, essay-page icons, letter grades, stars, magnifying glasses, robot graders, more than two shells per panel, cores of differing sizes. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. One motif (shell±core) instantiated four times under one relation per panel. The mirror structure converts two prose sections into a single reusable schema — high germane-load efficiency.

---

### Figure 5 — Partnership beats replacement (Medium; VG)

**Concept:** The AI-plus-teacher configuration with distinct roles — AI takes the fast, criteria-explicit pass; scarce human attention is freed for misconception-reframing and motivational work — versus the replacement architecture the procurement pitch assumes. "Partnership architectures keep outperforming replacement architectures, on both sides of the screen."

**Type:** Two-panel allocation schematic.

**BLOCK 1 — Illustrae paste:**
A two-panel allocation schematic rendered as a flat, unannotated vector illustration, panels stacked vertically. Each panel shows the same cast: at left, a column of six small neutral squares — pieces of learner work; at right edge, the work column repeated after processing. Top panel (replacement): a single large pink rounded rectangle stands between the columns, and all six flow lines pass through it; no other element exists — one processor, total interception. Bottom panel (partnership): two processors side by side in sequence — first a pink rounded rectangle, smaller than the top panel's, through which all six lines pass; then, after it, four of the six lines continue straight to the output column while two lines bend upward through a solid blue circle — the human — before rejoining. The blue circle sits slightly elevated, unmistakably distinct in shape and hue from the pink rectangle. The two diverted lines must be the visually marked ones: slightly thicker, in blue, against four thinner gray pass-through lines. Flat white background, 1pt baseline strokes, orthogonal routing with gentle bends, no text, generous spacing, Okabe-Ito palette.

**BLOCK 2 — FULL SCOPE:**
- **[S]** 89mm, 300 DPI, vector. Portrait-leaning; two stacked panels, identical column geometry.
- **[C]** 7 components: top — (1) input/output work columns; (2) monolithic AI processor intercepting all lines. Bottom — (3) input/output columns; (4) reduced AI processor, first position; (5) human node, second position, elevated; (6) four pass-through lines [inference: the 4/2 split is a qualitative allocation, not a measured ratio — labeled INFERENCE]; (7) two diverted judgment-bearing lines.
- **[O]** Left-to-right flow both panels; → single-headed; the bottom panel's sequence order (AI first, human second) is load-bearing — the AI pass *frees* the human, it does not gatekeep the human; diverted lines rejoin before the output column so both panels end with six delivered items.
- **[P]** Work squares and diverted lines anchor #56B4E9 / #0072B2; AI processors composite #CC79A7; human node anchor #0072B2 solid; pass-through lines 50% gray. Green withheld deliberately — the chapter endorses the pattern, but the figure should argue by structure, not by color-coded applause.
- **[E]** Serious exclusions: no human pictogram (a plain circle, per the no-human-figures rule; the elevation and hue do the work), no Tutor CoPilot reference, no effect-size badge (Hwang & Lee 2025 is [verify]-flagged; the hybrid superiority is direction-verified at review level — caption cites with flags intact), no third panel for human-only purity (the chapter kills it on arithmetic, in prose).

**BLOCK 3 — NEGATIVE:**
Figure-specific: human silhouettes or stick figures, robot icons, handshake imagery, heart icons, trophy or medal marks, a third panel, lines that terminate unprocessed, crossing flow lines. Standard: text labels, words, gibberish letters, titles, captions, decorative borders, realistic textures, plastic wrap effects, drop shadows, gradient backgrounds, photographic elements, non-standard arrows, dual-headed arrows, hand-drawn styles, sketch lines, human figures, visual clutter, overlapping unaligned paths, fuzzy borders, watermarks, red-green color combinations, rainbow color scales, 3D perspective distortion.

**Cognitive Load Check:** PASS. Same cast read twice; the delta is one node added and two lines diverted. The 4/2 visual ratio quietly carries the chapter's budget arithmetic (most volume explicit, scarce attention reserved) without a single number.

---

## Video candidate pass

Criteria sweep:
- **The pipeline shift (Figure 2 substrate):** transition-mechanism ✓ (cost collapse → coupling breaks → queue re-forms at judgment); 3+ causal stages ✓ (generation cost falls → production stage shrinks → judgment decouples from production → backlog migrates → validation becomes the cost center → unbudgeted validation decays into theater); cyclical ✗ (one-way structural transition); below-observation ✓ (the bottleneck's migration is invisible on every team dashboard — teams see speed, not the relocated queue; validation theater is precisely the state of not seeing it). Three of four, with the strongest temporal spine in the chapter.
- **Boundary creep / stakes shift (Figure 1):** genuinely temporal (rows drift under deadline pressure) and below-observation, but its mechanism is governance, not causation — stages are decisions, not dynamics. Second place; better served as an interactive than a video.
- **Perception/performance split (Figure 3):** two static findings; the open compounding question would require fabricating longitudinal data the chapter explicitly says nobody has measured. Disqualified on no-fabrication.
- **Proxy/construct mirror (Figure 4):** a structural pun, not a process. Fails.

**RECOMMENDED (one): The bottleneck moves.** A 45–60 second piece on Figure 2's anatomy: items flow through the wide production stage at a laborious pace, the nested judgment block pulsing with each item — judgment riding inside the work; then the production stage contracts in a single beat, items begin arriving at triple rate, and the queue visibly re-forms in front of the now-standalone judgment block, which has not grown; the final movement offers the fork — either the judgment block widens (budgeted validation) or items begin slipping past it unpaused (validation theater), and the piece holds on the slipping variant one beat longer than is comfortable. The chapter's thesis sentence — generation is fast, judgment is the bottleneck, the bottleneck is the job — is a statement about rates, and rates are the one thing animation depicts natively.
